(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var MongoID = Package['mongo-id'].MongoID;
var DiffSequence = Package['diff-sequence'].DiffSequence;
var Random = Package.random.Random;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var ObserveSequence, seqChangedToEmpty, seqChangedToArray, seqChangedToCursor;

var require = meteorInstall({"node_modules":{"meteor":{"observe-sequence":{"observe_sequence.js":function module(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/observe-sequence/observe_sequence.js                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
const isObject = function (value) {
  var type = typeof value;
  return value != null && (type == 'object' || type == 'function');
};
const has = (obj, path) => {
  const thisPath = Array.isArray(path) ? path : [path];
  const length = thisPath.length;
  for (let i = 0; i < length; i++) {
    const key = thisPath[i];
    const _has = obj != null && Object.hasOwnProperty.call(obj, key);
    if (!_has) return false;
    obj = obj[key];
  }
  return !!length;
};
const warn = function () {
  if (ObserveSequence._suppressWarnings) {
    ObserveSequence._suppressWarnings--;
  } else {
    if (typeof console !== 'undefined' && console.warn) console.warn.apply(console, arguments);
    ObserveSequence._loggedWarnings++;
  }
};

// isArray returns true for arrays of these types:
// standard arrays: instanceof Array === true, _.isArray(arr) === true
// vm generated arrays: instanceOf Array === false, _.isArray(arr) === true
// subclassed arrays: instanceof Array === true, _.isArray(arr) === false
// see specific tests
function isArray(arr) {
  return arr instanceof Array || Array.isArray(arr);
}

// isIterable returns trues for objects implementing iterable protocol,
// except strings, as {{#each 'string'}} doesn't make much sense.
// Requires ES6+ and does not work in IE (but degrades gracefully).
// Does not support the `length` + index protocol also supported by Array.from
function isIterable(object) {
  const iter = typeof Symbol != 'undefined' && Symbol.iterator;
  return iter && object instanceof Object // note: returns false for strings
  && typeof object[iter] == 'function'; // implements iterable protocol
}
const idStringify = MongoID.idStringify;
const idParse = MongoID.idParse;
ObserveSequence = {
  _suppressWarnings: 0,
  _loggedWarnings: 0,
  // A mechanism similar to cursor.observe which receives a reactive
  // function returning a sequence type and firing appropriate callbacks
  // when the value changes.
  //
  // @param sequenceFunc {Function} a reactive function returning a
  //     sequence type. The currently supported sequence types are:
  //     Array, Cursor, and null.
  //
  // @param callbacks {Object} similar to a specific subset of
  //     callbacks passed to `cursor.observe`
  //     (http://docs.meteor.com/#observe), with minor variations to
  //     support the fact that not all sequences contain objects with
  //     _id fields.  Specifically:
  //
  //     * addedAt(id, item, atIndex, beforeId)
  //     * changedAt(id, newItem, oldItem, atIndex)
  //     * removedAt(id, oldItem, atIndex)
  //     * movedTo(id, item, fromIndex, toIndex, beforeId)
  //
  // @returns {Object(stop: Function)} call 'stop' on the return value
  //     to stop observing this sequence function.
  //
  // We don't make any assumptions about our ability to compare sequence
  // elements (ie, we don't assume EJSON.equals works; maybe there is extra
  // state/random methods on the objects) so unlike cursor.observe, we may
  // sometimes call changedAt() when nothing actually changed.
  // XXX consider if we *can* make the stronger assumption and avoid
  //     no-op changedAt calls (in some cases?)
  //
  // XXX currently only supports the callbacks used by our
  // implementation of {{#each}}, but this can be expanded.
  //
  // XXX #each doesn't use the indices (though we'll eventually need
  // a way to get them when we support `@index`), but calling
  // `cursor.observe` causes the index to be calculated on every
  // callback using a linear scan (unless you turn it off by passing
  // `_no_indices`).  Any way to avoid calculating indices on a pure
  // cursor observe like we used to?
  observe: function (sequenceFunc, callbacks) {
    var lastSeq = null;
    var activeObserveHandle = null;

    // 'lastSeqArray' contains the previous value of the sequence
    // we're observing. It is an array of objects with '_id' and
    // 'item' fields.  'item' is the element in the array, or the
    // document in the cursor.
    //
    // '_id' is whichever of the following is relevant, unless it has
    // already appeared -- in which case it's randomly generated.
    //
    // * if 'item' is an object:
    //   * an '_id' field, if present
    //   * otherwise, the index in the array
    //
    // * if 'item' is a number or string, use that value
    //
    // XXX this can be generalized by allowing {{#each}} to accept a
    // general 'key' argument which could be a function, a dotted
    // field name, or the special @index value.
    var lastSeqArray = []; // elements are objects of form {_id, item}
    var computation = Tracker.autorun(function () {
      var seq = sequenceFunc();
      Tracker.nonreactive(function () {
        var seqArray; // same structure as `lastSeqArray` above.

        if (activeObserveHandle) {
          // If we were previously observing a cursor, replace lastSeqArray with
          // more up-to-date information.  Then stop the old observe.
          lastSeqArray = lastSeq.fetch().map(function (doc) {
            return {
              _id: doc._id,
              item: doc
            };
          });
          activeObserveHandle.stop();
          activeObserveHandle = null;
        }
        if (!seq) {
          seqArray = seqChangedToEmpty(lastSeqArray, callbacks);
        } else if (isArray(seq)) {
          seqArray = seqChangedToArray(lastSeqArray, seq, callbacks);
        } else if (isStoreCursor(seq)) {
          var result /* [seqArray, activeObserveHandle] */ = seqChangedToCursor(lastSeqArray, seq, callbacks);
          seqArray = result[0];
          activeObserveHandle = result[1];
        } else if (isIterable(seq)) {
          const array = Array.from(seq);
          seqArray = seqChangedToArray(lastSeqArray, array, callbacks);
        } else {
          throw badSequenceError(seq);
        }
        diffArray(lastSeqArray, seqArray, callbacks);
        lastSeq = seq;
        lastSeqArray = seqArray;
      });
    });
    return {
      stop: function () {
        computation.stop();
        if (activeObserveHandle) activeObserveHandle.stop();
      }
    };
  },
  // Fetch the items of `seq` into an array, where `seq` is of one of the
  // sequence types accepted by `observe`.  If `seq` is a cursor, a
  // dependency is established.
  fetch: function (seq) {
    if (!seq) {
      return [];
    } else if (isArray(seq)) {
      return seq;
    } else if (isStoreCursor(seq)) {
      return seq.fetch();
    } else if (isIterable(seq)) {
      return Array.from(seq);
    } else {
      throw badSequenceError(seq);
    }
  }
};
function ellipsis(longStr, maxLength) {
  if (!maxLength) maxLength = 100;
  if (longStr.length < maxLength) return longStr;
  return longStr.substr(0, maxLength - 1) + '…';
}
function arrayToDebugStr(value, maxLength) {
  var out = '',
    sep = '';
  for (var i = 0; i < value.length; i++) {
    var item = value[i];
    out += sep + toDebugStr(item, maxLength);
    if (out.length > maxLength) return out;
    sep = ', ';
  }
  return out;
}
function toDebugStr(value, maxLength) {
  if (!maxLength) maxLength = 150;
  const type = typeof value;
  switch (type) {
    case 'undefined':
      return type;
    case 'number':
      return value.toString();
    case 'string':
      return JSON.stringify(value);
    // add quotes
    case 'object':
      if (value === null) {
        return 'null';
      } else if (Array.isArray(value)) {
        return 'Array [' + arrayToDebugStr(value, maxLength) + ']';
      } else if (Symbol.iterator in value) {
        // Map and Set are not handled by JSON.stringify
        return value.constructor.name + ' [' + arrayToDebugStr(Array.from(value), maxLength) + ']'; // Array.from doesn't work in IE, but neither do iterators so it's unreachable
      } else {
        // use JSON.stringify (sometimes toString can be better but we don't know)
        return value.constructor.name + ' ' + ellipsis(JSON.stringify(value), maxLength);
      }
    default:
      return type + ': ' + value.toString();
  }
}
function sequenceGotValue(sequence) {
  try {
    return ' Got ' + toDebugStr(sequence);
  } catch (e) {
    return '';
  }
}
const badSequenceError = function (sequence) {
  return new Error("{{#each}} currently only accepts " + "arrays, cursors, iterables or falsey values." + sequenceGotValue(sequence));
};
const isFunction = func => {
  return typeof func === "function";
};
const isStoreCursor = function (cursor) {
  return cursor && isObject(cursor) && isFunction(cursor.observe) && isFunction(cursor.fetch);
};

// Calculates the differences between `lastSeqArray` and
// `seqArray` and calls appropriate functions from `callbacks`.
// Reuses Minimongo's diff algorithm implementation.
const diffArray = function (lastSeqArray, seqArray, callbacks) {
  var diffFn = Package['diff-sequence'].DiffSequence.diffQueryOrderedChanges;
  var oldIdObjects = [];
  var newIdObjects = [];
  var posOld = {}; // maps from idStringify'd ids
  var posNew = {}; // ditto
  var posCur = {};
  var lengthCur = lastSeqArray.length;
  seqArray.forEach(function (doc, i) {
    newIdObjects.push({
      _id: doc._id
    });
    posNew[idStringify(doc._id)] = i;
  });
  lastSeqArray.forEach(function (doc, i) {
    oldIdObjects.push({
      _id: doc._id
    });
    posOld[idStringify(doc._id)] = i;
    posCur[idStringify(doc._id)] = i;
  });

  // Arrays can contain arbitrary objects. We don't diff the
  // objects. Instead we always fire 'changedAt' callback on every
  // object. The consumer of `observe-sequence` should deal with
  // it appropriately.
  diffFn(oldIdObjects, newIdObjects, {
    addedBefore: function (id, doc, before) {
      var position = before ? posCur[idStringify(before)] : lengthCur;
      if (before) {
        // If not adding at the end, we need to update indexes.
        // XXX this can still be improved greatly!
        Object.entries(posCur).forEach(function (_ref) {
          let [id, pos] = _ref;
          if (pos >= position) posCur[id]++;
        });
      }
      lengthCur++;
      posCur[idStringify(id)] = position;
      callbacks.addedAt(id, seqArray[posNew[idStringify(id)]].item, position, before);
    },
    movedBefore: function (id, before) {
      if (id === before) return;
      var oldPosition = posCur[idStringify(id)];
      var newPosition = before ? posCur[idStringify(before)] : lengthCur;

      // Moving the item forward. The new element is losing one position as it
      // was removed from the old position before being inserted at the new
      // position.
      // Ex.:   0  *1*  2   3   4
      //        0   2   3  *1*  4
      // The original issued callback is "1" before "4".
      // The position of "1" is 1, the position of "4" is 4.
      // The generated move is (1) -> (3)
      if (newPosition > oldPosition) {
        newPosition--;
      }

      // Fix up the positions of elements between the old and the new positions
      // of the moved element.
      //
      // There are two cases:
      //   1. The element is moved forward. Then all the positions in between
      //   are moved back.
      //   2. The element is moved back. Then the positions in between *and* the
      //   element that is currently standing on the moved element's future
      //   position are moved forward.
      Object.entries(posCur).forEach(function (_ref2) {
        let [id, elCurPosition] = _ref2;
        if (oldPosition < elCurPosition && elCurPosition < newPosition) posCur[id]--;else if (newPosition <= elCurPosition && elCurPosition < oldPosition) posCur[id]++;
      });

      // Finally, update the position of the moved element.
      posCur[idStringify(id)] = newPosition;
      callbacks.movedTo(id, seqArray[posNew[idStringify(id)]].item, oldPosition, newPosition, before);
    },
    removed: function (id) {
      var prevPosition = posCur[idStringify(id)];
      Object.entries(posCur).forEach(function (_ref3) {
        let [id, pos] = _ref3;
        if (pos >= prevPosition) posCur[id]--;
      });
      delete posCur[idStringify(id)];
      lengthCur--;
      callbacks.removedAt(id, lastSeqArray[posOld[idStringify(id)]].item, prevPosition);
    }
  });
  Object.entries(posNew).forEach(function (_ref4) {
    let [idString, pos] = _ref4;
    var id = idParse(idString);
    if (has(posOld, idString)) {
      // specifically for primitive types, compare equality before
      // firing the 'changedAt' callback. otherwise, always fire it
      // because doing a deep EJSON comparison is not guaranteed to
      // work (an array can contain arbitrary objects, and 'transform'
      // can be used on cursors). also, deep diffing is not
      // necessarily the most efficient (if only a specific subfield
      // of the object is later accessed).
      var newItem = seqArray[pos].item;
      var oldItem = lastSeqArray[posOld[idString]].item;
      if (typeof newItem === 'object' || newItem !== oldItem) callbacks.changedAt(id, newItem, oldItem, pos);
    }
  });
};
seqChangedToEmpty = function (lastSeqArray, callbacks) {
  return [];
};
seqChangedToArray = function (lastSeqArray, array, callbacks) {
  var idsUsed = {};
  var seqArray = array.map(function (item, index) {
    var id;
    if (typeof item === 'string') {
      // ensure not empty, since other layers (eg DomRange) assume this as well
      id = "-" + item;
    } else if (typeof item === 'number' || typeof item === 'boolean' || item === undefined || item === null) {
      id = item;
    } else if (typeof item === 'object') {
      id = item && '_id' in item ? item._id : index;
    } else {
      throw new Error("{{#each}} doesn't support arrays with " + "elements of type " + typeof item);
    }
    var idString = idStringify(id);
    if (idsUsed[idString]) {
      if (item && typeof item === 'object' && '_id' in item) warn("duplicate id " + id + " in", array);
      id = Random.id();
    } else {
      idsUsed[idString] = true;
    }
    return {
      _id: id,
      item: item
    };
  });
  return seqArray;
};
seqChangedToCursor = function (lastSeqArray, cursor, callbacks) {
  var initial = true; // are we observing initial data from cursor?
  var seqArray = [];
  var observeHandle = cursor.observe({
    addedAt: function (document, atIndex, before) {
      if (initial) {
        // keep track of initial data so that we can diff once
        // we exit `observe`.
        if (before !== null) throw new Error("Expected initial data from observe in order");
        seqArray.push({
          _id: document._id,
          item: document
        });
      } else {
        callbacks.addedAt(document._id, document, atIndex, before);
      }
    },
    changedAt: function (newDocument, oldDocument, atIndex) {
      callbacks.changedAt(newDocument._id, newDocument, oldDocument, atIndex);
    },
    removedAt: function (oldDocument, atIndex) {
      callbacks.removedAt(oldDocument._id, oldDocument, atIndex);
    },
    movedTo: function (document, fromIndex, toIndex, before) {
      callbacks.movedTo(document._id, document, fromIndex, toIndex, before);
    }
  });
  initial = false;
  return [seqArray, observeHandle];
};
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/node_modules/meteor/observe-sequence/observe_sequence.js");

/* Exports */
Package._define("observe-sequence", {
  ObserveSequence: ObserveSequence
});

})();

//# sourceURL=meteor://💻app/packages/observe-sequence.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvb2JzZXJ2ZS1zZXF1ZW5jZS9vYnNlcnZlX3NlcXVlbmNlLmpzIl0sIm5hbWVzIjpbImlzT2JqZWN0IiwidmFsdWUiLCJ0eXBlIiwiaGFzIiwib2JqIiwicGF0aCIsInRoaXNQYXRoIiwiQXJyYXkiLCJpc0FycmF5IiwibGVuZ3RoIiwiaSIsImtleSIsIl9oYXMiLCJPYmplY3QiLCJoYXNPd25Qcm9wZXJ0eSIsImNhbGwiLCJ3YXJuIiwiT2JzZXJ2ZVNlcXVlbmNlIiwiX3N1cHByZXNzV2FybmluZ3MiLCJjb25zb2xlIiwiYXBwbHkiLCJhcmd1bWVudHMiLCJfbG9nZ2VkV2FybmluZ3MiLCJhcnIiLCJpc0l0ZXJhYmxlIiwib2JqZWN0IiwiaXRlciIsIlN5bWJvbCIsIml0ZXJhdG9yIiwiaWRTdHJpbmdpZnkiLCJNb25nb0lEIiwiaWRQYXJzZSIsIm9ic2VydmUiLCJzZXF1ZW5jZUZ1bmMiLCJjYWxsYmFja3MiLCJsYXN0U2VxIiwiYWN0aXZlT2JzZXJ2ZUhhbmRsZSIsImxhc3RTZXFBcnJheSIsImNvbXB1dGF0aW9uIiwiVHJhY2tlciIsImF1dG9ydW4iLCJzZXEiLCJub25yZWFjdGl2ZSIsInNlcUFycmF5IiwiZmV0Y2giLCJtYXAiLCJkb2MiLCJfaWQiLCJpdGVtIiwic3RvcCIsInNlcUNoYW5nZWRUb0VtcHR5Iiwic2VxQ2hhbmdlZFRvQXJyYXkiLCJpc1N0b3JlQ3Vyc29yIiwicmVzdWx0Iiwic2VxQ2hhbmdlZFRvQ3Vyc29yIiwiYXJyYXkiLCJmcm9tIiwiYmFkU2VxdWVuY2VFcnJvciIsImRpZmZBcnJheSIsImVsbGlwc2lzIiwibG9uZ1N0ciIsIm1heExlbmd0aCIsInN1YnN0ciIsImFycmF5VG9EZWJ1Z1N0ciIsIm91dCIsInNlcCIsInRvRGVidWdTdHIiLCJ0b1N0cmluZyIsIkpTT04iLCJzdHJpbmdpZnkiLCJjb25zdHJ1Y3RvciIsIm5hbWUiLCJzZXF1ZW5jZUdvdFZhbHVlIiwic2VxdWVuY2UiLCJlIiwiRXJyb3IiLCJpc0Z1bmN0aW9uIiwiZnVuYyIsImN1cnNvciIsImRpZmZGbiIsIlBhY2thZ2UiLCJEaWZmU2VxdWVuY2UiLCJkaWZmUXVlcnlPcmRlcmVkQ2hhbmdlcyIsIm9sZElkT2JqZWN0cyIsIm5ld0lkT2JqZWN0cyIsInBvc09sZCIsInBvc05ldyIsInBvc0N1ciIsImxlbmd0aEN1ciIsImZvckVhY2giLCJwdXNoIiwiYWRkZWRCZWZvcmUiLCJpZCIsImJlZm9yZSIsInBvc2l0aW9uIiwiZW50cmllcyIsIl9yZWYiLCJwb3MiLCJhZGRlZEF0IiwibW92ZWRCZWZvcmUiLCJvbGRQb3NpdGlvbiIsIm5ld1Bvc2l0aW9uIiwiX3JlZjIiLCJlbEN1clBvc2l0aW9uIiwibW92ZWRUbyIsInJlbW92ZWQiLCJwcmV2UG9zaXRpb24iLCJfcmVmMyIsInJlbW92ZWRBdCIsIl9yZWY0IiwiaWRTdHJpbmciLCJuZXdJdGVtIiwib2xkSXRlbSIsImNoYW5nZWRBdCIsImlkc1VzZWQiLCJpbmRleCIsInVuZGVmaW5lZCIsIlJhbmRvbSIsImluaXRpYWwiLCJvYnNlcnZlSGFuZGxlIiwiZG9jdW1lbnQiLCJhdEluZGV4IiwibmV3RG9jdW1lbnQiLCJvbGREb2N1bWVudCIsImZyb21JbmRleCIsInRvSW5kZXgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsTUFBTUEsUUFBUSxHQUFHLFNBQUFBLENBQVVDLEtBQUssRUFBRTtFQUNoQyxJQUFJQyxJQUFJLEdBQUcsT0FBT0QsS0FBSztFQUN2QixPQUFPQSxLQUFLLElBQUksSUFBSSxLQUFLQyxJQUFJLElBQUksUUFBUSxJQUFJQSxJQUFJLElBQUksVUFBVSxDQUFDO0FBQ2xFLENBQUM7QUFDRCxNQUFNQyxHQUFHLEdBQUdBLENBQUNDLEdBQUcsRUFBRUMsSUFBSSxLQUFLO0VBQ3pCLE1BQU1DLFFBQVEsR0FBR0MsS0FBSyxDQUFDQyxPQUFPLENBQUNILElBQUksQ0FBQyxHQUFHQSxJQUFJLEdBQUcsQ0FBQ0EsSUFBSSxDQUFDO0VBQ3BELE1BQU1JLE1BQU0sR0FBR0gsUUFBUSxDQUFDRyxNQUFNO0VBQzlCLEtBQUssSUFBSUMsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHRCxNQUFNLEVBQUVDLENBQUMsRUFBRSxFQUFFO0lBQy9CLE1BQU1DLEdBQUcsR0FBR0wsUUFBUSxDQUFDSSxDQUFDLENBQUM7SUFDdkIsTUFBTUUsSUFBSSxHQUFHUixHQUFHLElBQUksSUFBSSxJQUFJUyxNQUFNLENBQUNDLGNBQWMsQ0FBQ0MsSUFBSSxDQUFDWCxHQUFHLEVBQUVPLEdBQUcsQ0FBQztJQUNoRSxJQUFJLENBQUNDLElBQUksRUFBRSxPQUFPLEtBQUs7SUFDdkJSLEdBQUcsR0FBR0EsR0FBRyxDQUFDTyxHQUFHLENBQUM7RUFDaEI7RUFDQSxPQUFPLENBQUMsQ0FBQ0YsTUFBTTtBQUNqQixDQUFDO0FBRUQsTUFBTU8sSUFBSSxHQUFHLFNBQUFBLENBQUEsRUFBWTtFQUN2QixJQUFJQyxlQUFlLENBQUNDLGlCQUFpQixFQUFFO0lBQ3JDRCxlQUFlLENBQUNDLGlCQUFpQixFQUFFO0VBQ3JDLENBQUMsTUFBTTtJQUNMLElBQUksT0FBT0MsT0FBTyxLQUFLLFdBQVcsSUFBSUEsT0FBTyxDQUFDSCxJQUFJLEVBQ2hERyxPQUFPLENBQUNILElBQUksQ0FBQ0ksS0FBSyxDQUFDRCxPQUFPLEVBQUVFLFNBQVMsQ0FBQztJQUV4Q0osZUFBZSxDQUFDSyxlQUFlLEVBQUU7RUFDbkM7QUFDRixDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTZCxPQUFPQSxDQUFDZSxHQUFHLEVBQUU7RUFDcEIsT0FBT0EsR0FBRyxZQUFZaEIsS0FBSyxJQUFJQSxLQUFLLENBQUNDLE9BQU8sQ0FBQ2UsR0FBRyxDQUFDO0FBQ25EOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsVUFBVUEsQ0FBRUMsTUFBTSxFQUFFO0VBQzNCLE1BQU1DLElBQUksR0FBRyxPQUFPQyxNQUFNLElBQUksV0FBVyxJQUFJQSxNQUFNLENBQUNDLFFBQVE7RUFDNUQsT0FBT0YsSUFBSSxJQUNORCxNQUFNLFlBQVlaLE1BQU0sQ0FBQztFQUFBLEdBQ3pCLE9BQU9ZLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLElBQUksVUFBVSxDQUFDLENBQUM7QUFDMUM7QUFFQSxNQUFNRyxXQUFXLEdBQUdDLE9BQU8sQ0FBQ0QsV0FBVztBQUN2QyxNQUFNRSxPQUFPLEdBQUdELE9BQU8sQ0FBQ0MsT0FBTztBQUUvQmQsZUFBZSxHQUFHO0VBQ2hCQyxpQkFBaUIsRUFBRSxDQUFDO0VBQ3BCSSxlQUFlLEVBQUUsQ0FBQztFQUVsQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0FVLE9BQU8sRUFBRSxTQUFBQSxDQUFVQyxZQUFZLEVBQUVDLFNBQVMsRUFBRTtJQUMxQyxJQUFJQyxPQUFPLEdBQUcsSUFBSTtJQUNsQixJQUFJQyxtQkFBbUIsR0FBRyxJQUFJOztJQUU5QjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBSUMsWUFBWSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZCLElBQUlDLFdBQVcsR0FBR0MsT0FBTyxDQUFDQyxPQUFPLENBQUMsWUFBWTtNQUM1QyxJQUFJQyxHQUFHLEdBQUdSLFlBQVksQ0FBQyxDQUFDO01BRXhCTSxPQUFPLENBQUNHLFdBQVcsQ0FBQyxZQUFZO1FBQzlCLElBQUlDLFFBQVEsQ0FBQyxDQUFDOztRQUVkLElBQUlQLG1CQUFtQixFQUFFO1VBQ3ZCO1VBQ0E7VUFDQUMsWUFBWSxHQUFHRixPQUFPLENBQUNTLEtBQUssQ0FBQyxDQUFDLENBQUNDLEdBQUcsQ0FBQyxVQUFVQyxHQUFHLEVBQUU7WUFDaEQsT0FBTztjQUFDQyxHQUFHLEVBQUVELEdBQUcsQ0FBQ0MsR0FBRztjQUFFQyxJQUFJLEVBQUVGO1lBQUcsQ0FBQztVQUNsQyxDQUFDLENBQUM7VUFDRlYsbUJBQW1CLENBQUNhLElBQUksQ0FBQyxDQUFDO1VBQzFCYixtQkFBbUIsR0FBRyxJQUFJO1FBQzVCO1FBRUEsSUFBSSxDQUFDSyxHQUFHLEVBQUU7VUFDUkUsUUFBUSxHQUFHTyxpQkFBaUIsQ0FBQ2IsWUFBWSxFQUFFSCxTQUFTLENBQUM7UUFDdkQsQ0FBQyxNQUFNLElBQUkxQixPQUFPLENBQUNpQyxHQUFHLENBQUMsRUFBRTtVQUN2QkUsUUFBUSxHQUFHUSxpQkFBaUIsQ0FBQ2QsWUFBWSxFQUFFSSxHQUFHLEVBQUVQLFNBQVMsQ0FBQztRQUM1RCxDQUFDLE1BQU0sSUFBSWtCLGFBQWEsQ0FBQ1gsR0FBRyxDQUFDLEVBQUU7VUFDN0IsSUFBSVksTUFBTSxDQUFDLHdDQUNMQyxrQkFBa0IsQ0FBQ2pCLFlBQVksRUFBRUksR0FBRyxFQUFFUCxTQUFTLENBQUM7VUFDdERTLFFBQVEsR0FBR1UsTUFBTSxDQUFDLENBQUMsQ0FBQztVQUNwQmpCLG1CQUFtQixHQUFHaUIsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNqQyxDQUFDLE1BQU0sSUFBSTdCLFVBQVUsQ0FBQ2lCLEdBQUcsQ0FBQyxFQUFFO1VBQzFCLE1BQU1jLEtBQUssR0FBR2hELEtBQUssQ0FBQ2lELElBQUksQ0FBQ2YsR0FBRyxDQUFDO1VBQzdCRSxRQUFRLEdBQUdRLGlCQUFpQixDQUFDZCxZQUFZLEVBQUVrQixLQUFLLEVBQUVyQixTQUFTLENBQUM7UUFDOUQsQ0FBQyxNQUFNO1VBQ0wsTUFBTXVCLGdCQUFnQixDQUFDaEIsR0FBRyxDQUFDO1FBQzdCO1FBRUFpQixTQUFTLENBQUNyQixZQUFZLEVBQUVNLFFBQVEsRUFBRVQsU0FBUyxDQUFDO1FBQzVDQyxPQUFPLEdBQUdNLEdBQUc7UUFDYkosWUFBWSxHQUFHTSxRQUFRO01BQ3pCLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQztJQUVGLE9BQU87TUFDTE0sSUFBSSxFQUFFLFNBQUFBLENBQUEsRUFBWTtRQUNoQlgsV0FBVyxDQUFDVyxJQUFJLENBQUMsQ0FBQztRQUNsQixJQUFJYixtQkFBbUIsRUFDckJBLG1CQUFtQixDQUFDYSxJQUFJLENBQUMsQ0FBQztNQUM5QjtJQUNGLENBQUM7RUFDSCxDQUFDO0VBRUQ7RUFDQTtFQUNBO0VBQ0FMLEtBQUssRUFBRSxTQUFBQSxDQUFVSCxHQUFHLEVBQUU7SUFDcEIsSUFBSSxDQUFDQSxHQUFHLEVBQUU7TUFDUixPQUFPLEVBQUU7SUFDWCxDQUFDLE1BQU0sSUFBSWpDLE9BQU8sQ0FBQ2lDLEdBQUcsQ0FBQyxFQUFFO01BQ3ZCLE9BQU9BLEdBQUc7SUFDWixDQUFDLE1BQU0sSUFBSVcsYUFBYSxDQUFDWCxHQUFHLENBQUMsRUFBRTtNQUM3QixPQUFPQSxHQUFHLENBQUNHLEtBQUssQ0FBQyxDQUFDO0lBQ3BCLENBQUMsTUFBTSxJQUFJcEIsVUFBVSxDQUFDaUIsR0FBRyxDQUFDLEVBQUU7TUFDMUIsT0FBT2xDLEtBQUssQ0FBQ2lELElBQUksQ0FBQ2YsR0FBRyxDQUFDO0lBQ3hCLENBQUMsTUFBTTtNQUNMLE1BQU1nQixnQkFBZ0IsQ0FBQ2hCLEdBQUcsQ0FBQztJQUM3QjtFQUNGO0FBQ0YsQ0FBQztBQUVELFNBQVNrQixRQUFRQSxDQUFDQyxPQUFPLEVBQUVDLFNBQVMsRUFBRTtFQUNwQyxJQUFHLENBQUNBLFNBQVMsRUFBRUEsU0FBUyxHQUFHLEdBQUc7RUFDOUIsSUFBR0QsT0FBTyxDQUFDbkQsTUFBTSxHQUFHb0QsU0FBUyxFQUFFLE9BQU9ELE9BQU87RUFDN0MsT0FBT0EsT0FBTyxDQUFDRSxNQUFNLENBQUMsQ0FBQyxFQUFFRCxTQUFTLEdBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRztBQUM3QztBQUVBLFNBQVNFLGVBQWVBLENBQUM5RCxLQUFLLEVBQUU0RCxTQUFTLEVBQUU7RUFDekMsSUFBSUcsR0FBRyxHQUFHLEVBQUU7SUFBRUMsR0FBRyxHQUFHLEVBQUU7RUFDdEIsS0FBSSxJQUFJdkQsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHVCxLQUFLLENBQUNRLE1BQU0sRUFBRUMsQ0FBQyxFQUFFLEVBQUU7SUFDcEMsSUFBSXNDLElBQUksR0FBRy9DLEtBQUssQ0FBQ1MsQ0FBQyxDQUFDO0lBQ25Cc0QsR0FBRyxJQUFJQyxHQUFHLEdBQUdDLFVBQVUsQ0FBQ2xCLElBQUksRUFBRWEsU0FBUyxDQUFDO0lBQ3hDLElBQUdHLEdBQUcsQ0FBQ3ZELE1BQU0sR0FBR29ELFNBQVMsRUFBRSxPQUFPRyxHQUFHO0lBQ3JDQyxHQUFHLEdBQUcsSUFBSTtFQUNaO0VBQ0EsT0FBT0QsR0FBRztBQUNaO0FBRUEsU0FBU0UsVUFBVUEsQ0FBQ2pFLEtBQUssRUFBRTRELFNBQVMsRUFBRTtFQUNwQyxJQUFHLENBQUNBLFNBQVMsRUFBRUEsU0FBUyxHQUFHLEdBQUc7RUFDOUIsTUFBTTNELElBQUksR0FBRyxPQUFPRCxLQUFLO0VBQ3pCLFFBQU9DLElBQUk7SUFDVCxLQUFLLFdBQVc7TUFDZCxPQUFPQSxJQUFJO0lBQ2IsS0FBSyxRQUFRO01BQ1gsT0FBT0QsS0FBSyxDQUFDa0UsUUFBUSxDQUFDLENBQUM7SUFDekIsS0FBSyxRQUFRO01BQ1gsT0FBT0MsSUFBSSxDQUFDQyxTQUFTLENBQUNwRSxLQUFLLENBQUM7SUFBRTtJQUNoQyxLQUFLLFFBQVE7TUFDWCxJQUFHQSxLQUFLLEtBQUssSUFBSSxFQUFFO1FBQ2pCLE9BQU8sTUFBTTtNQUNmLENBQUMsTUFBTSxJQUFHTSxLQUFLLENBQUNDLE9BQU8sQ0FBQ1AsS0FBSyxDQUFDLEVBQUU7UUFDOUIsT0FBTyxTQUFTLEdBQUc4RCxlQUFlLENBQUM5RCxLQUFLLEVBQUU0RCxTQUFTLENBQUMsR0FBRyxHQUFHO01BQzVELENBQUMsTUFBTSxJQUFHbEMsTUFBTSxDQUFDQyxRQUFRLElBQUkzQixLQUFLLEVBQUU7UUFBRTtRQUNwQyxPQUFPQSxLQUFLLENBQUNxRSxXQUFXLENBQUNDLElBQUksR0FDekIsSUFBSSxHQUFHUixlQUFlLENBQUN4RCxLQUFLLENBQUNpRCxJQUFJLENBQUN2RCxLQUFLLENBQUMsRUFBRTRELFNBQVMsQ0FBQyxHQUNwRCxHQUFHLENBQUMsQ0FBQztNQUNYLENBQUMsTUFBTTtRQUFFO1FBQ1AsT0FBTzVELEtBQUssQ0FBQ3FFLFdBQVcsQ0FBQ0MsSUFBSSxHQUFHLEdBQUcsR0FDNUJaLFFBQVEsQ0FBQ1MsSUFBSSxDQUFDQyxTQUFTLENBQUNwRSxLQUFLLENBQUMsRUFBRTRELFNBQVMsQ0FBQztNQUNuRDtJQUNGO01BQ0UsT0FBTzNELElBQUksR0FBRyxJQUFJLEdBQUdELEtBQUssQ0FBQ2tFLFFBQVEsQ0FBQyxDQUFDO0VBQ3pDO0FBQ0Y7QUFFQSxTQUFTSyxnQkFBZ0JBLENBQUNDLFFBQVEsRUFBRTtFQUNsQyxJQUFJO0lBQ0YsT0FBTyxPQUFPLEdBQUdQLFVBQVUsQ0FBQ08sUUFBUSxDQUFDO0VBQ3ZDLENBQUMsQ0FBQyxPQUFNQyxDQUFDLEVBQUU7SUFDVCxPQUFPLEVBQUU7RUFDWDtBQUNGO0FBRUEsTUFBTWpCLGdCQUFnQixHQUFHLFNBQUFBLENBQVVnQixRQUFRLEVBQUU7RUFDM0MsT0FBTyxJQUFJRSxLQUFLLENBQUMsbUNBQW1DLEdBQ25DLDhDQUE4QyxHQUM5Q0gsZ0JBQWdCLENBQUNDLFFBQVEsQ0FBQyxDQUFDO0FBQzlDLENBQUM7QUFFRCxNQUFNRyxVQUFVLEdBQUlDLElBQUksSUFBSztFQUMzQixPQUFPLE9BQU9BLElBQUksS0FBSyxVQUFVO0FBQ25DLENBQUM7QUFFRCxNQUFNekIsYUFBYSxHQUFHLFNBQUFBLENBQVUwQixNQUFNLEVBQUU7RUFDdEMsT0FBT0EsTUFBTSxJQUFJOUUsUUFBUSxDQUFDOEUsTUFBTSxDQUFDLElBQy9CRixVQUFVLENBQUNFLE1BQU0sQ0FBQzlDLE9BQU8sQ0FBQyxJQUFJNEMsVUFBVSxDQUFDRSxNQUFNLENBQUNsQyxLQUFLLENBQUM7QUFDMUQsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQSxNQUFNYyxTQUFTLEdBQUcsU0FBQUEsQ0FBVXJCLFlBQVksRUFBRU0sUUFBUSxFQUFFVCxTQUFTLEVBQUU7RUFDN0QsSUFBSTZDLE1BQU0sR0FBR0MsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFDQyxZQUFZLENBQUNDLHVCQUF1QjtFQUMxRSxJQUFJQyxZQUFZLEdBQUcsRUFBRTtFQUNyQixJQUFJQyxZQUFZLEdBQUcsRUFBRTtFQUNyQixJQUFJQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNqQixJQUFJQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNqQixJQUFJQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQ2YsSUFBSUMsU0FBUyxHQUFHbkQsWUFBWSxDQUFDNUIsTUFBTTtFQUVuQ2tDLFFBQVEsQ0FBQzhDLE9BQU8sQ0FBQyxVQUFVM0MsR0FBRyxFQUFFcEMsQ0FBQyxFQUFFO0lBQ2pDMEUsWUFBWSxDQUFDTSxJQUFJLENBQUM7TUFBQzNDLEdBQUcsRUFBRUQsR0FBRyxDQUFDQztJQUFHLENBQUMsQ0FBQztJQUNqQ3VDLE1BQU0sQ0FBQ3pELFdBQVcsQ0FBQ2lCLEdBQUcsQ0FBQ0MsR0FBRyxDQUFDLENBQUMsR0FBR3JDLENBQUM7RUFDbEMsQ0FBQyxDQUFDO0VBQ0YyQixZQUFZLENBQUNvRCxPQUFPLENBQUMsVUFBVTNDLEdBQUcsRUFBRXBDLENBQUMsRUFBRTtJQUNyQ3lFLFlBQVksQ0FBQ08sSUFBSSxDQUFDO01BQUMzQyxHQUFHLEVBQUVELEdBQUcsQ0FBQ0M7SUFBRyxDQUFDLENBQUM7SUFDakNzQyxNQUFNLENBQUN4RCxXQUFXLENBQUNpQixHQUFHLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEdBQUdyQyxDQUFDO0lBQ2hDNkUsTUFBTSxDQUFDMUQsV0FBVyxDQUFDaUIsR0FBRyxDQUFDQyxHQUFHLENBQUMsQ0FBQyxHQUFHckMsQ0FBQztFQUNsQyxDQUFDLENBQUM7O0VBRUY7RUFDQTtFQUNBO0VBQ0E7RUFDQXFFLE1BQU0sQ0FBQ0ksWUFBWSxFQUFFQyxZQUFZLEVBQUU7SUFDakNPLFdBQVcsRUFBRSxTQUFBQSxDQUFVQyxFQUFFLEVBQUU5QyxHQUFHLEVBQUUrQyxNQUFNLEVBQUU7TUFDdEMsSUFBSUMsUUFBUSxHQUFHRCxNQUFNLEdBQUdOLE1BQU0sQ0FBQzFELFdBQVcsQ0FBQ2dFLE1BQU0sQ0FBQyxDQUFDLEdBQUdMLFNBQVM7TUFFL0QsSUFBSUssTUFBTSxFQUFFO1FBQ1Y7UUFDQTtRQUNBaEYsTUFBTSxDQUFDa0YsT0FBTyxDQUFDUixNQUFNLENBQUMsQ0FBQ0UsT0FBTyxDQUFDLFVBQUFPLElBQUEsRUFBcUI7VUFBQSxJQUFYLENBQUNKLEVBQUUsRUFBRUssR0FBRyxDQUFDLEdBQUFELElBQUE7VUFDaEQsSUFBSUMsR0FBRyxJQUFJSCxRQUFRLEVBQ2pCUCxNQUFNLENBQUNLLEVBQUUsQ0FBQyxFQUFFO1FBQ2hCLENBQUMsQ0FBQztNQUNKO01BRUFKLFNBQVMsRUFBRTtNQUNYRCxNQUFNLENBQUMxRCxXQUFXLENBQUMrRCxFQUFFLENBQUMsQ0FBQyxHQUFHRSxRQUFRO01BRWxDNUQsU0FBUyxDQUFDZ0UsT0FBTyxDQUNmTixFQUFFLEVBQ0ZqRCxRQUFRLENBQUMyQyxNQUFNLENBQUN6RCxXQUFXLENBQUMrRCxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM1QyxJQUFJLEVBQ3RDOEMsUUFBUSxFQUNSRCxNQUFNLENBQUM7SUFDWCxDQUFDO0lBQ0RNLFdBQVcsRUFBRSxTQUFBQSxDQUFVUCxFQUFFLEVBQUVDLE1BQU0sRUFBRTtNQUNqQyxJQUFJRCxFQUFFLEtBQUtDLE1BQU0sRUFDZjtNQUVGLElBQUlPLFdBQVcsR0FBR2IsTUFBTSxDQUFDMUQsV0FBVyxDQUFDK0QsRUFBRSxDQUFDLENBQUM7TUFDekMsSUFBSVMsV0FBVyxHQUFHUixNQUFNLEdBQUdOLE1BQU0sQ0FBQzFELFdBQVcsQ0FBQ2dFLE1BQU0sQ0FBQyxDQUFDLEdBQUdMLFNBQVM7O01BRWxFO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQSxJQUFJYSxXQUFXLEdBQUdELFdBQVcsRUFBRTtRQUM3QkMsV0FBVyxFQUFFO01BQ2Y7O01BRUE7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0F4RixNQUFNLENBQUNrRixPQUFPLENBQUNSLE1BQU0sQ0FBQyxDQUFDRSxPQUFPLENBQUMsVUFBQWEsS0FBQSxFQUErQjtRQUFBLElBQXJCLENBQUNWLEVBQUUsRUFBRVcsYUFBYSxDQUFDLEdBQUFELEtBQUE7UUFDMUQsSUFBSUYsV0FBVyxHQUFHRyxhQUFhLElBQUlBLGFBQWEsR0FBR0YsV0FBVyxFQUM1RGQsTUFBTSxDQUFDSyxFQUFFLENBQUMsRUFBRSxDQUFDLEtBQ1YsSUFBSVMsV0FBVyxJQUFJRSxhQUFhLElBQUlBLGFBQWEsR0FBR0gsV0FBVyxFQUNsRWIsTUFBTSxDQUFDSyxFQUFFLENBQUMsRUFBRTtNQUNoQixDQUFDLENBQUM7O01BRUY7TUFDQUwsTUFBTSxDQUFDMUQsV0FBVyxDQUFDK0QsRUFBRSxDQUFDLENBQUMsR0FBR1MsV0FBVztNQUVyQ25FLFNBQVMsQ0FBQ3NFLE9BQU8sQ0FDZlosRUFBRSxFQUNGakQsUUFBUSxDQUFDMkMsTUFBTSxDQUFDekQsV0FBVyxDQUFDK0QsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDNUMsSUFBSSxFQUN0Q29ELFdBQVcsRUFDWEMsV0FBVyxFQUNYUixNQUFNLENBQUM7SUFDWCxDQUFDO0lBQ0RZLE9BQU8sRUFBRSxTQUFBQSxDQUFVYixFQUFFLEVBQUU7TUFDckIsSUFBSWMsWUFBWSxHQUFHbkIsTUFBTSxDQUFDMUQsV0FBVyxDQUFDK0QsRUFBRSxDQUFDLENBQUM7TUFFMUMvRSxNQUFNLENBQUNrRixPQUFPLENBQUNSLE1BQU0sQ0FBQyxDQUFDRSxPQUFPLENBQUMsVUFBQWtCLEtBQUEsRUFBcUI7UUFBQSxJQUFYLENBQUNmLEVBQUUsRUFBRUssR0FBRyxDQUFDLEdBQUFVLEtBQUE7UUFDaEQsSUFBSVYsR0FBRyxJQUFJUyxZQUFZLEVBQ3JCbkIsTUFBTSxDQUFDSyxFQUFFLENBQUMsRUFBRTtNQUNoQixDQUFDLENBQUM7TUFFRixPQUFPTCxNQUFNLENBQUMxRCxXQUFXLENBQUMrRCxFQUFFLENBQUMsQ0FBQztNQUM5QkosU0FBUyxFQUFFO01BRVh0RCxTQUFTLENBQUMwRSxTQUFTLENBQ2pCaEIsRUFBRSxFQUNGdkQsWUFBWSxDQUFDZ0QsTUFBTSxDQUFDeEQsV0FBVyxDQUFDK0QsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDNUMsSUFBSSxFQUMxQzBELFlBQVksQ0FBQztJQUNqQjtFQUNGLENBQUMsQ0FBQztFQUVGN0YsTUFBTSxDQUFDa0YsT0FBTyxDQUFDVCxNQUFNLENBQUMsQ0FBQ0csT0FBTyxDQUFDLFVBQUFvQixLQUFBLEVBQTJCO0lBQUEsSUFBakIsQ0FBQ0MsUUFBUSxFQUFFYixHQUFHLENBQUMsR0FBQVksS0FBQTtJQUV0RCxJQUFJakIsRUFBRSxHQUFHN0QsT0FBTyxDQUFDK0UsUUFBUSxDQUFDO0lBRTFCLElBQUkzRyxHQUFHLENBQUNrRixNQUFNLEVBQUV5QixRQUFRLENBQUMsRUFBRTtNQUN6QjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUlDLE9BQU8sR0FBR3BFLFFBQVEsQ0FBQ3NELEdBQUcsQ0FBQyxDQUFDakQsSUFBSTtNQUNoQyxJQUFJZ0UsT0FBTyxHQUFHM0UsWUFBWSxDQUFDZ0QsTUFBTSxDQUFDeUIsUUFBUSxDQUFDLENBQUMsQ0FBQzlELElBQUk7TUFFakQsSUFBSSxPQUFPK0QsT0FBTyxLQUFLLFFBQVEsSUFBSUEsT0FBTyxLQUFLQyxPQUFPLEVBQ2xEOUUsU0FBUyxDQUFDK0UsU0FBUyxDQUFDckIsRUFBRSxFQUFFbUIsT0FBTyxFQUFFQyxPQUFPLEVBQUVmLEdBQUcsQ0FBQztJQUNsRDtFQUNKLENBQUMsQ0FBQztBQUNKLENBQUM7QUFFRC9DLGlCQUFpQixHQUFHLFNBQUFBLENBQVViLFlBQVksRUFBRUgsU0FBUyxFQUFFO0VBQ3JELE9BQU8sRUFBRTtBQUNYLENBQUM7QUFFRGlCLGlCQUFpQixHQUFHLFNBQUFBLENBQVVkLFlBQVksRUFBRWtCLEtBQUssRUFBRXJCLFNBQVMsRUFBRTtFQUM1RCxJQUFJZ0YsT0FBTyxHQUFHLENBQUMsQ0FBQztFQUNoQixJQUFJdkUsUUFBUSxHQUFHWSxLQUFLLENBQUNWLEdBQUcsQ0FBQyxVQUFVRyxJQUFJLEVBQUVtRSxLQUFLLEVBQUU7SUFDOUMsSUFBSXZCLEVBQUU7SUFDTixJQUFJLE9BQU81QyxJQUFJLEtBQUssUUFBUSxFQUFFO01BQzVCO01BQ0E0QyxFQUFFLEdBQUcsR0FBRyxHQUFHNUMsSUFBSTtJQUNqQixDQUFDLE1BQU0sSUFBSSxPQUFPQSxJQUFJLEtBQUssUUFBUSxJQUN4QixPQUFPQSxJQUFJLEtBQUssU0FBUyxJQUN6QkEsSUFBSSxLQUFLb0UsU0FBUyxJQUNsQnBFLElBQUksS0FBSyxJQUFJLEVBQUU7TUFDeEI0QyxFQUFFLEdBQUc1QyxJQUFJO0lBQ1gsQ0FBQyxNQUFNLElBQUksT0FBT0EsSUFBSSxLQUFLLFFBQVEsRUFBRTtNQUNuQzRDLEVBQUUsR0FBSTVDLElBQUksSUFBSyxLQUFLLElBQUlBLElBQUssR0FBSUEsSUFBSSxDQUFDRCxHQUFHLEdBQUdvRSxLQUFLO0lBQ25ELENBQUMsTUFBTTtNQUNMLE1BQU0sSUFBSXhDLEtBQUssQ0FBQyx3Q0FBd0MsR0FDeEMsbUJBQW1CLEdBQUcsT0FBTzNCLElBQUksQ0FBQztJQUNwRDtJQUVBLElBQUk4RCxRQUFRLEdBQUdqRixXQUFXLENBQUMrRCxFQUFFLENBQUM7SUFDOUIsSUFBSXNCLE9BQU8sQ0FBQ0osUUFBUSxDQUFDLEVBQUU7TUFDckIsSUFBSTlELElBQUksSUFBSSxPQUFPQSxJQUFJLEtBQUssUUFBUSxJQUFJLEtBQUssSUFBSUEsSUFBSSxFQUNuRGhDLElBQUksQ0FBQyxlQUFlLEdBQUc0RSxFQUFFLEdBQUcsS0FBSyxFQUFFckMsS0FBSyxDQUFDO01BQzNDcUMsRUFBRSxHQUFHeUIsTUFBTSxDQUFDekIsRUFBRSxDQUFDLENBQUM7SUFDbEIsQ0FBQyxNQUFNO01BQ0xzQixPQUFPLENBQUNKLFFBQVEsQ0FBQyxHQUFHLElBQUk7SUFDMUI7SUFFQSxPQUFPO01BQUUvRCxHQUFHLEVBQUU2QyxFQUFFO01BQUU1QyxJQUFJLEVBQUVBO0lBQUssQ0FBQztFQUNoQyxDQUFDLENBQUM7RUFFRixPQUFPTCxRQUFRO0FBQ2pCLENBQUM7QUFFRFcsa0JBQWtCLEdBQUcsU0FBQUEsQ0FBVWpCLFlBQVksRUFBRXlDLE1BQU0sRUFBRTVDLFNBQVMsRUFBRTtFQUM5RCxJQUFJb0YsT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFDO0VBQ3BCLElBQUkzRSxRQUFRLEdBQUcsRUFBRTtFQUVqQixJQUFJNEUsYUFBYSxHQUFHekMsTUFBTSxDQUFDOUMsT0FBTyxDQUFDO0lBQ2pDa0UsT0FBTyxFQUFFLFNBQUFBLENBQVVzQixRQUFRLEVBQUVDLE9BQU8sRUFBRTVCLE1BQU0sRUFBRTtNQUM1QyxJQUFJeUIsT0FBTyxFQUFFO1FBQ1g7UUFDQTtRQUNBLElBQUl6QixNQUFNLEtBQUssSUFBSSxFQUNqQixNQUFNLElBQUlsQixLQUFLLENBQUMsNkNBQTZDLENBQUM7UUFDaEVoQyxRQUFRLENBQUMrQyxJQUFJLENBQUM7VUFBRTNDLEdBQUcsRUFBRXlFLFFBQVEsQ0FBQ3pFLEdBQUc7VUFBRUMsSUFBSSxFQUFFd0U7UUFBUyxDQUFDLENBQUM7TUFDdEQsQ0FBQyxNQUFNO1FBQ0x0RixTQUFTLENBQUNnRSxPQUFPLENBQUNzQixRQUFRLENBQUN6RSxHQUFHLEVBQUV5RSxRQUFRLEVBQUVDLE9BQU8sRUFBRTVCLE1BQU0sQ0FBQztNQUM1RDtJQUNGLENBQUM7SUFDRG9CLFNBQVMsRUFBRSxTQUFBQSxDQUFVUyxXQUFXLEVBQUVDLFdBQVcsRUFBRUYsT0FBTyxFQUFFO01BQ3REdkYsU0FBUyxDQUFDK0UsU0FBUyxDQUFDUyxXQUFXLENBQUMzRSxHQUFHLEVBQUUyRSxXQUFXLEVBQUVDLFdBQVcsRUFDekNGLE9BQU8sQ0FBQztJQUM5QixDQUFDO0lBQ0RiLFNBQVMsRUFBRSxTQUFBQSxDQUFVZSxXQUFXLEVBQUVGLE9BQU8sRUFBRTtNQUN6Q3ZGLFNBQVMsQ0FBQzBFLFNBQVMsQ0FBQ2UsV0FBVyxDQUFDNUUsR0FBRyxFQUFFNEUsV0FBVyxFQUFFRixPQUFPLENBQUM7SUFDNUQsQ0FBQztJQUNEakIsT0FBTyxFQUFFLFNBQUFBLENBQVVnQixRQUFRLEVBQUVJLFNBQVMsRUFBRUMsT0FBTyxFQUFFaEMsTUFBTSxFQUFFO01BQ3ZEM0QsU0FBUyxDQUFDc0UsT0FBTyxDQUNmZ0IsUUFBUSxDQUFDekUsR0FBRyxFQUFFeUUsUUFBUSxFQUFFSSxTQUFTLEVBQUVDLE9BQU8sRUFBRWhDLE1BQU0sQ0FBQztJQUN2RDtFQUNGLENBQUMsQ0FBQztFQUNGeUIsT0FBTyxHQUFHLEtBQUs7RUFFZixPQUFPLENBQUMzRSxRQUFRLEVBQUU0RSxhQUFhLENBQUM7QUFDbEMsQ0FBQyxDIiwiZmlsZSI6Ii9wYWNrYWdlcy9vYnNlcnZlLXNlcXVlbmNlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgaXNPYmplY3QgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgdmFyIHR5cGUgPSB0eXBlb2YgdmFsdWU7XG4gIHJldHVybiB2YWx1ZSAhPSBudWxsICYmICh0eXBlID09ICdvYmplY3QnIHx8IHR5cGUgPT0gJ2Z1bmN0aW9uJyk7XG59XG5jb25zdCBoYXMgPSAob2JqLCBwYXRoKSA9PiB7XG4gIGNvbnN0IHRoaXNQYXRoID0gQXJyYXkuaXNBcnJheShwYXRoKSA/IHBhdGggOiBbcGF0aF07XG4gIGNvbnN0IGxlbmd0aCA9IHRoaXNQYXRoLmxlbmd0aDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGtleSA9IHRoaXNQYXRoW2ldO1xuICAgIGNvbnN0IF9oYXMgPSBvYmogIT0gbnVsbCAmJiBPYmplY3QuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIGtleSk7XG4gICAgaWYgKCFfaGFzKSByZXR1cm4gZmFsc2U7XG4gICAgb2JqID0gb2JqW2tleV07XG4gIH1cbiAgcmV0dXJuICEhbGVuZ3RoO1xufTtcblxuY29uc3Qgd2FybiA9IGZ1bmN0aW9uICgpIHtcbiAgaWYgKE9ic2VydmVTZXF1ZW5jZS5fc3VwcHJlc3NXYXJuaW5ncykge1xuICAgIE9ic2VydmVTZXF1ZW5jZS5fc3VwcHJlc3NXYXJuaW5ncy0tO1xuICB9IGVsc2Uge1xuICAgIGlmICh0eXBlb2YgY29uc29sZSAhPT0gJ3VuZGVmaW5lZCcgJiYgY29uc29sZS53YXJuKVxuICAgICAgY29uc29sZS53YXJuLmFwcGx5KGNvbnNvbGUsIGFyZ3VtZW50cyk7XG5cbiAgICBPYnNlcnZlU2VxdWVuY2UuX2xvZ2dlZFdhcm5pbmdzKys7XG4gIH1cbn07XG5cbi8vIGlzQXJyYXkgcmV0dXJucyB0cnVlIGZvciBhcnJheXMgb2YgdGhlc2UgdHlwZXM6XG4vLyBzdGFuZGFyZCBhcnJheXM6IGluc3RhbmNlb2YgQXJyYXkgPT09IHRydWUsIF8uaXNBcnJheShhcnIpID09PSB0cnVlXG4vLyB2bSBnZW5lcmF0ZWQgYXJyYXlzOiBpbnN0YW5jZU9mIEFycmF5ID09PSBmYWxzZSwgXy5pc0FycmF5KGFycikgPT09IHRydWVcbi8vIHN1YmNsYXNzZWQgYXJyYXlzOiBpbnN0YW5jZW9mIEFycmF5ID09PSB0cnVlLCBfLmlzQXJyYXkoYXJyKSA9PT0gZmFsc2Vcbi8vIHNlZSBzcGVjaWZpYyB0ZXN0c1xuZnVuY3Rpb24gaXNBcnJheShhcnIpIHtcbiAgcmV0dXJuIGFyciBpbnN0YW5jZW9mIEFycmF5IHx8IEFycmF5LmlzQXJyYXkoYXJyKTtcbn1cblxuLy8gaXNJdGVyYWJsZSByZXR1cm5zIHRydWVzIGZvciBvYmplY3RzIGltcGxlbWVudGluZyBpdGVyYWJsZSBwcm90b2NvbCxcbi8vIGV4Y2VwdCBzdHJpbmdzLCBhcyB7eyNlYWNoICdzdHJpbmcnfX0gZG9lc24ndCBtYWtlIG11Y2ggc2Vuc2UuXG4vLyBSZXF1aXJlcyBFUzYrIGFuZCBkb2VzIG5vdCB3b3JrIGluIElFIChidXQgZGVncmFkZXMgZ3JhY2VmdWxseSkuXG4vLyBEb2VzIG5vdCBzdXBwb3J0IHRoZSBgbGVuZ3RoYCArIGluZGV4IHByb3RvY29sIGFsc28gc3VwcG9ydGVkIGJ5IEFycmF5LmZyb21cbmZ1bmN0aW9uIGlzSXRlcmFibGUgKG9iamVjdCkge1xuICBjb25zdCBpdGVyID0gdHlwZW9mIFN5bWJvbCAhPSAndW5kZWZpbmVkJyAmJiBTeW1ib2wuaXRlcmF0b3I7XG4gIHJldHVybiBpdGVyXG4gICAgJiYgb2JqZWN0IGluc3RhbmNlb2YgT2JqZWN0IC8vIG5vdGU6IHJldHVybnMgZmFsc2UgZm9yIHN0cmluZ3NcbiAgICAmJiB0eXBlb2Ygb2JqZWN0W2l0ZXJdID09ICdmdW5jdGlvbic7IC8vIGltcGxlbWVudHMgaXRlcmFibGUgcHJvdG9jb2xcbn1cblxuY29uc3QgaWRTdHJpbmdpZnkgPSBNb25nb0lELmlkU3RyaW5naWZ5O1xuY29uc3QgaWRQYXJzZSA9IE1vbmdvSUQuaWRQYXJzZTtcblxuT2JzZXJ2ZVNlcXVlbmNlID0ge1xuICBfc3VwcHJlc3NXYXJuaW5nczogMCxcbiAgX2xvZ2dlZFdhcm5pbmdzOiAwLFxuXG4gIC8vIEEgbWVjaGFuaXNtIHNpbWlsYXIgdG8gY3Vyc29yLm9ic2VydmUgd2hpY2ggcmVjZWl2ZXMgYSByZWFjdGl2ZVxuICAvLyBmdW5jdGlvbiByZXR1cm5pbmcgYSBzZXF1ZW5jZSB0eXBlIGFuZCBmaXJpbmcgYXBwcm9wcmlhdGUgY2FsbGJhY2tzXG4gIC8vIHdoZW4gdGhlIHZhbHVlIGNoYW5nZXMuXG4gIC8vXG4gIC8vIEBwYXJhbSBzZXF1ZW5jZUZ1bmMge0Z1bmN0aW9ufSBhIHJlYWN0aXZlIGZ1bmN0aW9uIHJldHVybmluZyBhXG4gIC8vICAgICBzZXF1ZW5jZSB0eXBlLiBUaGUgY3VycmVudGx5IHN1cHBvcnRlZCBzZXF1ZW5jZSB0eXBlcyBhcmU6XG4gIC8vICAgICBBcnJheSwgQ3Vyc29yLCBhbmQgbnVsbC5cbiAgLy9cbiAgLy8gQHBhcmFtIGNhbGxiYWNrcyB7T2JqZWN0fSBzaW1pbGFyIHRvIGEgc3BlY2lmaWMgc3Vic2V0IG9mXG4gIC8vICAgICBjYWxsYmFja3MgcGFzc2VkIHRvIGBjdXJzb3Iub2JzZXJ2ZWBcbiAgLy8gICAgIChodHRwOi8vZG9jcy5tZXRlb3IuY29tLyNvYnNlcnZlKSwgd2l0aCBtaW5vciB2YXJpYXRpb25zIHRvXG4gIC8vICAgICBzdXBwb3J0IHRoZSBmYWN0IHRoYXQgbm90IGFsbCBzZXF1ZW5jZXMgY29udGFpbiBvYmplY3RzIHdpdGhcbiAgLy8gICAgIF9pZCBmaWVsZHMuICBTcGVjaWZpY2FsbHk6XG4gIC8vXG4gIC8vICAgICAqIGFkZGVkQXQoaWQsIGl0ZW0sIGF0SW5kZXgsIGJlZm9yZUlkKVxuICAvLyAgICAgKiBjaGFuZ2VkQXQoaWQsIG5ld0l0ZW0sIG9sZEl0ZW0sIGF0SW5kZXgpXG4gIC8vICAgICAqIHJlbW92ZWRBdChpZCwgb2xkSXRlbSwgYXRJbmRleClcbiAgLy8gICAgICogbW92ZWRUbyhpZCwgaXRlbSwgZnJvbUluZGV4LCB0b0luZGV4LCBiZWZvcmVJZClcbiAgLy9cbiAgLy8gQHJldHVybnMge09iamVjdChzdG9wOiBGdW5jdGlvbil9IGNhbGwgJ3N0b3AnIG9uIHRoZSByZXR1cm4gdmFsdWVcbiAgLy8gICAgIHRvIHN0b3Agb2JzZXJ2aW5nIHRoaXMgc2VxdWVuY2UgZnVuY3Rpb24uXG4gIC8vXG4gIC8vIFdlIGRvbid0IG1ha2UgYW55IGFzc3VtcHRpb25zIGFib3V0IG91ciBhYmlsaXR5IHRvIGNvbXBhcmUgc2VxdWVuY2VcbiAgLy8gZWxlbWVudHMgKGllLCB3ZSBkb24ndCBhc3N1bWUgRUpTT04uZXF1YWxzIHdvcmtzOyBtYXliZSB0aGVyZSBpcyBleHRyYVxuICAvLyBzdGF0ZS9yYW5kb20gbWV0aG9kcyBvbiB0aGUgb2JqZWN0cykgc28gdW5saWtlIGN1cnNvci5vYnNlcnZlLCB3ZSBtYXlcbiAgLy8gc29tZXRpbWVzIGNhbGwgY2hhbmdlZEF0KCkgd2hlbiBub3RoaW5nIGFjdHVhbGx5IGNoYW5nZWQuXG4gIC8vIFhYWCBjb25zaWRlciBpZiB3ZSAqY2FuKiBtYWtlIHRoZSBzdHJvbmdlciBhc3N1bXB0aW9uIGFuZCBhdm9pZFxuICAvLyAgICAgbm8tb3AgY2hhbmdlZEF0IGNhbGxzIChpbiBzb21lIGNhc2VzPylcbiAgLy9cbiAgLy8gWFhYIGN1cnJlbnRseSBvbmx5IHN1cHBvcnRzIHRoZSBjYWxsYmFja3MgdXNlZCBieSBvdXJcbiAgLy8gaW1wbGVtZW50YXRpb24gb2Yge3sjZWFjaH19LCBidXQgdGhpcyBjYW4gYmUgZXhwYW5kZWQuXG4gIC8vXG4gIC8vIFhYWCAjZWFjaCBkb2Vzbid0IHVzZSB0aGUgaW5kaWNlcyAodGhvdWdoIHdlJ2xsIGV2ZW50dWFsbHkgbmVlZFxuICAvLyBhIHdheSB0byBnZXQgdGhlbSB3aGVuIHdlIHN1cHBvcnQgYEBpbmRleGApLCBidXQgY2FsbGluZ1xuICAvLyBgY3Vyc29yLm9ic2VydmVgIGNhdXNlcyB0aGUgaW5kZXggdG8gYmUgY2FsY3VsYXRlZCBvbiBldmVyeVxuICAvLyBjYWxsYmFjayB1c2luZyBhIGxpbmVhciBzY2FuICh1bmxlc3MgeW91IHR1cm4gaXQgb2ZmIGJ5IHBhc3NpbmdcbiAgLy8gYF9ub19pbmRpY2VzYCkuICBBbnkgd2F5IHRvIGF2b2lkIGNhbGN1bGF0aW5nIGluZGljZXMgb24gYSBwdXJlXG4gIC8vIGN1cnNvciBvYnNlcnZlIGxpa2Ugd2UgdXNlZCB0bz9cbiAgb2JzZXJ2ZTogZnVuY3Rpb24gKHNlcXVlbmNlRnVuYywgY2FsbGJhY2tzKSB7XG4gICAgdmFyIGxhc3RTZXEgPSBudWxsO1xuICAgIHZhciBhY3RpdmVPYnNlcnZlSGFuZGxlID0gbnVsbDtcblxuICAgIC8vICdsYXN0U2VxQXJyYXknIGNvbnRhaW5zIHRoZSBwcmV2aW91cyB2YWx1ZSBvZiB0aGUgc2VxdWVuY2VcbiAgICAvLyB3ZSdyZSBvYnNlcnZpbmcuIEl0IGlzIGFuIGFycmF5IG9mIG9iamVjdHMgd2l0aCAnX2lkJyBhbmRcbiAgICAvLyAnaXRlbScgZmllbGRzLiAgJ2l0ZW0nIGlzIHRoZSBlbGVtZW50IGluIHRoZSBhcnJheSwgb3IgdGhlXG4gICAgLy8gZG9jdW1lbnQgaW4gdGhlIGN1cnNvci5cbiAgICAvL1xuICAgIC8vICdfaWQnIGlzIHdoaWNoZXZlciBvZiB0aGUgZm9sbG93aW5nIGlzIHJlbGV2YW50LCB1bmxlc3MgaXQgaGFzXG4gICAgLy8gYWxyZWFkeSBhcHBlYXJlZCAtLSBpbiB3aGljaCBjYXNlIGl0J3MgcmFuZG9tbHkgZ2VuZXJhdGVkLlxuICAgIC8vXG4gICAgLy8gKiBpZiAnaXRlbScgaXMgYW4gb2JqZWN0OlxuICAgIC8vICAgKiBhbiAnX2lkJyBmaWVsZCwgaWYgcHJlc2VudFxuICAgIC8vICAgKiBvdGhlcndpc2UsIHRoZSBpbmRleCBpbiB0aGUgYXJyYXlcbiAgICAvL1xuICAgIC8vICogaWYgJ2l0ZW0nIGlzIGEgbnVtYmVyIG9yIHN0cmluZywgdXNlIHRoYXQgdmFsdWVcbiAgICAvL1xuICAgIC8vIFhYWCB0aGlzIGNhbiBiZSBnZW5lcmFsaXplZCBieSBhbGxvd2luZyB7eyNlYWNofX0gdG8gYWNjZXB0IGFcbiAgICAvLyBnZW5lcmFsICdrZXknIGFyZ3VtZW50IHdoaWNoIGNvdWxkIGJlIGEgZnVuY3Rpb24sIGEgZG90dGVkXG4gICAgLy8gZmllbGQgbmFtZSwgb3IgdGhlIHNwZWNpYWwgQGluZGV4IHZhbHVlLlxuICAgIHZhciBsYXN0U2VxQXJyYXkgPSBbXTsgLy8gZWxlbWVudHMgYXJlIG9iamVjdHMgb2YgZm9ybSB7X2lkLCBpdGVtfVxuICAgIHZhciBjb21wdXRhdGlvbiA9IFRyYWNrZXIuYXV0b3J1bihmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgc2VxID0gc2VxdWVuY2VGdW5jKCk7XG5cbiAgICAgIFRyYWNrZXIubm9ucmVhY3RpdmUoZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgc2VxQXJyYXk7IC8vIHNhbWUgc3RydWN0dXJlIGFzIGBsYXN0U2VxQXJyYXlgIGFib3ZlLlxuXG4gICAgICAgIGlmIChhY3RpdmVPYnNlcnZlSGFuZGxlKSB7XG4gICAgICAgICAgLy8gSWYgd2Ugd2VyZSBwcmV2aW91c2x5IG9ic2VydmluZyBhIGN1cnNvciwgcmVwbGFjZSBsYXN0U2VxQXJyYXkgd2l0aFxuICAgICAgICAgIC8vIG1vcmUgdXAtdG8tZGF0ZSBpbmZvcm1hdGlvbi4gIFRoZW4gc3RvcCB0aGUgb2xkIG9ic2VydmUuXG4gICAgICAgICAgbGFzdFNlcUFycmF5ID0gbGFzdFNlcS5mZXRjaCgpLm1hcChmdW5jdGlvbiAoZG9jKSB7XG4gICAgICAgICAgICByZXR1cm4ge19pZDogZG9jLl9pZCwgaXRlbTogZG9jfTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBhY3RpdmVPYnNlcnZlSGFuZGxlLnN0b3AoKTtcbiAgICAgICAgICBhY3RpdmVPYnNlcnZlSGFuZGxlID0gbnVsbDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghc2VxKSB7XG4gICAgICAgICAgc2VxQXJyYXkgPSBzZXFDaGFuZ2VkVG9FbXB0eShsYXN0U2VxQXJyYXksIGNhbGxiYWNrcyk7XG4gICAgICAgIH0gZWxzZSBpZiAoaXNBcnJheShzZXEpKSB7XG4gICAgICAgICAgc2VxQXJyYXkgPSBzZXFDaGFuZ2VkVG9BcnJheShsYXN0U2VxQXJyYXksIHNlcSwgY2FsbGJhY2tzKTtcbiAgICAgICAgfSBlbHNlIGlmIChpc1N0b3JlQ3Vyc29yKHNlcSkpIHtcbiAgICAgICAgICB2YXIgcmVzdWx0IC8qIFtzZXFBcnJheSwgYWN0aXZlT2JzZXJ2ZUhhbmRsZV0gKi8gPVxuICAgICAgICAgICAgICAgIHNlcUNoYW5nZWRUb0N1cnNvcihsYXN0U2VxQXJyYXksIHNlcSwgY2FsbGJhY2tzKTtcbiAgICAgICAgICBzZXFBcnJheSA9IHJlc3VsdFswXTtcbiAgICAgICAgICBhY3RpdmVPYnNlcnZlSGFuZGxlID0gcmVzdWx0WzFdO1xuICAgICAgICB9IGVsc2UgaWYgKGlzSXRlcmFibGUoc2VxKSkge1xuICAgICAgICAgIGNvbnN0IGFycmF5ID0gQXJyYXkuZnJvbShzZXEpO1xuICAgICAgICAgIHNlcUFycmF5ID0gc2VxQ2hhbmdlZFRvQXJyYXkobGFzdFNlcUFycmF5LCBhcnJheSwgY2FsbGJhY2tzKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aHJvdyBiYWRTZXF1ZW5jZUVycm9yKHNlcSk7XG4gICAgICAgIH1cblxuICAgICAgICBkaWZmQXJyYXkobGFzdFNlcUFycmF5LCBzZXFBcnJheSwgY2FsbGJhY2tzKTtcbiAgICAgICAgbGFzdFNlcSA9IHNlcTtcbiAgICAgICAgbGFzdFNlcUFycmF5ID0gc2VxQXJyYXk7XG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIHJldHVybiB7XG4gICAgICBzdG9wOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNvbXB1dGF0aW9uLnN0b3AoKTtcbiAgICAgICAgaWYgKGFjdGl2ZU9ic2VydmVIYW5kbGUpXG4gICAgICAgICAgYWN0aXZlT2JzZXJ2ZUhhbmRsZS5zdG9wKCk7XG4gICAgICB9XG4gICAgfTtcbiAgfSxcblxuICAvLyBGZXRjaCB0aGUgaXRlbXMgb2YgYHNlcWAgaW50byBhbiBhcnJheSwgd2hlcmUgYHNlcWAgaXMgb2Ygb25lIG9mIHRoZVxuICAvLyBzZXF1ZW5jZSB0eXBlcyBhY2NlcHRlZCBieSBgb2JzZXJ2ZWAuICBJZiBgc2VxYCBpcyBhIGN1cnNvciwgYVxuICAvLyBkZXBlbmRlbmN5IGlzIGVzdGFibGlzaGVkLlxuICBmZXRjaDogZnVuY3Rpb24gKHNlcSkge1xuICAgIGlmICghc2VxKSB7XG4gICAgICByZXR1cm4gW107XG4gICAgfSBlbHNlIGlmIChpc0FycmF5KHNlcSkpIHtcbiAgICAgIHJldHVybiBzZXE7XG4gICAgfSBlbHNlIGlmIChpc1N0b3JlQ3Vyc29yKHNlcSkpIHtcbiAgICAgIHJldHVybiBzZXEuZmV0Y2goKTtcbiAgICB9IGVsc2UgaWYgKGlzSXRlcmFibGUoc2VxKSkge1xuICAgICAgcmV0dXJuIEFycmF5LmZyb20oc2VxKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgYmFkU2VxdWVuY2VFcnJvcihzZXEpO1xuICAgIH1cbiAgfVxufTtcblxuZnVuY3Rpb24gZWxsaXBzaXMobG9uZ1N0ciwgbWF4TGVuZ3RoKSB7XG4gIGlmKCFtYXhMZW5ndGgpIG1heExlbmd0aCA9IDEwMDtcbiAgaWYobG9uZ1N0ci5sZW5ndGggPCBtYXhMZW5ndGgpIHJldHVybiBsb25nU3RyO1xuICByZXR1cm4gbG9uZ1N0ci5zdWJzdHIoMCwgbWF4TGVuZ3RoLTEpICsgJ+KApic7XG59XG5cbmZ1bmN0aW9uIGFycmF5VG9EZWJ1Z1N0cih2YWx1ZSwgbWF4TGVuZ3RoKSB7XG4gIHZhciBvdXQgPSAnJywgc2VwID0gJyc7XG4gIGZvcih2YXIgaSA9IDA7IGkgPCB2YWx1ZS5sZW5ndGg7IGkrKykge1xuICAgIHZhciBpdGVtID0gdmFsdWVbaV07XG4gICAgb3V0ICs9IHNlcCArIHRvRGVidWdTdHIoaXRlbSwgbWF4TGVuZ3RoKTtcbiAgICBpZihvdXQubGVuZ3RoID4gbWF4TGVuZ3RoKSByZXR1cm4gb3V0O1xuICAgIHNlcCA9ICcsICc7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gdG9EZWJ1Z1N0cih2YWx1ZSwgbWF4TGVuZ3RoKSB7XG4gIGlmKCFtYXhMZW5ndGgpIG1heExlbmd0aCA9IDE1MDtcbiAgY29uc3QgdHlwZSA9IHR5cGVvZiB2YWx1ZTtcbiAgc3dpdGNoKHR5cGUpIHtcbiAgICBjYXNlICd1bmRlZmluZWQnOlxuICAgICAgcmV0dXJuIHR5cGU7XG4gICAgY2FzZSAnbnVtYmVyJzpcbiAgICAgIHJldHVybiB2YWx1ZS50b1N0cmluZygpO1xuICAgIGNhc2UgJ3N0cmluZyc6XG4gICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpOyAvLyBhZGQgcXVvdGVzXG4gICAgY2FzZSAnb2JqZWN0JzpcbiAgICAgIGlmKHZhbHVlID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiAnbnVsbCc7XG4gICAgICB9IGVsc2UgaWYoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuICdBcnJheSBbJyArIGFycmF5VG9EZWJ1Z1N0cih2YWx1ZSwgbWF4TGVuZ3RoKSArICddJztcbiAgICAgIH0gZWxzZSBpZihTeW1ib2wuaXRlcmF0b3IgaW4gdmFsdWUpIHsgLy8gTWFwIGFuZCBTZXQgYXJlIG5vdCBoYW5kbGVkIGJ5IEpTT04uc3RyaW5naWZ5XG4gICAgICAgIHJldHVybiB2YWx1ZS5jb25zdHJ1Y3Rvci5uYW1lXG4gICAgICAgICAgKyAnIFsnICsgYXJyYXlUb0RlYnVnU3RyKEFycmF5LmZyb20odmFsdWUpLCBtYXhMZW5ndGgpXG4gICAgICAgICAgKyAnXSc7IC8vIEFycmF5LmZyb20gZG9lc24ndCB3b3JrIGluIElFLCBidXQgbmVpdGhlciBkbyBpdGVyYXRvcnMgc28gaXQncyB1bnJlYWNoYWJsZVxuICAgICAgfSBlbHNlIHsgLy8gdXNlIEpTT04uc3RyaW5naWZ5IChzb21ldGltZXMgdG9TdHJpbmcgY2FuIGJlIGJldHRlciBidXQgd2UgZG9uJ3Qga25vdylcbiAgICAgICAgcmV0dXJuIHZhbHVlLmNvbnN0cnVjdG9yLm5hbWUgKyAnICdcbiAgICAgICAgICAgICArIGVsbGlwc2lzKEpTT04uc3RyaW5naWZ5KHZhbHVlKSwgbWF4TGVuZ3RoKTtcbiAgICAgIH1cbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHR5cGUgKyAnOiAnICsgdmFsdWUudG9TdHJpbmcoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBzZXF1ZW5jZUdvdFZhbHVlKHNlcXVlbmNlKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuICcgR290ICcgKyB0b0RlYnVnU3RyKHNlcXVlbmNlKTtcbiAgfSBjYXRjaChlKSB7XG4gICAgcmV0dXJuICcnXG4gIH1cbn1cblxuY29uc3QgYmFkU2VxdWVuY2VFcnJvciA9IGZ1bmN0aW9uIChzZXF1ZW5jZSkge1xuICByZXR1cm4gbmV3IEVycm9yKFwie3sjZWFjaH19IGN1cnJlbnRseSBvbmx5IGFjY2VwdHMgXCIgK1xuICAgICAgICAgICAgICAgICAgIFwiYXJyYXlzLCBjdXJzb3JzLCBpdGVyYWJsZXMgb3IgZmFsc2V5IHZhbHVlcy5cIiArXG4gICAgICAgICAgICAgICAgICAgc2VxdWVuY2VHb3RWYWx1ZShzZXF1ZW5jZSkpO1xufTtcblxuY29uc3QgaXNGdW5jdGlvbiA9IChmdW5jKSA9PiB7XG4gIHJldHVybiB0eXBlb2YgZnVuYyA9PT0gXCJmdW5jdGlvblwiO1xufVxuXG5jb25zdCBpc1N0b3JlQ3Vyc29yID0gZnVuY3Rpb24gKGN1cnNvcikge1xuICByZXR1cm4gY3Vyc29yICYmIGlzT2JqZWN0KGN1cnNvcikgJiZcbiAgICBpc0Z1bmN0aW9uKGN1cnNvci5vYnNlcnZlKSAmJiBpc0Z1bmN0aW9uKGN1cnNvci5mZXRjaCk7XG59O1xuXG4vLyBDYWxjdWxhdGVzIHRoZSBkaWZmZXJlbmNlcyBiZXR3ZWVuIGBsYXN0U2VxQXJyYXlgIGFuZFxuLy8gYHNlcUFycmF5YCBhbmQgY2FsbHMgYXBwcm9wcmlhdGUgZnVuY3Rpb25zIGZyb20gYGNhbGxiYWNrc2AuXG4vLyBSZXVzZXMgTWluaW1vbmdvJ3MgZGlmZiBhbGdvcml0aG0gaW1wbGVtZW50YXRpb24uXG5jb25zdCBkaWZmQXJyYXkgPSBmdW5jdGlvbiAobGFzdFNlcUFycmF5LCBzZXFBcnJheSwgY2FsbGJhY2tzKSB7XG4gIHZhciBkaWZmRm4gPSBQYWNrYWdlWydkaWZmLXNlcXVlbmNlJ10uRGlmZlNlcXVlbmNlLmRpZmZRdWVyeU9yZGVyZWRDaGFuZ2VzO1xuICB2YXIgb2xkSWRPYmplY3RzID0gW107XG4gIHZhciBuZXdJZE9iamVjdHMgPSBbXTtcbiAgdmFyIHBvc09sZCA9IHt9OyAvLyBtYXBzIGZyb20gaWRTdHJpbmdpZnknZCBpZHNcbiAgdmFyIHBvc05ldyA9IHt9OyAvLyBkaXR0b1xuICB2YXIgcG9zQ3VyID0ge307XG4gIHZhciBsZW5ndGhDdXIgPSBsYXN0U2VxQXJyYXkubGVuZ3RoO1xuXG4gIHNlcUFycmF5LmZvckVhY2goZnVuY3Rpb24gKGRvYywgaSkge1xuICAgIG5ld0lkT2JqZWN0cy5wdXNoKHtfaWQ6IGRvYy5faWR9KTtcbiAgICBwb3NOZXdbaWRTdHJpbmdpZnkoZG9jLl9pZCldID0gaTtcbiAgfSk7XG4gIGxhc3RTZXFBcnJheS5mb3JFYWNoKGZ1bmN0aW9uIChkb2MsIGkpIHtcbiAgICBvbGRJZE9iamVjdHMucHVzaCh7X2lkOiBkb2MuX2lkfSk7XG4gICAgcG9zT2xkW2lkU3RyaW5naWZ5KGRvYy5faWQpXSA9IGk7XG4gICAgcG9zQ3VyW2lkU3RyaW5naWZ5KGRvYy5faWQpXSA9IGk7XG4gIH0pO1xuXG4gIC8vIEFycmF5cyBjYW4gY29udGFpbiBhcmJpdHJhcnkgb2JqZWN0cy4gV2UgZG9uJ3QgZGlmZiB0aGVcbiAgLy8gb2JqZWN0cy4gSW5zdGVhZCB3ZSBhbHdheXMgZmlyZSAnY2hhbmdlZEF0JyBjYWxsYmFjayBvbiBldmVyeVxuICAvLyBvYmplY3QuIFRoZSBjb25zdW1lciBvZiBgb2JzZXJ2ZS1zZXF1ZW5jZWAgc2hvdWxkIGRlYWwgd2l0aFxuICAvLyBpdCBhcHByb3ByaWF0ZWx5LlxuICBkaWZmRm4ob2xkSWRPYmplY3RzLCBuZXdJZE9iamVjdHMsIHtcbiAgICBhZGRlZEJlZm9yZTogZnVuY3Rpb24gKGlkLCBkb2MsIGJlZm9yZSkge1xuICAgICAgdmFyIHBvc2l0aW9uID0gYmVmb3JlID8gcG9zQ3VyW2lkU3RyaW5naWZ5KGJlZm9yZSldIDogbGVuZ3RoQ3VyO1xuXG4gICAgICBpZiAoYmVmb3JlKSB7XG4gICAgICAgIC8vIElmIG5vdCBhZGRpbmcgYXQgdGhlIGVuZCwgd2UgbmVlZCB0byB1cGRhdGUgaW5kZXhlcy5cbiAgICAgICAgLy8gWFhYIHRoaXMgY2FuIHN0aWxsIGJlIGltcHJvdmVkIGdyZWF0bHkhXG4gICAgICAgIE9iamVjdC5lbnRyaWVzKHBvc0N1cikuZm9yRWFjaChmdW5jdGlvbiAoW2lkLCBwb3NdKSB7XG4gICAgICAgICAgaWYgKHBvcyA+PSBwb3NpdGlvbilcbiAgICAgICAgICAgIHBvc0N1cltpZF0rKztcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGxlbmd0aEN1cisrO1xuICAgICAgcG9zQ3VyW2lkU3RyaW5naWZ5KGlkKV0gPSBwb3NpdGlvbjtcblxuICAgICAgY2FsbGJhY2tzLmFkZGVkQXQoXG4gICAgICAgIGlkLFxuICAgICAgICBzZXFBcnJheVtwb3NOZXdbaWRTdHJpbmdpZnkoaWQpXV0uaXRlbSxcbiAgICAgICAgcG9zaXRpb24sXG4gICAgICAgIGJlZm9yZSk7XG4gICAgfSxcbiAgICBtb3ZlZEJlZm9yZTogZnVuY3Rpb24gKGlkLCBiZWZvcmUpIHtcbiAgICAgIGlmIChpZCA9PT0gYmVmb3JlKVxuICAgICAgICByZXR1cm47XG5cbiAgICAgIHZhciBvbGRQb3NpdGlvbiA9IHBvc0N1cltpZFN0cmluZ2lmeShpZCldO1xuICAgICAgdmFyIG5ld1Bvc2l0aW9uID0gYmVmb3JlID8gcG9zQ3VyW2lkU3RyaW5naWZ5KGJlZm9yZSldIDogbGVuZ3RoQ3VyO1xuXG4gICAgICAvLyBNb3ZpbmcgdGhlIGl0ZW0gZm9yd2FyZC4gVGhlIG5ldyBlbGVtZW50IGlzIGxvc2luZyBvbmUgcG9zaXRpb24gYXMgaXRcbiAgICAgIC8vIHdhcyByZW1vdmVkIGZyb20gdGhlIG9sZCBwb3NpdGlvbiBiZWZvcmUgYmVpbmcgaW5zZXJ0ZWQgYXQgdGhlIG5ld1xuICAgICAgLy8gcG9zaXRpb24uXG4gICAgICAvLyBFeC46ICAgMCAgKjEqICAyICAgMyAgIDRcbiAgICAgIC8vICAgICAgICAwICAgMiAgIDMgICoxKiAgNFxuICAgICAgLy8gVGhlIG9yaWdpbmFsIGlzc3VlZCBjYWxsYmFjayBpcyBcIjFcIiBiZWZvcmUgXCI0XCIuXG4gICAgICAvLyBUaGUgcG9zaXRpb24gb2YgXCIxXCIgaXMgMSwgdGhlIHBvc2l0aW9uIG9mIFwiNFwiIGlzIDQuXG4gICAgICAvLyBUaGUgZ2VuZXJhdGVkIG1vdmUgaXMgKDEpIC0+ICgzKVxuICAgICAgaWYgKG5ld1Bvc2l0aW9uID4gb2xkUG9zaXRpb24pIHtcbiAgICAgICAgbmV3UG9zaXRpb24tLTtcbiAgICAgIH1cblxuICAgICAgLy8gRml4IHVwIHRoZSBwb3NpdGlvbnMgb2YgZWxlbWVudHMgYmV0d2VlbiB0aGUgb2xkIGFuZCB0aGUgbmV3IHBvc2l0aW9uc1xuICAgICAgLy8gb2YgdGhlIG1vdmVkIGVsZW1lbnQuXG4gICAgICAvL1xuICAgICAgLy8gVGhlcmUgYXJlIHR3byBjYXNlczpcbiAgICAgIC8vICAgMS4gVGhlIGVsZW1lbnQgaXMgbW92ZWQgZm9yd2FyZC4gVGhlbiBhbGwgdGhlIHBvc2l0aW9ucyBpbiBiZXR3ZWVuXG4gICAgICAvLyAgIGFyZSBtb3ZlZCBiYWNrLlxuICAgICAgLy8gICAyLiBUaGUgZWxlbWVudCBpcyBtb3ZlZCBiYWNrLiBUaGVuIHRoZSBwb3NpdGlvbnMgaW4gYmV0d2VlbiAqYW5kKiB0aGVcbiAgICAgIC8vICAgZWxlbWVudCB0aGF0IGlzIGN1cnJlbnRseSBzdGFuZGluZyBvbiB0aGUgbW92ZWQgZWxlbWVudCdzIGZ1dHVyZVxuICAgICAgLy8gICBwb3NpdGlvbiBhcmUgbW92ZWQgZm9yd2FyZC5cbiAgICAgIE9iamVjdC5lbnRyaWVzKHBvc0N1cikuZm9yRWFjaChmdW5jdGlvbiAoW2lkLCBlbEN1clBvc2l0aW9uXSkge1xuICAgICAgICBpZiAob2xkUG9zaXRpb24gPCBlbEN1clBvc2l0aW9uICYmIGVsQ3VyUG9zaXRpb24gPCBuZXdQb3NpdGlvbilcbiAgICAgICAgICBwb3NDdXJbaWRdLS07XG4gICAgICAgIGVsc2UgaWYgKG5ld1Bvc2l0aW9uIDw9IGVsQ3VyUG9zaXRpb24gJiYgZWxDdXJQb3NpdGlvbiA8IG9sZFBvc2l0aW9uKVxuICAgICAgICAgIHBvc0N1cltpZF0rKztcbiAgICAgIH0pO1xuXG4gICAgICAvLyBGaW5hbGx5LCB1cGRhdGUgdGhlIHBvc2l0aW9uIG9mIHRoZSBtb3ZlZCBlbGVtZW50LlxuICAgICAgcG9zQ3VyW2lkU3RyaW5naWZ5KGlkKV0gPSBuZXdQb3NpdGlvbjtcblxuICAgICAgY2FsbGJhY2tzLm1vdmVkVG8oXG4gICAgICAgIGlkLFxuICAgICAgICBzZXFBcnJheVtwb3NOZXdbaWRTdHJpbmdpZnkoaWQpXV0uaXRlbSxcbiAgICAgICAgb2xkUG9zaXRpb24sXG4gICAgICAgIG5ld1Bvc2l0aW9uLFxuICAgICAgICBiZWZvcmUpO1xuICAgIH0sXG4gICAgcmVtb3ZlZDogZnVuY3Rpb24gKGlkKSB7XG4gICAgICB2YXIgcHJldlBvc2l0aW9uID0gcG9zQ3VyW2lkU3RyaW5naWZ5KGlkKV07XG5cbiAgICAgIE9iamVjdC5lbnRyaWVzKHBvc0N1cikuZm9yRWFjaChmdW5jdGlvbiAoW2lkLCBwb3NdKSB7XG4gICAgICAgIGlmIChwb3MgPj0gcHJldlBvc2l0aW9uKVxuICAgICAgICAgIHBvc0N1cltpZF0tLTtcbiAgICAgIH0pO1xuXG4gICAgICBkZWxldGUgcG9zQ3VyW2lkU3RyaW5naWZ5KGlkKV07XG4gICAgICBsZW5ndGhDdXItLTtcblxuICAgICAgY2FsbGJhY2tzLnJlbW92ZWRBdChcbiAgICAgICAgaWQsXG4gICAgICAgIGxhc3RTZXFBcnJheVtwb3NPbGRbaWRTdHJpbmdpZnkoaWQpXV0uaXRlbSxcbiAgICAgICAgcHJldlBvc2l0aW9uKTtcbiAgICB9XG4gIH0pO1xuICBcbiAgT2JqZWN0LmVudHJpZXMocG9zTmV3KS5mb3JFYWNoKGZ1bmN0aW9uIChbaWRTdHJpbmcsIHBvc10pIHtcblxuICAgIHZhciBpZCA9IGlkUGFyc2UoaWRTdHJpbmcpO1xuICAgIFxuICAgIGlmIChoYXMocG9zT2xkLCBpZFN0cmluZykpIHtcbiAgICAgIC8vIHNwZWNpZmljYWxseSBmb3IgcHJpbWl0aXZlIHR5cGVzLCBjb21wYXJlIGVxdWFsaXR5IGJlZm9yZVxuICAgICAgLy8gZmlyaW5nIHRoZSAnY2hhbmdlZEF0JyBjYWxsYmFjay4gb3RoZXJ3aXNlLCBhbHdheXMgZmlyZSBpdFxuICAgICAgLy8gYmVjYXVzZSBkb2luZyBhIGRlZXAgRUpTT04gY29tcGFyaXNvbiBpcyBub3QgZ3VhcmFudGVlZCB0b1xuICAgICAgLy8gd29yayAoYW4gYXJyYXkgY2FuIGNvbnRhaW4gYXJiaXRyYXJ5IG9iamVjdHMsIGFuZCAndHJhbnNmb3JtJ1xuICAgICAgLy8gY2FuIGJlIHVzZWQgb24gY3Vyc29ycykuIGFsc28sIGRlZXAgZGlmZmluZyBpcyBub3RcbiAgICAgIC8vIG5lY2Vzc2FyaWx5IHRoZSBtb3N0IGVmZmljaWVudCAoaWYgb25seSBhIHNwZWNpZmljIHN1YmZpZWxkXG4gICAgICAvLyBvZiB0aGUgb2JqZWN0IGlzIGxhdGVyIGFjY2Vzc2VkKS5cbiAgICAgIHZhciBuZXdJdGVtID0gc2VxQXJyYXlbcG9zXS5pdGVtO1xuICAgICAgdmFyIG9sZEl0ZW0gPSBsYXN0U2VxQXJyYXlbcG9zT2xkW2lkU3RyaW5nXV0uaXRlbTtcblxuICAgICAgaWYgKHR5cGVvZiBuZXdJdGVtID09PSAnb2JqZWN0JyB8fCBuZXdJdGVtICE9PSBvbGRJdGVtKVxuICAgICAgICAgIGNhbGxiYWNrcy5jaGFuZ2VkQXQoaWQsIG5ld0l0ZW0sIG9sZEl0ZW0sIHBvcyk7XG4gICAgICB9XG4gIH0pO1xufTtcblxuc2VxQ2hhbmdlZFRvRW1wdHkgPSBmdW5jdGlvbiAobGFzdFNlcUFycmF5LCBjYWxsYmFja3MpIHtcbiAgcmV0dXJuIFtdO1xufTtcblxuc2VxQ2hhbmdlZFRvQXJyYXkgPSBmdW5jdGlvbiAobGFzdFNlcUFycmF5LCBhcnJheSwgY2FsbGJhY2tzKSB7XG4gIHZhciBpZHNVc2VkID0ge307XG4gIHZhciBzZXFBcnJheSA9IGFycmF5Lm1hcChmdW5jdGlvbiAoaXRlbSwgaW5kZXgpIHtcbiAgICB2YXIgaWQ7XG4gICAgaWYgKHR5cGVvZiBpdGVtID09PSAnc3RyaW5nJykge1xuICAgICAgLy8gZW5zdXJlIG5vdCBlbXB0eSwgc2luY2Ugb3RoZXIgbGF5ZXJzIChlZyBEb21SYW5nZSkgYXNzdW1lIHRoaXMgYXMgd2VsbFxuICAgICAgaWQgPSBcIi1cIiArIGl0ZW07XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgaXRlbSA9PT0gJ251bWJlcicgfHxcbiAgICAgICAgICAgICAgIHR5cGVvZiBpdGVtID09PSAnYm9vbGVhbicgfHxcbiAgICAgICAgICAgICAgIGl0ZW0gPT09IHVuZGVmaW5lZCB8fFxuICAgICAgICAgICAgICAgaXRlbSA9PT0gbnVsbCkge1xuICAgICAgaWQgPSBpdGVtO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIGl0ZW0gPT09ICdvYmplY3QnKSB7XG4gICAgICBpZCA9IChpdGVtICYmICgnX2lkJyBpbiBpdGVtKSkgPyBpdGVtLl9pZCA6IGluZGV4O1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJ7eyNlYWNofX0gZG9lc24ndCBzdXBwb3J0IGFycmF5cyB3aXRoIFwiICtcbiAgICAgICAgICAgICAgICAgICAgICBcImVsZW1lbnRzIG9mIHR5cGUgXCIgKyB0eXBlb2YgaXRlbSk7XG4gICAgfVxuXG4gICAgdmFyIGlkU3RyaW5nID0gaWRTdHJpbmdpZnkoaWQpO1xuICAgIGlmIChpZHNVc2VkW2lkU3RyaW5nXSkge1xuICAgICAgaWYgKGl0ZW0gJiYgdHlwZW9mIGl0ZW0gPT09ICdvYmplY3QnICYmICdfaWQnIGluIGl0ZW0pXG4gICAgICAgIHdhcm4oXCJkdXBsaWNhdGUgaWQgXCIgKyBpZCArIFwiIGluXCIsIGFycmF5KTtcbiAgICAgIGlkID0gUmFuZG9tLmlkKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlkc1VzZWRbaWRTdHJpbmddID0gdHJ1ZTtcbiAgICB9XG5cbiAgICByZXR1cm4geyBfaWQ6IGlkLCBpdGVtOiBpdGVtIH07XG4gIH0pO1xuXG4gIHJldHVybiBzZXFBcnJheTtcbn07XG5cbnNlcUNoYW5nZWRUb0N1cnNvciA9IGZ1bmN0aW9uIChsYXN0U2VxQXJyYXksIGN1cnNvciwgY2FsbGJhY2tzKSB7XG4gIHZhciBpbml0aWFsID0gdHJ1ZTsgLy8gYXJlIHdlIG9ic2VydmluZyBpbml0aWFsIGRhdGEgZnJvbSBjdXJzb3I/XG4gIHZhciBzZXFBcnJheSA9IFtdO1xuXG4gIHZhciBvYnNlcnZlSGFuZGxlID0gY3Vyc29yLm9ic2VydmUoe1xuICAgIGFkZGVkQXQ6IGZ1bmN0aW9uIChkb2N1bWVudCwgYXRJbmRleCwgYmVmb3JlKSB7XG4gICAgICBpZiAoaW5pdGlhbCkge1xuICAgICAgICAvLyBrZWVwIHRyYWNrIG9mIGluaXRpYWwgZGF0YSBzbyB0aGF0IHdlIGNhbiBkaWZmIG9uY2VcbiAgICAgICAgLy8gd2UgZXhpdCBgb2JzZXJ2ZWAuXG4gICAgICAgIGlmIChiZWZvcmUgIT09IG51bGwpXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgaW5pdGlhbCBkYXRhIGZyb20gb2JzZXJ2ZSBpbiBvcmRlclwiKTtcbiAgICAgICAgc2VxQXJyYXkucHVzaCh7IF9pZDogZG9jdW1lbnQuX2lkLCBpdGVtOiBkb2N1bWVudCB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNhbGxiYWNrcy5hZGRlZEF0KGRvY3VtZW50Ll9pZCwgZG9jdW1lbnQsIGF0SW5kZXgsIGJlZm9yZSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBjaGFuZ2VkQXQ6IGZ1bmN0aW9uIChuZXdEb2N1bWVudCwgb2xkRG9jdW1lbnQsIGF0SW5kZXgpIHtcbiAgICAgIGNhbGxiYWNrcy5jaGFuZ2VkQXQobmV3RG9jdW1lbnQuX2lkLCBuZXdEb2N1bWVudCwgb2xkRG9jdW1lbnQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGF0SW5kZXgpO1xuICAgIH0sXG4gICAgcmVtb3ZlZEF0OiBmdW5jdGlvbiAob2xkRG9jdW1lbnQsIGF0SW5kZXgpIHtcbiAgICAgIGNhbGxiYWNrcy5yZW1vdmVkQXQob2xkRG9jdW1lbnQuX2lkLCBvbGREb2N1bWVudCwgYXRJbmRleCk7XG4gICAgfSxcbiAgICBtb3ZlZFRvOiBmdW5jdGlvbiAoZG9jdW1lbnQsIGZyb21JbmRleCwgdG9JbmRleCwgYmVmb3JlKSB7XG4gICAgICBjYWxsYmFja3MubW92ZWRUbyhcbiAgICAgICAgZG9jdW1lbnQuX2lkLCBkb2N1bWVudCwgZnJvbUluZGV4LCB0b0luZGV4LCBiZWZvcmUpO1xuICAgIH1cbiAgfSk7XG4gIGluaXRpYWwgPSBmYWxzZTtcblxuICByZXR1cm4gW3NlcUFycmF5LCBvYnNlcnZlSGFuZGxlXTtcbn07XG4iXX0=
