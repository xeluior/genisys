var require = meteorInstall({"api":{"clients":{"server":{"methods.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// api/clients/server/methods.js                                                                                    //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }
}, 1);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 2);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }
}, 3);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 4);
const {
  exec
} = require('child_process');
Meteor.methods({
  "Clients.Provision": function (clientId, playbook) {
    check(clientId, Mongo.ObjectID);
    const client = ClientsCollection.findOne({
      _id: clientId
    });
    if (!client) {
      throw new Meteor.Error("client-not-found", "That client doesn't exist.");
    }

    // Reading inventory file and adding hostname to inventory file
    fs.readFile('inventory', 'utf8', function (err, fileContent) {
      if (err) {
        console.error("Error reading file: ".concat(err));
        return;
      }

      // Check if the hostname is in the file 
      if (fileContent.includes(client.hostname)) {
        console.log("".concat(client.hostname, " already exists in the file."));
      } else {
        // If 'client.hostname' is not in the file, add it to the end of the file
        fileContent += "".concat(client.hostname, " ansible_host=").concat(client.ip, "\n");

        // Write the modified content back to the file
        fs.writeFile('inventory', fileContent, 'utf8', function (err) {
          if (err) {
            console.error("Error writing to file: ".concat(err));
            return;
          }
          console.log("".concat(client.hostname, " added to the file."));
          console.log("Content of file: ".concat(fileContent));
        });
      }
    });

    // Running Ansible command
    const command = "ansible-playbook -i inventory ".concat(playbook, " --limit \"").concat(client.hostname, "\"");
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error("Error executing command: ".concat(error.message));
        return;
      }
      if (stderr) {
        console.error("Command stderr: ".concat(stderr));
        return;
      }
      console.log("Command stdout: ".concat(stdout));
    });

    // Update client's provisioned status
    ClientsCollection.update({
      _id: clientId
    }, {
      $set: {
        provisioned: true,
        provisionedAt: new Date()
      }
    });
    return {
      status: 200,
      message: "".concat(client.hostname, " successfully provisioned")
    };
  }
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// api/clients/server/publications.js                                                                               //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 1);
let PlaybooksCollection;
module.link("../playbooks", {
  PlaybooksCollection(v) {
    PlaybooksCollection = v;
  }
}, 2);
Meteor.publish('Clients', function () {
  return ClientsCollection.find();
});
Meteor.publish('Playbooks', function () {
  return PlaybooksCollection.find();
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"clients.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// api/clients/clients.js                                                                                           //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  ClientsCollection: () => ClientsCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 0);
const ClientsCollection = new Mongo.Collection('ClientsCollection');
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"playbooks.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// api/clients/playbooks.js                                                                                         //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  PlaybooksCollection: () => PlaybooksCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 0);
const PlaybooksCollection = new Mongo.Collection('PlaybooksCollection');
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                  //
// server/main.js                                                                                                   //
//                                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                    //
module.export({
  CONFIG_FILE: () => CONFIG_FILE
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let ClientsCollection;
module.link("../api/clients/clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 1);
let PlaybooksCollection;
module.link("../api/clients/playbooks", {
  PlaybooksCollection(v) {
    PlaybooksCollection = v;
  }
}, 2);
module.link("../api/clients/server/publications");
module.link("../api/clients/server/methods");
const yaml = require("js-yaml");
const fs = require("fs");
const CONFIG_FILE_VAR = process.env.CONFIG_FILE || "/etc/genisys.yaml";
const CONFIG_FILE = yaml.load(fs.readFileSync(String(CONFIG_FILE_VAR), "utf8"));
// const temp_yaml_string = `---
// ansible:
//   inventory: /var/genisys/inventory
//   ssh-key: /etc/genisys/ssh/id_rsa
//   playbooks:
//     - /etc/genisys/playbooks/firstrun.yaml
//     - /etc/genisys/playbooks/script2.yaml`

// export const CONFIG_FILE = yaml.load(temp_yaml_string)

Meteor.startup(() => {
  console.log("Meteor Started");
  PlaybooksCollection.dropCollectionAsync();
  CONFIG_FILE["ansible"]["playbooks"].forEach(element => {
    obj = {
      playbook: element
    };
    PlaybooksCollection.insert(obj);
  });

  //Creating Inventory file
  fs.access("inventory", fs.constants.F_OK, err => {
    if (err) {
      console.log("inventory does not exist, creating now");
      fs.writeFileSync("inventory", "[all_hosts]\n");
    } else {
      console.log("inventory exists");
    }
  });
});
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".mjs"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvYXBpL2NsaWVudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL2NsaWVudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL3BsYXlib29rcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwibGluayIsInYiLCJjaGVjayIsIkNsaWVudHNDb2xsZWN0aW9uIiwiZnMiLCJkZWZhdWx0IiwiTW9uZ28iLCJleGVjIiwicmVxdWlyZSIsIm1ldGhvZHMiLCJDbGllbnRzLlByb3Zpc2lvbiIsImNsaWVudElkIiwicGxheWJvb2siLCJPYmplY3RJRCIsImNsaWVudCIsImZpbmRPbmUiLCJfaWQiLCJFcnJvciIsInJlYWRGaWxlIiwiZXJyIiwiZmlsZUNvbnRlbnQiLCJjb25zb2xlIiwiZXJyb3IiLCJjb25jYXQiLCJpbmNsdWRlcyIsImhvc3RuYW1lIiwibG9nIiwiaXAiLCJ3cml0ZUZpbGUiLCJjb21tYW5kIiwic3Rkb3V0Iiwic3RkZXJyIiwibWVzc2FnZSIsInVwZGF0ZSIsIiRzZXQiLCJwcm92aXNpb25lZCIsInByb3Zpc2lvbmVkQXQiLCJEYXRlIiwic3RhdHVzIiwiUGxheWJvb2tzQ29sbGVjdGlvbiIsInB1Ymxpc2giLCJmaW5kIiwiZXhwb3J0IiwiQ29sbGVjdGlvbiIsIkNPTkZJR19GSUxFIiwieWFtbCIsIkNPTkZJR19GSUxFX1ZBUiIsInByb2Nlc3MiLCJlbnYiLCJsb2FkIiwicmVhZEZpbGVTeW5jIiwiU3RyaW5nIiwic3RhcnR1cCIsImRyb3BDb2xsZWN0aW9uQXN5bmMiLCJmb3JFYWNoIiwiZWxlbWVudCIsIm9iaiIsImluc2VydCIsImFjY2VzcyIsImNvbnN0YW50cyIsIkZfT0siLCJ3cml0ZUZpbGVTeW5jIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLE1BQU07QUFBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUMsZUFBZSxFQUFDO0VBQUNGLE1BQU1BLENBQUNHLENBQUMsRUFBQztJQUFDSCxNQUFNLEdBQUNHLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJQyxLQUFLO0FBQUNILE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDRSxLQUFLQSxDQUFDRCxDQUFDLEVBQUM7SUFBQ0MsS0FBSyxHQUFDRCxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUUsaUJBQWlCO0FBQUNKLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLFlBQVksRUFBQztFQUFDRyxpQkFBaUJBLENBQUNGLENBQUMsRUFBQztJQUFDRSxpQkFBaUIsR0FBQ0YsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlHLEVBQUU7QUFBQ0wsTUFBTSxDQUFDQyxJQUFJLENBQUMsSUFBSSxFQUFDO0VBQUNLLE9BQU9BLENBQUNKLENBQUMsRUFBQztJQUFDRyxFQUFFLEdBQUNILENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJSyxLQUFLO0FBQUNQLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDTSxLQUFLQSxDQUFDTCxDQUFDLEVBQUM7SUFBQ0ssS0FBSyxHQUFDTCxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBSW5VLE1BQU07RUFBRU07QUFBSyxDQUFDLEdBQUdDLE9BQU8sQ0FBQyxlQUFlLENBQUM7QUFHekNWLE1BQU0sQ0FBQ1csT0FBTyxDQUFDO0VBQ2IsbUJBQW1CLEVBQUUsU0FBQUMsQ0FBVUMsUUFBUSxFQUFFQyxRQUFRLEVBQUU7SUFDakRWLEtBQUssQ0FBQ1MsUUFBUSxFQUFFTCxLQUFLLENBQUNPLFFBQVEsQ0FBQztJQUUvQixNQUFNQyxNQUFNLEdBQUdYLGlCQUFpQixDQUFDWSxPQUFPLENBQUM7TUFDdkNDLEdBQUcsRUFBRUw7SUFDUCxDQUFDLENBQUM7SUFFRixJQUFJLENBQUNHLE1BQU0sRUFBRTtNQUNYLE1BQU0sSUFBSWhCLE1BQU0sQ0FBQ21CLEtBQUssQ0FBQyxrQkFBa0IsRUFBRSw0QkFBNEIsQ0FBQztJQUMxRTs7SUFJQTtJQUNBYixFQUFFLENBQUNjLFFBQVEsQ0FBQyxXQUFXLEVBQUUsTUFBTSxFQUFFLFVBQVVDLEdBQUcsRUFBRUMsV0FBVyxFQUFFO01BQ3pELElBQUlELEdBQUcsRUFBRTtRQUNMRSxPQUFPLENBQUNDLEtBQUssd0JBQUFDLE1BQUEsQ0FBd0JKLEdBQUcsQ0FBRSxDQUFDO1FBQzNDO01BQ0o7O01BRUE7TUFDQSxJQUFJQyxXQUFXLENBQUNJLFFBQVEsQ0FBQ1YsTUFBTSxDQUFDVyxRQUFRLENBQUMsRUFBRTtRQUN2Q0osT0FBTyxDQUFDSyxHQUFHLElBQUFILE1BQUEsQ0FBSVQsTUFBTSxDQUFDVyxRQUFRLGlDQUE4QixDQUFDO01BQ2pFLENBQUMsTUFBTTtRQUNIO1FBQ0FMLFdBQVcsT0FBQUcsTUFBQSxDQUFPVCxNQUFNLENBQUNXLFFBQVEsb0JBQUFGLE1BQUEsQ0FBaUJULE1BQU0sQ0FBQ2EsRUFBRSxPQUFJOztRQUUvRDtRQUNBdkIsRUFBRSxDQUFDd0IsU0FBUyxDQUFDLFdBQVcsRUFBRVIsV0FBVyxFQUFFLE1BQU0sRUFBRSxVQUFVRCxHQUFHLEVBQUU7VUFDMUQsSUFBSUEsR0FBRyxFQUFFO1lBQ0xFLE9BQU8sQ0FBQ0MsS0FBSywyQkFBQUMsTUFBQSxDQUEyQkosR0FBRyxDQUFFLENBQUM7WUFDOUM7VUFDSjtVQUNBRSxPQUFPLENBQUNLLEdBQUcsSUFBQUgsTUFBQSxDQUFJVCxNQUFNLENBQUNXLFFBQVEsd0JBQXFCLENBQUM7VUFDcERKLE9BQU8sQ0FBQ0ssR0FBRyxxQkFBQUgsTUFBQSxDQUFxQkgsV0FBVyxDQUFFLENBQUM7UUFDbEQsQ0FBQyxDQUFDO01BQ047SUFDSixDQUFDLENBQUM7O0lBRUY7SUFDQSxNQUFNUyxPQUFPLG9DQUFBTixNQUFBLENBQW9DWCxRQUFRLGlCQUFBVyxNQUFBLENBQWFULE1BQU0sQ0FBQ1csUUFBUSxPQUFHO0lBQ3hGbEIsSUFBSSxDQUFDc0IsT0FBTyxFQUFFLENBQUNQLEtBQUssRUFBRVEsTUFBTSxFQUFFQyxNQUFNLEtBQUs7TUFDckMsSUFBSVQsS0FBSyxFQUFFO1FBQ1BELE9BQU8sQ0FBQ0MsS0FBSyw2QkFBQUMsTUFBQSxDQUE2QkQsS0FBSyxDQUFDVSxPQUFPLENBQUUsQ0FBQztRQUMxRDtNQUNKO01BQ0EsSUFBSUQsTUFBTSxFQUFFO1FBQ1JWLE9BQU8sQ0FBQ0MsS0FBSyxvQkFBQUMsTUFBQSxDQUFvQlEsTUFBTSxDQUFFLENBQUM7UUFDMUM7TUFDSjtNQUNBVixPQUFPLENBQUNLLEdBQUcsb0JBQUFILE1BQUEsQ0FBb0JPLE1BQU0sQ0FBRSxDQUFDO0lBQzVDLENBQUMsQ0FBQzs7SUFFRjtJQUNBM0IsaUJBQWlCLENBQUM4QixNQUFNLENBQ3RCO01BQ0VqQixHQUFHLEVBQUVMO0lBQ1AsQ0FBQyxFQUNEO01BQ0V1QixJQUFJLEVBQUU7UUFDSkMsV0FBVyxFQUFFLElBQUk7UUFDakJDLGFBQWEsRUFBRSxJQUFJQyxJQUFJLENBQUM7TUFDMUI7SUFDRixDQUNGLENBQUM7SUFDRCxPQUFPO01BQ0xDLE1BQU0sRUFBRSxHQUFHO01BQ1hOLE9BQU8sS0FBQVQsTUFBQSxDQUFLVCxNQUFNLENBQUNXLFFBQVE7SUFDN0IsQ0FBQztFQUNIO0FBQ0YsQ0FBQyxDQUFDLEM7Ozs7Ozs7Ozs7O0FDOUVGLElBQUkzQixNQUFNO0FBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGVBQWUsRUFBQztFQUFDRixNQUFNQSxDQUFDRyxDQUFDLEVBQUM7SUFBQ0gsTUFBTSxHQUFDRyxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUUsaUJBQWlCO0FBQUNKLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLFlBQVksRUFBQztFQUFDRyxpQkFBaUJBLENBQUNGLENBQUMsRUFBQztJQUFDRSxpQkFBaUIsR0FBQ0YsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlzQyxtQkFBbUI7QUFBQ3hDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDdUMsbUJBQW1CQSxDQUFDdEMsQ0FBQyxFQUFDO0lBQUNzQyxtQkFBbUIsR0FBQ3RDLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFJblFILE1BQU0sQ0FBQzBDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsWUFBVztFQUNqQyxPQUFPckMsaUJBQWlCLENBQUNzQyxJQUFJLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUM7QUFFRjNDLE1BQU0sQ0FBQzBDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsWUFBVztFQUNuQyxPQUFPRCxtQkFBbUIsQ0FBQ0UsSUFBSSxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLEM7Ozs7Ozs7Ozs7O0FDVkYxQyxNQUFNLENBQUMyQyxNQUFNLENBQUM7RUFBQ3ZDLGlCQUFpQixFQUFDQSxDQUFBLEtBQUlBO0FBQWlCLENBQUMsQ0FBQztBQUFDLElBQUlHLEtBQUs7QUFBQ1AsTUFBTSxDQUFDQyxJQUFJLENBQUMsY0FBYyxFQUFDO0VBQUNNLEtBQUtBLENBQUNMLENBQUMsRUFBQztJQUFDSyxLQUFLLEdBQUNMLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFFN0csTUFBTUUsaUJBQWlCLEdBQUcsSUFBSUcsS0FBSyxDQUFDcUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLEM7Ozs7Ozs7Ozs7O0FDRjFFNUMsTUFBTSxDQUFDMkMsTUFBTSxDQUFDO0VBQUNILG1CQUFtQixFQUFDQSxDQUFBLEtBQUlBO0FBQW1CLENBQUMsQ0FBQztBQUFDLElBQUlqQyxLQUFLO0FBQUNQLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDTSxLQUFLQSxDQUFDTCxDQUFDLEVBQUM7SUFBQ0ssS0FBSyxHQUFDTCxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBRWpILE1BQU1zQyxtQkFBbUIsR0FBRyxJQUFJakMsS0FBSyxDQUFDcUMsVUFBVSxDQUFDLHFCQUFxQixDQUFDLEM7Ozs7Ozs7Ozs7O0FDRjlFNUMsTUFBTSxDQUFDMkMsTUFBTSxDQUFDO0VBQUNFLFdBQVcsRUFBQ0EsQ0FBQSxLQUFJQTtBQUFXLENBQUMsQ0FBQztBQUFDLElBQUk5QyxNQUFNO0FBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGVBQWUsRUFBQztFQUFDRixNQUFNQSxDQUFDRyxDQUFDLEVBQUM7SUFBQ0gsTUFBTSxHQUFDRyxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUUsaUJBQWlCO0FBQUNKLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLHdCQUF3QixFQUFDO0VBQUNHLGlCQUFpQkEsQ0FBQ0YsQ0FBQyxFQUFDO0lBQUNFLGlCQUFpQixHQUFDRixDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSXNDLG1CQUFtQjtBQUFDeEMsTUFBTSxDQUFDQyxJQUFJLENBQUMsMEJBQTBCLEVBQUM7RUFBQ3VDLG1CQUFtQkEsQ0FBQ3RDLENBQUMsRUFBQztJQUFDc0MsbUJBQW1CLEdBQUN0QyxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUNGLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLG9DQUFvQyxDQUFDO0FBQUNELE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLCtCQUErQixDQUFDO0FBTXZhLE1BQU02QyxJQUFJLEdBQUdyQyxPQUFPLENBQUMsU0FBUyxDQUFDO0FBQy9CLE1BQU1KLEVBQUUsR0FBR0ksT0FBTyxDQUFDLElBQUksQ0FBQztBQUV4QixNQUFNc0MsZUFBZSxHQUFHQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0osV0FBVyxJQUFJLG1CQUFtQjtBQUMvRCxNQUFNQSxXQUFXLEdBQUdDLElBQUksQ0FBQ0ksSUFBSSxDQUNsQzdDLEVBQUUsQ0FBQzhDLFlBQVksQ0FBQ0MsTUFBTSxDQUFDTCxlQUFlLENBQUMsRUFBRSxNQUFNLENBQ2pELENBQUM7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQWhELE1BQU0sQ0FBQ3NELE9BQU8sQ0FBQyxNQUFNO0VBQ25CL0IsT0FBTyxDQUFDSyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7RUFFN0JhLG1CQUFtQixDQUFDYyxtQkFBbUIsQ0FBQyxDQUFDO0VBRXpDVCxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUNVLE9BQU8sQ0FBRUMsT0FBTyxJQUFLO0lBQ3ZEQyxHQUFHLEdBQUc7TUFBRTVDLFFBQVEsRUFBRTJDO0lBQVEsQ0FBQztJQUMzQmhCLG1CQUFtQixDQUFDa0IsTUFBTSxDQUFDRCxHQUFHLENBQUM7RUFDakMsQ0FBQyxDQUFDOztFQUVGO0VBQ0FwRCxFQUFFLENBQUNzRCxNQUFNLENBQUMsV0FBVyxFQUFFdEQsRUFBRSxDQUFDdUQsU0FBUyxDQUFDQyxJQUFJLEVBQUd6QyxHQUFHLElBQUs7SUFDakQsSUFBSUEsR0FBRyxFQUFFO01BQ1BFLE9BQU8sQ0FBQ0ssR0FBRyx5Q0FBeUMsQ0FBQztNQUNyRHRCLEVBQUUsQ0FBQ3lELGFBQWEsQ0FBQyxXQUFXLEVBQUUsZUFBZSxDQUFDO0lBQ2hELENBQUMsTUFBTTtNQUNMeEMsT0FBTyxDQUFDSyxHQUFHLG1CQUFtQixDQUFDO0lBQ2pDO0VBQ0YsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCJcclxuaW1wb3J0IHsgY2hlY2sgfSBmcm9tIFwibWV0ZW9yL2NoZWNrXCJcclxuaW1wb3J0IHsgQ2xpZW50c0NvbGxlY3Rpb24gfSBmcm9tIFwiLi4vY2xpZW50c1wiXHJcbmltcG9ydCBmcyBmcm9tIFwiZnNcIlxyXG5jb25zdCB7IGV4ZWMgfSA9IHJlcXVpcmUoJ2NoaWxkX3Byb2Nlc3MnKVxyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcbiAgXCJDbGllbnRzLlByb3Zpc2lvblwiOiBmdW5jdGlvbiAoY2xpZW50SWQsIHBsYXlib29rKSB7XHJcbiAgICBjaGVjayhjbGllbnRJZCwgTW9uZ28uT2JqZWN0SUQpXHJcblxyXG4gICAgY29uc3QgY2xpZW50ID0gQ2xpZW50c0NvbGxlY3Rpb24uZmluZE9uZSh7XHJcbiAgICAgIF9pZDogY2xpZW50SWQsXHJcbiAgICB9KVxyXG5cclxuICAgIGlmICghY2xpZW50KSB7XHJcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoXCJjbGllbnQtbm90LWZvdW5kXCIsIFwiVGhhdCBjbGllbnQgZG9lc24ndCBleGlzdC5cIilcclxuICAgIH1cclxuXHJcblxyXG5cclxuICAgIC8vIFJlYWRpbmcgaW52ZW50b3J5IGZpbGUgYW5kIGFkZGluZyBob3N0bmFtZSB0byBpbnZlbnRvcnkgZmlsZVxyXG4gICAgZnMucmVhZEZpbGUoJ2ludmVudG9yeScsICd1dGY4JywgZnVuY3Rpb24gKGVyciwgZmlsZUNvbnRlbnQpIHtcclxuICAgICAgICBpZiAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHJlYWRpbmcgZmlsZTogJHtlcnJ9YCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICBcclxuICAgICAgICAvLyBDaGVjayBpZiB0aGUgaG9zdG5hbWUgaXMgaW4gdGhlIGZpbGUgXHJcbiAgICAgICAgaWYgKGZpbGVDb250ZW50LmluY2x1ZGVzKGNsaWVudC5ob3N0bmFtZSkpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coYCR7Y2xpZW50Lmhvc3RuYW1lfSBhbHJlYWR5IGV4aXN0cyBpbiB0aGUgZmlsZS5gKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvLyBJZiAnY2xpZW50Lmhvc3RuYW1lJyBpcyBub3QgaW4gdGhlIGZpbGUsIGFkZCBpdCB0byB0aGUgZW5kIG9mIHRoZSBmaWxlXHJcbiAgICAgICAgICAgIGZpbGVDb250ZW50ICs9IGAke2NsaWVudC5ob3N0bmFtZX0gYW5zaWJsZV9ob3N0PSR7Y2xpZW50LmlwfVxcbmA7XHJcbiAgICBcclxuICAgICAgICAgICAgLy8gV3JpdGUgdGhlIG1vZGlmaWVkIGNvbnRlbnQgYmFjayB0byB0aGUgZmlsZVxyXG4gICAgICAgICAgICBmcy53cml0ZUZpbGUoJ2ludmVudG9yeScsIGZpbGVDb250ZW50LCAndXRmOCcsIGZ1bmN0aW9uIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciB3cml0aW5nIHRvIGZpbGU6ICR7ZXJyfWApO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke2NsaWVudC5ob3N0bmFtZX0gYWRkZWQgdG8gdGhlIGZpbGUuYCk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgQ29udGVudCBvZiBmaWxlOiAke2ZpbGVDb250ZW50fWApXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIC8vIFJ1bm5pbmcgQW5zaWJsZSBjb21tYW5kXHJcbiAgICBjb25zdCBjb21tYW5kID0gYGFuc2libGUtcGxheWJvb2sgLWkgaW52ZW50b3J5ICR7cGxheWJvb2t9IC0tbGltaXQgXCIke2NsaWVudC5ob3N0bmFtZX1cImBcclxuICAgIGV4ZWMoY29tbWFuZCwgKGVycm9yLCBzdGRvdXQsIHN0ZGVycikgPT4ge1xyXG4gICAgICAgIGlmIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBleGVjdXRpbmcgY29tbWFuZDogJHtlcnJvci5tZXNzYWdlfWApO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChzdGRlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgQ29tbWFuZCBzdGRlcnI6ICR7c3RkZXJyfWApO1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnNvbGUubG9nKGBDb21tYW5kIHN0ZG91dDogJHtzdGRvdXR9YCk7XHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyBVcGRhdGUgY2xpZW50J3MgcHJvdmlzaW9uZWQgc3RhdHVzXHJcbiAgICBDbGllbnRzQ29sbGVjdGlvbi51cGRhdGUoXHJcbiAgICAgIHtcclxuICAgICAgICBfaWQ6IGNsaWVudElkLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgcHJvdmlzaW9uZWQ6IHRydWUsXHJcbiAgICAgICAgICBwcm92aXNpb25lZEF0OiBuZXcgRGF0ZSgpLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHN0YXR1czogMjAwLFxyXG4gICAgICBtZXNzYWdlOiBgJHtjbGllbnQuaG9zdG5hbWV9IHN1Y2Nlc3NmdWxseSBwcm92aXNpb25lZGAsXHJcbiAgICB9XHJcbiAgfVxyXG59KVxyXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHsgQ2xpZW50c0NvbGxlY3Rpb24gfSBmcm9tICcuLi9jbGllbnRzJztcclxuaW1wb3J0IHsgUGxheWJvb2tzQ29sbGVjdGlvbiB9IGZyb20gJy4uL3BsYXlib29rcyc7XHJcblxyXG5NZXRlb3IucHVibGlzaCgnQ2xpZW50cycsIGZ1bmN0aW9uKCkge1xyXG4gICAgcmV0dXJuIENsaWVudHNDb2xsZWN0aW9uLmZpbmQoKVxyXG59KVxyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ1BsYXlib29rcycsIGZ1bmN0aW9uKCkge1xyXG4gICAgcmV0dXJuIFBsYXlib29rc0NvbGxlY3Rpb24uZmluZCgpXHJcbn0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5cclxuZXhwb3J0IGNvbnN0IENsaWVudHNDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ0NsaWVudHNDb2xsZWN0aW9uJyk7IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5cclxuZXhwb3J0IGNvbnN0IFBsYXlib29rc0NvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignUGxheWJvb2tzQ29sbGVjdGlvbicpIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIlxyXG5pbXBvcnQgeyBDbGllbnRzQ29sbGVjdGlvbiB9IGZyb20gXCIuLi9hcGkvY2xpZW50cy9jbGllbnRzXCJcclxuaW1wb3J0IHsgUGxheWJvb2tzQ29sbGVjdGlvbiB9IGZyb20gXCIuLi9hcGkvY2xpZW50cy9wbGF5Ym9va3NcIlxyXG5pbXBvcnQgXCIuLi9hcGkvY2xpZW50cy9zZXJ2ZXIvcHVibGljYXRpb25zXCJcclxuaW1wb3J0IFwiLi4vYXBpL2NsaWVudHMvc2VydmVyL21ldGhvZHNcIlxyXG5cclxuY29uc3QgeWFtbCA9IHJlcXVpcmUoXCJqcy15YW1sXCIpXHJcbmNvbnN0IGZzID0gcmVxdWlyZShcImZzXCIpXHJcblxyXG5jb25zdCBDT05GSUdfRklMRV9WQVIgPSBwcm9jZXNzLmVudi5DT05GSUdfRklMRSB8fCBcIi9ldGMvZ2VuaXN5cy55YW1sXCJcclxuZXhwb3J0IGNvbnN0IENPTkZJR19GSUxFID0geWFtbC5sb2FkKFxyXG4gIGZzLnJlYWRGaWxlU3luYyhTdHJpbmcoQ09ORklHX0ZJTEVfVkFSKSwgXCJ1dGY4XCIpXHJcbilcclxuXHJcbi8vIGNvbnN0IHRlbXBfeWFtbF9zdHJpbmcgPSBgLS0tXHJcbi8vIGFuc2libGU6XHJcbi8vICAgaW52ZW50b3J5OiAvdmFyL2dlbmlzeXMvaW52ZW50b3J5XHJcbi8vICAgc3NoLWtleTogL2V0Yy9nZW5pc3lzL3NzaC9pZF9yc2FcclxuLy8gICBwbGF5Ym9va3M6XHJcbi8vICAgICAtIC9ldGMvZ2VuaXN5cy9wbGF5Ym9va3MvZmlyc3RydW4ueWFtbFxyXG4vLyAgICAgLSAvZXRjL2dlbmlzeXMvcGxheWJvb2tzL3NjcmlwdDIueWFtbGBcclxuXHJcbi8vIGV4cG9ydCBjb25zdCBDT05GSUdfRklMRSA9IHlhbWwubG9hZCh0ZW1wX3lhbWxfc3RyaW5nKVxyXG5cclxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKFwiTWV0ZW9yIFN0YXJ0ZWRcIilcclxuXHJcbiAgUGxheWJvb2tzQ29sbGVjdGlvbi5kcm9wQ29sbGVjdGlvbkFzeW5jKClcclxuXHJcbiAgQ09ORklHX0ZJTEVbXCJhbnNpYmxlXCJdW1wicGxheWJvb2tzXCJdLmZvckVhY2goKGVsZW1lbnQpID0+IHtcclxuICAgIG9iaiA9IHsgcGxheWJvb2s6IGVsZW1lbnQgfVxyXG4gICAgUGxheWJvb2tzQ29sbGVjdGlvbi5pbnNlcnQob2JqKVxyXG4gIH0pXHJcblxyXG4gIC8vQ3JlYXRpbmcgSW52ZW50b3J5IGZpbGVcclxuICBmcy5hY2Nlc3MoXCJpbnZlbnRvcnlcIiwgZnMuY29uc3RhbnRzLkZfT0ssIChlcnIpID0+IHtcclxuICAgIGlmIChlcnIpIHtcclxuICAgICAgY29uc29sZS5sb2coYGludmVudG9yeSBkb2VzIG5vdCBleGlzdCwgY3JlYXRpbmcgbm93YClcclxuICAgICAgZnMud3JpdGVGaWxlU3luYyhcImludmVudG9yeVwiLCBcIlthbGxfaG9zdHNdXFxuXCIpXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zb2xlLmxvZyhgaW52ZW50b3J5IGV4aXN0c2ApXHJcbiAgICB9XHJcbiAgfSlcclxufSlcclxuIl19
