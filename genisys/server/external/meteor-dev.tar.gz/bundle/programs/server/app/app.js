var require = meteorInstall({"api":{"clients":{"server":{"methods.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// api/clients/server/methods.js                                                             //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }
}, 1);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 2);
let AnsibleCollection;
module.link("../ansible", {
  AnsibleCollection(v) {
    AnsibleCollection = v;
  }
}, 3);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }
}, 4);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 5);
const {
  spawn
} = require("child_process");
Meteor.methods({
  "Clients.Provision": function (clientId, playbook) {
    // check(clientId, Mongo.ObjectID)

    const client = ClientsCollection.findOne({
      _id: clientId
    });
    if (!client) {
      throw new Meteor.Error("client-not-found", "That client doesn't exist.");
    }
    if (playbook.localeCompare('None') === 0) {
      throw new Meteor.Error("invalid-playbook", "Please select a playbook to run.");
    }

    // Reading inventory file and adding hostname to inventory file
    fs.readFile("inventory", "utf8", function (err, fileContent) {
      if (err) {
        console.error("Error reading file: ".concat(err));
        return;
      }

      // Check if the hostname is in the file
      if (fileContent.includes(client.hostname)) {
        console.log("".concat(client.hostname, " already exists in the file."));
      } else {
        // If 'client.hostname' is not in the file, add it to the end of the file
        fileContent += "".concat(client.hostname, " ansible_host=").concat(client.ip, "\n");

        // Write the modified content back to the file
        fs.writeFile("inventory", fileContent, "utf8", function (err) {
          if (err) {
            console.error("Error writing to file: ".concat(err));
            return;
          }
          console.log("".concat(client.hostname, " added to the file."));
          console.log("Content of file: ".concat(fileContent));
        });
      }
    });

    // Building Ansible command
    // let command = `ansible-playbook -i inventory ${playbook} --limit "${client.hostname}" --ssh-common-args '-o StrictHostKeyChecking=no' --user root`

    let command = 'ansible-playbook';
    let cmd_args = ["-i", "inventory", "".concat(playbook), "--limit", "\"".concat(client.hostname, "\""), "--ssh-common-args", "'-o StrictHostKeyChecking=no'", "--user", "root"];

    // If key found, append to command
    const ansibleObject = AnsibleCollection.findOne({
      "ssh-key": {
        $exists: true
      }
    });
    if (ansibleObject) {
      // command += ` --private-key ${ansibleObject["ssh-key"]}`
      cmd_args.push("--private-key", "".concat(ansibleObject["ssh-key"]));
    }
    const commandResult = spawn(command, cmd_args).on('error', function (err) {
      throw err;
    });
    commandResult.stdout.on("data", function (data) {
      console.log("stdout", data);
    });
    commandResult.stderr.on("data", function (data) {
      console.error(data);
      return {
        status: 400,
        message: "".concat(client.hostname, " failed provisioning")
      };
    });
    commandResult.on("close", code => {
      console.log("ansible-playbook returned with code ".concat(code));
    });

    // Update client's provisioned status
    ClientsCollection.update({
      _id: clientId
    }, {
      $set: {
        provisioned: true,
        provisionedAt: new Date()
      }
    });
    return {
      status: 200,
      message: "".concat(client.hostname, " successfully provisioned")
    };
  },
  "Clients.RemoveHost": function (clientId) {
    ClientsCollection.remove({
      _id: clientId
    });
  },
  "RefreshConfig": function () {}
});
///////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// api/clients/server/publications.js                                                        //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 1);
let PlaybooksCollection;
module.link("../playbooks", {
  PlaybooksCollection(v) {
    PlaybooksCollection = v;
  }
}, 2);
let AnsibleCollection;
module.link("../ansible", {
  AnsibleCollection(v) {
    AnsibleCollection = v;
  }
}, 3);
Meteor.publish('Clients', function () {
  return ClientsCollection.find();
});
Meteor.publish('Playbooks', function () {
  return PlaybooksCollection.find();
});
Meteor.publish('Ansible', function () {
  return AnsibleCollection.find();
});
///////////////////////////////////////////////////////////////////////////////////////////////

}},"ansible.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// api/clients/ansible.js                                                                    //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
module.export({
  AnsibleCollection: () => AnsibleCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 0);
const AnsibleCollection = new Mongo.Collection('AnsibleCollection');
///////////////////////////////////////////////////////////////////////////////////////////////

},"clients.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// api/clients/clients.js                                                                    //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
module.export({
  ClientsCollection: () => ClientsCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 0);
const ClientsCollection = new Mongo.Collection('ClientsCollection');
///////////////////////////////////////////////////////////////////////////////////////////////

},"playbooks.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// api/clients/playbooks.js                                                                  //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
module.export({
  PlaybooksCollection: () => PlaybooksCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 0);
const PlaybooksCollection = new Mongo.Collection('PlaybooksCollection');
///////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// server/main.js                                                                            //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
module.export({
  CONFIG_FILE: () => CONFIG_FILE
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let PlaybooksCollection;
module.link("../api/clients/playbooks", {
  PlaybooksCollection(v) {
    PlaybooksCollection = v;
  }
}, 1);
let AnsibleCollection;
module.link("../api/clients/ansible", {
  AnsibleCollection(v) {
    AnsibleCollection = v;
  }
}, 2);
module.link("../api/clients/server/publications");
module.link("../api/clients/server/methods");
const yaml = require("js-yaml");
const fs = require("fs");
const CONFIG_FILE_VAR = process.env.CONFIG_FILE || "/etc/genisys.yaml";
const CONFIG_FILE = yaml.load(fs.readFileSync(String(CONFIG_FILE_VAR), "utf8"));
// const temp_yaml_string = `---
// ansible:
//   inventory: /var/genisys/inventory
//   ssh-key: /etc/genisys/ssh/id_rsa
//   playbooks:
//     - /etc/genisys/playbooks/firstrun.yaml
//     - /etc/genisys/playbooks/script2.yaml`

// export const CONFIG_FILE = yaml.load(temp_yaml_string)

Meteor.startup(() => {
  console.log("Meteor Started");
  PlaybooksCollection.dropCollectionAsync();
  AnsibleCollection.dropCollectionAsync();

  // Load playbooks into Mongo
  CONFIG_FILE["ansible"]["playbooks"].forEach(element => {
    obj = {
      playbook: element
    };
    PlaybooksCollection.insert(obj);
  });

  // Putting ansible SSH key into mongo collection for usage on client
  if (CONFIG_FILE["ansible"]["ssh-key"]) {
    obj = {
      "ssh-key": CONFIG_FILE["ansible"]["ssh-key"]
    };
    AnsibleCollection.insert(obj);
  }

  //Creating Inventory file
  fs.access("inventory", fs.constants.F_OK, err => {
    if (err) {
      console.log("inventory does not exist, creating now");
      fs.writeFileSync("inventory", "[all_hosts]\n");
    } else {
      console.log("inventory exists");
    }
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".mjs"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvYXBpL2NsaWVudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL2Fuc2libGUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL2NsaWVudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL3BsYXlib29rcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwibGluayIsInYiLCJjaGVjayIsIkNsaWVudHNDb2xsZWN0aW9uIiwiQW5zaWJsZUNvbGxlY3Rpb24iLCJmcyIsImRlZmF1bHQiLCJNb25nbyIsInNwYXduIiwicmVxdWlyZSIsIm1ldGhvZHMiLCJDbGllbnRzLlByb3Zpc2lvbiIsImNsaWVudElkIiwicGxheWJvb2siLCJjbGllbnQiLCJmaW5kT25lIiwiX2lkIiwiRXJyb3IiLCJsb2NhbGVDb21wYXJlIiwicmVhZEZpbGUiLCJlcnIiLCJmaWxlQ29udGVudCIsImNvbnNvbGUiLCJlcnJvciIsImNvbmNhdCIsImluY2x1ZGVzIiwiaG9zdG5hbWUiLCJsb2ciLCJpcCIsIndyaXRlRmlsZSIsImNvbW1hbmQiLCJjbWRfYXJncyIsImFuc2libGVPYmplY3QiLCIkZXhpc3RzIiwicHVzaCIsImNvbW1hbmRSZXN1bHQiLCJvbiIsInN0ZG91dCIsImRhdGEiLCJzdGRlcnIiLCJzdGF0dXMiLCJtZXNzYWdlIiwiY29kZSIsInVwZGF0ZSIsIiRzZXQiLCJwcm92aXNpb25lZCIsInByb3Zpc2lvbmVkQXQiLCJEYXRlIiwiQ2xpZW50cy5SZW1vdmVIb3N0IiwicmVtb3ZlIiwiUmVmcmVzaENvbmZpZyIsIlBsYXlib29rc0NvbGxlY3Rpb24iLCJwdWJsaXNoIiwiZmluZCIsImV4cG9ydCIsIkNvbGxlY3Rpb24iLCJDT05GSUdfRklMRSIsInlhbWwiLCJDT05GSUdfRklMRV9WQVIiLCJwcm9jZXNzIiwiZW52IiwibG9hZCIsInJlYWRGaWxlU3luYyIsIlN0cmluZyIsInN0YXJ0dXAiLCJkcm9wQ29sbGVjdGlvbkFzeW5jIiwiZm9yRWFjaCIsImVsZW1lbnQiLCJvYmoiLCJpbnNlcnQiLCJhY2Nlc3MiLCJjb25zdGFudHMiLCJGX09LIiwid3JpdGVGaWxlU3luYyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFNO0FBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGVBQWUsRUFBQztFQUFDRixNQUFNQSxDQUFDRyxDQUFDLEVBQUM7SUFBQ0gsTUFBTSxHQUFDRyxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUMsS0FBSztBQUFDSCxNQUFNLENBQUNDLElBQUksQ0FBQyxjQUFjLEVBQUM7RUFBQ0UsS0FBS0EsQ0FBQ0QsQ0FBQyxFQUFDO0lBQUNDLEtBQUssR0FBQ0QsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlFLGlCQUFpQjtBQUFDSixNQUFNLENBQUNDLElBQUksQ0FBQyxZQUFZLEVBQUM7RUFBQ0csaUJBQWlCQSxDQUFDRixDQUFDLEVBQUM7SUFBQ0UsaUJBQWlCLEdBQUNGLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJRyxpQkFBaUI7QUFBQ0wsTUFBTSxDQUFDQyxJQUFJLENBQUMsWUFBWSxFQUFDO0VBQUNJLGlCQUFpQkEsQ0FBQ0gsQ0FBQyxFQUFDO0lBQUNHLGlCQUFpQixHQUFDSCxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUksRUFBRTtBQUFDTixNQUFNLENBQUNDLElBQUksQ0FBQyxJQUFJLEVBQUM7RUFBQ00sT0FBT0EsQ0FBQ0wsQ0FBQyxFQUFDO0lBQUNJLEVBQUUsR0FBQ0osQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlNLEtBQUs7QUFBQ1IsTUFBTSxDQUFDQyxJQUFJLENBQUMsY0FBYyxFQUFDO0VBQUNPLEtBQUtBLENBQUNOLENBQUMsRUFBQztJQUFDTSxLQUFLLEdBQUNOLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFLamEsTUFBTTtFQUFFTztBQUFNLENBQUMsR0FBR0MsT0FBTyxDQUFDLGVBQWUsQ0FBQztBQUcxQ1gsTUFBTSxDQUFDWSxPQUFPLENBQUM7RUFDYixtQkFBbUIsRUFBRSxTQUFBQyxDQUFVQyxRQUFRLEVBQUVDLFFBQVEsRUFBRTtJQUNqRDs7SUFFQSxNQUFNQyxNQUFNLEdBQUdYLGlCQUFpQixDQUFDWSxPQUFPLENBQUM7TUFDdkNDLEdBQUcsRUFBRUo7SUFDUCxDQUFDLENBQUM7SUFFRixJQUFJLENBQUNFLE1BQU0sRUFBRTtNQUNYLE1BQU0sSUFBSWhCLE1BQU0sQ0FBQ21CLEtBQUssQ0FBQyxrQkFBa0IsRUFBRSw0QkFBNEIsQ0FBQztJQUMxRTtJQUVBLElBQUlKLFFBQVEsQ0FBQ0ssYUFBYSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFDeEM7TUFDRSxNQUFNLElBQUlwQixNQUFNLENBQUNtQixLQUFLLENBQUMsa0JBQWtCLEVBQUUsa0NBQWtDLENBQUM7SUFDaEY7O0lBRUE7SUFDQVosRUFBRSxDQUFDYyxRQUFRLENBQUMsV0FBVyxFQUFFLE1BQU0sRUFBRSxVQUFVQyxHQUFHLEVBQUVDLFdBQVcsRUFBRTtNQUMzRCxJQUFJRCxHQUFHLEVBQUU7UUFDUEUsT0FBTyxDQUFDQyxLQUFLLHdCQUFBQyxNQUFBLENBQXdCSixHQUFHLENBQUUsQ0FBQztRQUMzQztNQUNGOztNQUVBO01BQ0EsSUFBSUMsV0FBVyxDQUFDSSxRQUFRLENBQUNYLE1BQU0sQ0FBQ1ksUUFBUSxDQUFDLEVBQUU7UUFDekNKLE9BQU8sQ0FBQ0ssR0FBRyxJQUFBSCxNQUFBLENBQUlWLE1BQU0sQ0FBQ1ksUUFBUSxpQ0FBOEIsQ0FBQztNQUMvRCxDQUFDLE1BQU07UUFDTDtRQUNBTCxXQUFXLE9BQUFHLE1BQUEsQ0FBT1YsTUFBTSxDQUFDWSxRQUFRLG9CQUFBRixNQUFBLENBQWlCVixNQUFNLENBQUNjLEVBQUUsT0FBSTs7UUFFL0Q7UUFDQXZCLEVBQUUsQ0FBQ3dCLFNBQVMsQ0FBQyxXQUFXLEVBQUVSLFdBQVcsRUFBRSxNQUFNLEVBQUUsVUFBVUQsR0FBRyxFQUFFO1VBQzVELElBQUlBLEdBQUcsRUFBRTtZQUNQRSxPQUFPLENBQUNDLEtBQUssMkJBQUFDLE1BQUEsQ0FBMkJKLEdBQUcsQ0FBRSxDQUFDO1lBQzlDO1VBQ0Y7VUFDQUUsT0FBTyxDQUFDSyxHQUFHLElBQUFILE1BQUEsQ0FBSVYsTUFBTSxDQUFDWSxRQUFRLHdCQUFxQixDQUFDO1VBQ3BESixPQUFPLENBQUNLLEdBQUcscUJBQUFILE1BQUEsQ0FBcUJILFdBQVcsQ0FBRSxDQUFDO1FBQ2hELENBQUMsQ0FBQztNQUNKO0lBQ0YsQ0FBQyxDQUFDOztJQUVGO0lBQ0E7O0lBRUEsSUFBSVMsT0FBTyxHQUFHLGtCQUFrQjtJQUNoQyxJQUFJQyxRQUFRLEdBQUcsdUJBQUFQLE1BQUEsQ0FBdUJYLFFBQVEsbUJBQUFXLE1BQUEsQ0FBbUJWLE1BQU0sQ0FBQ1ksUUFBUSxnRkFBNEU7O0lBRTVKO0lBQ0EsTUFBTU0sYUFBYSxHQUFHNUIsaUJBQWlCLENBQUNXLE9BQU8sQ0FBQztNQUM5QyxTQUFTLEVBQUU7UUFBRWtCLE9BQU8sRUFBRTtNQUFLO0lBQzdCLENBQUMsQ0FBQztJQUNGLElBQUlELGFBQWEsRUFBRTtNQUNqQjtNQUNBRCxRQUFRLENBQUNHLElBQUkscUJBQUFWLE1BQUEsQ0FBcUJRLGFBQWEsQ0FBQyxTQUFTLENBQUMsQ0FBRSxDQUFDO0lBQy9EO0lBRUEsTUFBTUcsYUFBYSxHQUFHM0IsS0FBSyxDQUFDc0IsT0FBTyxFQUFFQyxRQUFRLENBQUMsQ0FBQ0ssRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFTaEIsR0FBRyxFQUFFO01BQUMsTUFBTUEsR0FBRztJQUFBLENBQUMsQ0FBQztJQUVyRmUsYUFBYSxDQUFDRSxNQUFNLENBQUNELEVBQUUsQ0FBQyxNQUFNLEVBQUUsVUFBVUUsSUFBSSxFQUFFO01BQzlDaEIsT0FBTyxDQUFDSyxHQUFHLENBQUMsUUFBUSxFQUFFVyxJQUFJLENBQUM7SUFDN0IsQ0FBQyxDQUFDO0lBRUZILGFBQWEsQ0FBQ0ksTUFBTSxDQUFDSCxFQUFFLENBQUMsTUFBTSxFQUFFLFVBQVVFLElBQUksRUFBRTtNQUM5Q2hCLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDZSxJQUFJLENBQUM7TUFDbkIsT0FBTztRQUNMRSxNQUFNLEVBQUUsR0FBRztRQUNYQyxPQUFPLEtBQUFqQixNQUFBLENBQUtWLE1BQU0sQ0FBQ1ksUUFBUTtNQUM3QixDQUFDO0lBQ0gsQ0FBQyxDQUFDO0lBRUZTLGFBQWEsQ0FBQ0MsRUFBRSxDQUFDLE9BQU8sRUFBR00sSUFBSSxJQUFLO01BQ2xDcEIsT0FBTyxDQUFDSyxHQUFHLHdDQUFBSCxNQUFBLENBQXdDa0IsSUFBSSxDQUFFLENBQUM7SUFDNUQsQ0FBQyxDQUFDOztJQUVGO0lBQ0F2QyxpQkFBaUIsQ0FBQ3dDLE1BQU0sQ0FDdEI7TUFDRTNCLEdBQUcsRUFBRUo7SUFDUCxDQUFDLEVBQ0Q7TUFDRWdDLElBQUksRUFBRTtRQUNKQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkMsYUFBYSxFQUFFLElBQUlDLElBQUksQ0FBQztNQUMxQjtJQUNGLENBQ0YsQ0FBQztJQUNELE9BQU87TUFDTFAsTUFBTSxFQUFFLEdBQUc7TUFDWEMsT0FBTyxLQUFBakIsTUFBQSxDQUFLVixNQUFNLENBQUNZLFFBQVE7SUFDN0IsQ0FBQztFQUNILENBQUM7RUFDRCxvQkFBb0IsRUFBRSxTQUFBc0IsQ0FBVXBDLFFBQVEsRUFBRTtJQUN4Q1QsaUJBQWlCLENBQUM4QyxNQUFNLENBQUM7TUFBQ2pDLEdBQUcsRUFBRUo7SUFBUSxDQUFDLENBQUM7RUFDM0MsQ0FBQztFQUNELGVBQWUsRUFBRSxTQUFBc0MsQ0FBQSxFQUFZLENBQUM7QUFDaEMsQ0FBQyxDQUFDLEM7Ozs7Ozs7Ozs7O0FDekdGLElBQUlwRCxNQUFNO0FBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGVBQWUsRUFBQztFQUFDRixNQUFNQSxDQUFDRyxDQUFDLEVBQUM7SUFBQ0gsTUFBTSxHQUFDRyxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUUsaUJBQWlCO0FBQUNKLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLFlBQVksRUFBQztFQUFDRyxpQkFBaUJBLENBQUNGLENBQUMsRUFBQztJQUFDRSxpQkFBaUIsR0FBQ0YsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlrRCxtQkFBbUI7QUFBQ3BELE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDbUQsbUJBQW1CQSxDQUFDbEQsQ0FBQyxFQUFDO0lBQUNrRCxtQkFBbUIsR0FBQ2xELENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJRyxpQkFBaUI7QUFBQ0wsTUFBTSxDQUFDQyxJQUFJLENBQUMsWUFBWSxFQUFDO0VBQUNJLGlCQUFpQkEsQ0FBQ0gsQ0FBQyxFQUFDO0lBQUNHLGlCQUFpQixHQUFDSCxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBS2pXSCxNQUFNLENBQUNzRCxPQUFPLENBQUMsU0FBUyxFQUFFLFlBQVc7RUFDakMsT0FBT2pELGlCQUFpQixDQUFDa0QsSUFBSSxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDO0FBRUZ2RCxNQUFNLENBQUNzRCxPQUFPLENBQUMsV0FBVyxFQUFFLFlBQVc7RUFDbkMsT0FBT0QsbUJBQW1CLENBQUNFLElBQUksQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQztBQUVGdkQsTUFBTSxDQUFDc0QsT0FBTyxDQUFDLFNBQVMsRUFBRSxZQUFXO0VBQ2pDLE9BQU9oRCxpQkFBaUIsQ0FBQ2lELElBQUksQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDOzs7Ozs7Ozs7OztBQ2ZGdEQsTUFBTSxDQUFDdUQsTUFBTSxDQUFDO0VBQUNsRCxpQkFBaUIsRUFBQ0EsQ0FBQSxLQUFJQTtBQUFpQixDQUFDLENBQUM7QUFBQyxJQUFJRyxLQUFLO0FBQUNSLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDTyxLQUFLQSxDQUFDTixDQUFDLEVBQUM7SUFBQ00sS0FBSyxHQUFDTixDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBRTdHLE1BQU1HLGlCQUFpQixHQUFHLElBQUlHLEtBQUssQ0FBQ2dELFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxDOzs7Ozs7Ozs7OztBQ0YxRXhELE1BQU0sQ0FBQ3VELE1BQU0sQ0FBQztFQUFDbkQsaUJBQWlCLEVBQUNBLENBQUEsS0FBSUE7QUFBaUIsQ0FBQyxDQUFDO0FBQUMsSUFBSUksS0FBSztBQUFDUixNQUFNLENBQUNDLElBQUksQ0FBQyxjQUFjLEVBQUM7RUFBQ08sS0FBS0EsQ0FBQ04sQ0FBQyxFQUFDO0lBQUNNLEtBQUssR0FBQ04sQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUU3RyxNQUFNRSxpQkFBaUIsR0FBRyxJQUFJSSxLQUFLLENBQUNnRCxVQUFVLENBQUMsbUJBQW1CLENBQUMsQzs7Ozs7Ozs7Ozs7QUNGMUV4RCxNQUFNLENBQUN1RCxNQUFNLENBQUM7RUFBQ0gsbUJBQW1CLEVBQUNBLENBQUEsS0FBSUE7QUFBbUIsQ0FBQyxDQUFDO0FBQUMsSUFBSTVDLEtBQUs7QUFBQ1IsTUFBTSxDQUFDQyxJQUFJLENBQUMsY0FBYyxFQUFDO0VBQUNPLEtBQUtBLENBQUNOLENBQUMsRUFBQztJQUFDTSxLQUFLLEdBQUNOLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFFakgsTUFBTWtELG1CQUFtQixHQUFHLElBQUk1QyxLQUFLLENBQUNnRCxVQUFVLENBQUMscUJBQXFCLENBQUMsQzs7Ozs7Ozs7Ozs7QUNGOUV4RCxNQUFNLENBQUN1RCxNQUFNLENBQUM7RUFBQ0UsV0FBVyxFQUFDQSxDQUFBLEtBQUlBO0FBQVcsQ0FBQyxDQUFDO0FBQUMsSUFBSTFELE1BQU07QUFBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUMsZUFBZSxFQUFDO0VBQUNGLE1BQU1BLENBQUNHLENBQUMsRUFBQztJQUFDSCxNQUFNLEdBQUNHLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJa0QsbUJBQW1CO0FBQUNwRCxNQUFNLENBQUNDLElBQUksQ0FBQywwQkFBMEIsRUFBQztFQUFDbUQsbUJBQW1CQSxDQUFDbEQsQ0FBQyxFQUFDO0lBQUNrRCxtQkFBbUIsR0FBQ2xELENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJRyxpQkFBaUI7QUFBQ0wsTUFBTSxDQUFDQyxJQUFJLENBQUMsd0JBQXdCLEVBQUM7RUFBQ0ksaUJBQWlCQSxDQUFDSCxDQUFDLEVBQUM7SUFBQ0csaUJBQWlCLEdBQUNILENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQ0YsTUFBTSxDQUFDQyxJQUFJLENBQUMsb0NBQW9DLENBQUM7QUFBQ0QsTUFBTSxDQUFDQyxJQUFJLENBQUMsK0JBQStCLENBQUM7QUFNdmEsTUFBTXlELElBQUksR0FBR2hELE9BQU8sQ0FBQyxTQUFTLENBQUM7QUFDL0IsTUFBTUosRUFBRSxHQUFHSSxPQUFPLENBQUMsSUFBSSxDQUFDO0FBRXhCLE1BQU1pRCxlQUFlLEdBQUdDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSixXQUFXLElBQUksbUJBQW1CO0FBQy9ELE1BQU1BLFdBQVcsR0FBR0MsSUFBSSxDQUFDSSxJQUFJLENBQ2xDeEQsRUFBRSxDQUFDeUQsWUFBWSxDQUFDQyxNQUFNLENBQUNMLGVBQWUsQ0FBQyxFQUFFLE1BQU0sQ0FDakQsQ0FBQztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBNUQsTUFBTSxDQUFDa0UsT0FBTyxDQUFDLE1BQU07RUFDbkIxQyxPQUFPLENBQUNLLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztFQUU3QndCLG1CQUFtQixDQUFDYyxtQkFBbUIsQ0FBQyxDQUFDO0VBQ3pDN0QsaUJBQWlCLENBQUM2RCxtQkFBbUIsQ0FBQyxDQUFDOztFQUV2QztFQUNBVCxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUNVLE9BQU8sQ0FBRUMsT0FBTyxJQUFLO0lBQ3ZEQyxHQUFHLEdBQUc7TUFBRXZELFFBQVEsRUFBRXNEO0lBQVEsQ0FBQztJQUMzQmhCLG1CQUFtQixDQUFDa0IsTUFBTSxDQUFDRCxHQUFHLENBQUM7RUFDakMsQ0FBQyxDQUFDOztFQUVGO0VBQ0EsSUFBSVosV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUNyQztJQUNFWSxHQUFHLEdBQUc7TUFBQyxTQUFTLEVBQUVaLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTO0lBQUMsQ0FBQztJQUNwRHBELGlCQUFpQixDQUFDaUUsTUFBTSxDQUFDRCxHQUFHLENBQUM7RUFDL0I7O0VBRUE7RUFDQS9ELEVBQUUsQ0FBQ2lFLE1BQU0sQ0FBQyxXQUFXLEVBQUVqRSxFQUFFLENBQUNrRSxTQUFTLENBQUNDLElBQUksRUFBR3BELEdBQUcsSUFBSztJQUNqRCxJQUFJQSxHQUFHLEVBQUU7TUFDUEUsT0FBTyxDQUFDSyxHQUFHLHlDQUF5QyxDQUFDO01BQ3JEdEIsRUFBRSxDQUFDb0UsYUFBYSxDQUFDLFdBQVcsRUFBRSxlQUFlLENBQUM7SUFDaEQsQ0FBQyxNQUFNO01BQ0xuRCxPQUFPLENBQUNLLEdBQUcsbUJBQW1CLENBQUM7SUFDakM7RUFDRixDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQyIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIlxyXG5pbXBvcnQgeyBjaGVjayB9IGZyb20gXCJtZXRlb3IvY2hlY2tcIlxyXG5pbXBvcnQgeyBDbGllbnRzQ29sbGVjdGlvbiB9IGZyb20gXCIuLi9jbGllbnRzXCJcclxuaW1wb3J0IHsgQW5zaWJsZUNvbGxlY3Rpb24gfSBmcm9tIFwiLi4vYW5zaWJsZVwiXHJcbmltcG9ydCBmcyBmcm9tIFwiZnNcIlxyXG5jb25zdCB7IHNwYXduIH0gPSByZXF1aXJlKFwiY2hpbGRfcHJvY2Vzc1wiKVxyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gXCJtZXRlb3IvbW9uZ29cIlxyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG4gIFwiQ2xpZW50cy5Qcm92aXNpb25cIjogZnVuY3Rpb24gKGNsaWVudElkLCBwbGF5Ym9vaykge1xyXG4gICAgLy8gY2hlY2soY2xpZW50SWQsIE1vbmdvLk9iamVjdElEKVxyXG5cclxuICAgIGNvbnN0IGNsaWVudCA9IENsaWVudHNDb2xsZWN0aW9uLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGNsaWVudElkLFxyXG4gICAgfSlcclxuXHJcbiAgICBpZiAoIWNsaWVudCkge1xyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKFwiY2xpZW50LW5vdC1mb3VuZFwiLCBcIlRoYXQgY2xpZW50IGRvZXNuJ3QgZXhpc3QuXCIpXHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHBsYXlib29rLmxvY2FsZUNvbXBhcmUoJ05vbmUnKSA9PT0gMClcclxuICAgIHtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImludmFsaWQtcGxheWJvb2tcIiwgXCJQbGVhc2Ugc2VsZWN0IGEgcGxheWJvb2sgdG8gcnVuLlwiKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIFJlYWRpbmcgaW52ZW50b3J5IGZpbGUgYW5kIGFkZGluZyBob3N0bmFtZSB0byBpbnZlbnRvcnkgZmlsZVxyXG4gICAgZnMucmVhZEZpbGUoXCJpbnZlbnRvcnlcIiwgXCJ1dGY4XCIsIGZ1bmN0aW9uIChlcnIsIGZpbGVDb250ZW50KSB7XHJcbiAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciByZWFkaW5nIGZpbGU6ICR7ZXJyfWApXHJcbiAgICAgICAgcmV0dXJuXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIENoZWNrIGlmIHRoZSBob3N0bmFtZSBpcyBpbiB0aGUgZmlsZVxyXG4gICAgICBpZiAoZmlsZUNvbnRlbnQuaW5jbHVkZXMoY2xpZW50Lmhvc3RuYW1lKSkge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGAke2NsaWVudC5ob3N0bmFtZX0gYWxyZWFkeSBleGlzdHMgaW4gdGhlIGZpbGUuYClcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICAvLyBJZiAnY2xpZW50Lmhvc3RuYW1lJyBpcyBub3QgaW4gdGhlIGZpbGUsIGFkZCBpdCB0byB0aGUgZW5kIG9mIHRoZSBmaWxlXHJcbiAgICAgICAgZmlsZUNvbnRlbnQgKz0gYCR7Y2xpZW50Lmhvc3RuYW1lfSBhbnNpYmxlX2hvc3Q9JHtjbGllbnQuaXB9XFxuYFxyXG5cclxuICAgICAgICAvLyBXcml0ZSB0aGUgbW9kaWZpZWQgY29udGVudCBiYWNrIHRvIHRoZSBmaWxlXHJcbiAgICAgICAgZnMud3JpdGVGaWxlKFwiaW52ZW50b3J5XCIsIGZpbGVDb250ZW50LCBcInV0ZjhcIiwgZnVuY3Rpb24gKGVycikge1xyXG4gICAgICAgICAgaWYgKGVycikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciB3cml0aW5nIHRvIGZpbGU6ICR7ZXJyfWApXHJcbiAgICAgICAgICAgIHJldHVyblxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgY29uc29sZS5sb2coYCR7Y2xpZW50Lmhvc3RuYW1lfSBhZGRlZCB0byB0aGUgZmlsZS5gKVxyXG4gICAgICAgICAgY29uc29sZS5sb2coYENvbnRlbnQgb2YgZmlsZTogJHtmaWxlQ29udGVudH1gKVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIH0pXHJcblxyXG4gICAgLy8gQnVpbGRpbmcgQW5zaWJsZSBjb21tYW5kXHJcbiAgICAvLyBsZXQgY29tbWFuZCA9IGBhbnNpYmxlLXBsYXlib29rIC1pIGludmVudG9yeSAke3BsYXlib29rfSAtLWxpbWl0IFwiJHtjbGllbnQuaG9zdG5hbWV9XCIgLS1zc2gtY29tbW9uLWFyZ3MgJy1vIFN0cmljdEhvc3RLZXlDaGVja2luZz1ubycgLS11c2VyIHJvb3RgXHJcblxyXG4gICAgbGV0IGNvbW1hbmQgPSAnYW5zaWJsZS1wbGF5Ym9vaydcclxuICAgIGxldCBjbWRfYXJncyA9IFtgLWlgLCBgaW52ZW50b3J5YCwgYCR7cGxheWJvb2t9YCwgYC0tbGltaXRgLCBgXCIke2NsaWVudC5ob3N0bmFtZX1cImAsIGAtLXNzaC1jb21tb24tYXJnc2AsIGAnLW8gU3RyaWN0SG9zdEtleUNoZWNraW5nPW5vJ2AsIGAtLXVzZXJgLCBgcm9vdGBdXHJcblxyXG4gICAgLy8gSWYga2V5IGZvdW5kLCBhcHBlbmQgdG8gY29tbWFuZFxyXG4gICAgY29uc3QgYW5zaWJsZU9iamVjdCA9IEFuc2libGVDb2xsZWN0aW9uLmZpbmRPbmUoe1xyXG4gICAgICBcInNzaC1rZXlcIjogeyAkZXhpc3RzOiB0cnVlIH0sXHJcbiAgICB9KVxyXG4gICAgaWYgKGFuc2libGVPYmplY3QpIHtcclxuICAgICAgLy8gY29tbWFuZCArPSBgIC0tcHJpdmF0ZS1rZXkgJHthbnNpYmxlT2JqZWN0W1wic3NoLWtleVwiXX1gXHJcbiAgICAgIGNtZF9hcmdzLnB1c2goYC0tcHJpdmF0ZS1rZXlgLCBgJHthbnNpYmxlT2JqZWN0W1wic3NoLWtleVwiXX1gKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGNvbW1hbmRSZXN1bHQgPSBzcGF3bihjb21tYW5kLCBjbWRfYXJncykub24oJ2Vycm9yJywgZnVuY3Rpb24oZXJyKSB7dGhyb3cgZXJyfSlcclxuXHJcbiAgICBjb21tYW5kUmVzdWx0LnN0ZG91dC5vbihcImRhdGFcIiwgZnVuY3Rpb24gKGRhdGEpIHtcclxuICAgICAgY29uc29sZS5sb2coXCJzdGRvdXRcIiwgZGF0YSlcclxuICAgIH0pXHJcblxyXG4gICAgY29tbWFuZFJlc3VsdC5zdGRlcnIub24oXCJkYXRhXCIsIGZ1bmN0aW9uIChkYXRhKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoZGF0YSlcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICBzdGF0dXM6IDQwMCxcclxuICAgICAgICBtZXNzYWdlOiBgJHtjbGllbnQuaG9zdG5hbWV9IGZhaWxlZCBwcm92aXNpb25pbmdgLFxyXG4gICAgICB9XHJcbiAgICB9KVxyXG5cclxuICAgIGNvbW1hbmRSZXN1bHQub24oXCJjbG9zZVwiLCAoY29kZSkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhgYW5zaWJsZS1wbGF5Ym9vayByZXR1cm5lZCB3aXRoIGNvZGUgJHtjb2RlfWApXHJcbiAgICB9KVxyXG5cclxuICAgIC8vIFVwZGF0ZSBjbGllbnQncyBwcm92aXNpb25lZCBzdGF0dXNcclxuICAgIENsaWVudHNDb2xsZWN0aW9uLnVwZGF0ZShcclxuICAgICAge1xyXG4gICAgICAgIF9pZDogY2xpZW50SWQsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICAkc2V0OiB7XHJcbiAgICAgICAgICBwcm92aXNpb25lZDogdHJ1ZSxcclxuICAgICAgICAgIHByb3Zpc2lvbmVkQXQ6IG5ldyBEYXRlKCksXHJcbiAgICAgICAgfSxcclxuICAgICAgfVxyXG4gICAgKVxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgc3RhdHVzOiAyMDAsXHJcbiAgICAgIG1lc3NhZ2U6IGAke2NsaWVudC5ob3N0bmFtZX0gc3VjY2Vzc2Z1bGx5IHByb3Zpc2lvbmVkYCxcclxuICAgIH1cclxuICB9LFxyXG4gIFwiQ2xpZW50cy5SZW1vdmVIb3N0XCI6IGZ1bmN0aW9uIChjbGllbnRJZCkge1xyXG4gICAgQ2xpZW50c0NvbGxlY3Rpb24ucmVtb3ZlKHtfaWQ6IGNsaWVudElkfSlcclxuICB9LFxyXG4gIFwiUmVmcmVzaENvbmZpZ1wiOiBmdW5jdGlvbiAoKSB7fSxcclxufSlcclxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IENsaWVudHNDb2xsZWN0aW9uIH0gZnJvbSAnLi4vY2xpZW50cyc7XHJcbmltcG9ydCB7IFBsYXlib29rc0NvbGxlY3Rpb24gfSBmcm9tICcuLi9wbGF5Ym9va3MnO1xyXG5pbXBvcnQgeyBBbnNpYmxlQ29sbGVjdGlvbiB9IGZyb20gJy4uL2Fuc2libGUnO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ0NsaWVudHMnLCBmdW5jdGlvbigpIHtcclxuICAgIHJldHVybiBDbGllbnRzQ29sbGVjdGlvbi5maW5kKClcclxufSlcclxuXHJcbk1ldGVvci5wdWJsaXNoKCdQbGF5Ym9va3MnLCBmdW5jdGlvbigpIHtcclxuICAgIHJldHVybiBQbGF5Ym9va3NDb2xsZWN0aW9uLmZpbmQoKVxyXG59KVxyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ0Fuc2libGUnLCBmdW5jdGlvbigpIHtcclxuICAgIHJldHVybiBBbnNpYmxlQ29sbGVjdGlvbi5maW5kKClcclxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgY29uc3QgQW5zaWJsZUNvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignQW5zaWJsZUNvbGxlY3Rpb24nKTsiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgY29uc3QgQ2xpZW50c0NvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignQ2xpZW50c0NvbGxlY3Rpb24nKTsiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgY29uc3QgUGxheWJvb2tzQ29sbGVjdGlvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdQbGF5Ym9va3NDb2xsZWN0aW9uJykiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiXHJcbmltcG9ydCB7IFBsYXlib29rc0NvbGxlY3Rpb24gfSBmcm9tIFwiLi4vYXBpL2NsaWVudHMvcGxheWJvb2tzXCJcclxuaW1wb3J0IHsgQW5zaWJsZUNvbGxlY3Rpb24gfSBmcm9tIFwiLi4vYXBpL2NsaWVudHMvYW5zaWJsZVwiXHJcbmltcG9ydCBcIi4uL2FwaS9jbGllbnRzL3NlcnZlci9wdWJsaWNhdGlvbnNcIlxyXG5pbXBvcnQgXCIuLi9hcGkvY2xpZW50cy9zZXJ2ZXIvbWV0aG9kc1wiXHJcblxyXG5jb25zdCB5YW1sID0gcmVxdWlyZShcImpzLXlhbWxcIilcclxuY29uc3QgZnMgPSByZXF1aXJlKFwiZnNcIilcclxuXHJcbmNvbnN0IENPTkZJR19GSUxFX1ZBUiA9IHByb2Nlc3MuZW52LkNPTkZJR19GSUxFIHx8IFwiL2V0Yy9nZW5pc3lzLnlhbWxcIlxyXG5leHBvcnQgY29uc3QgQ09ORklHX0ZJTEUgPSB5YW1sLmxvYWQoXHJcbiAgZnMucmVhZEZpbGVTeW5jKFN0cmluZyhDT05GSUdfRklMRV9WQVIpLCBcInV0ZjhcIilcclxuKVxyXG5cclxuLy8gY29uc3QgdGVtcF95YW1sX3N0cmluZyA9IGAtLS1cclxuLy8gYW5zaWJsZTpcclxuLy8gICBpbnZlbnRvcnk6IC92YXIvZ2VuaXN5cy9pbnZlbnRvcnlcclxuLy8gICBzc2gta2V5OiAvZXRjL2dlbmlzeXMvc3NoL2lkX3JzYVxyXG4vLyAgIHBsYXlib29rczpcclxuLy8gICAgIC0gL2V0Yy9nZW5pc3lzL3BsYXlib29rcy9maXJzdHJ1bi55YW1sXHJcbi8vICAgICAtIC9ldGMvZ2VuaXN5cy9wbGF5Ym9va3Mvc2NyaXB0Mi55YW1sYFxyXG5cclxuLy8gZXhwb3J0IGNvbnN0IENPTkZJR19GSUxFID0geWFtbC5sb2FkKHRlbXBfeWFtbF9zdHJpbmcpXHJcblxyXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XHJcbiAgY29uc29sZS5sb2coXCJNZXRlb3IgU3RhcnRlZFwiKVxyXG5cclxuICBQbGF5Ym9va3NDb2xsZWN0aW9uLmRyb3BDb2xsZWN0aW9uQXN5bmMoKVxyXG4gIEFuc2libGVDb2xsZWN0aW9uLmRyb3BDb2xsZWN0aW9uQXN5bmMoKVxyXG5cclxuICAvLyBMb2FkIHBsYXlib29rcyBpbnRvIE1vbmdvXHJcbiAgQ09ORklHX0ZJTEVbXCJhbnNpYmxlXCJdW1wicGxheWJvb2tzXCJdLmZvckVhY2goKGVsZW1lbnQpID0+IHtcclxuICAgIG9iaiA9IHsgcGxheWJvb2s6IGVsZW1lbnQgfVxyXG4gICAgUGxheWJvb2tzQ29sbGVjdGlvbi5pbnNlcnQob2JqKVxyXG4gIH0pXHJcblxyXG4gIC8vIFB1dHRpbmcgYW5zaWJsZSBTU0gga2V5IGludG8gbW9uZ28gY29sbGVjdGlvbiBmb3IgdXNhZ2Ugb24gY2xpZW50XHJcbiAgaWYgKENPTkZJR19GSUxFW1wiYW5zaWJsZVwiXVtcInNzaC1rZXlcIl0pXHJcbiAge1xyXG4gICAgb2JqID0ge1wic3NoLWtleVwiOiBDT05GSUdfRklMRVtcImFuc2libGVcIl1bXCJzc2gta2V5XCJdfVxyXG4gICAgQW5zaWJsZUNvbGxlY3Rpb24uaW5zZXJ0KG9iailcclxuICB9XHJcblxyXG4gIC8vQ3JlYXRpbmcgSW52ZW50b3J5IGZpbGVcclxuICBmcy5hY2Nlc3MoXCJpbnZlbnRvcnlcIiwgZnMuY29uc3RhbnRzLkZfT0ssIChlcnIpID0+IHtcclxuICAgIGlmIChlcnIpIHtcclxuICAgICAgY29uc29sZS5sb2coYGludmVudG9yeSBkb2VzIG5vdCBleGlzdCwgY3JlYXRpbmcgbm93YClcclxuICAgICAgZnMud3JpdGVGaWxlU3luYyhcImludmVudG9yeVwiLCBcIlthbGxfaG9zdHNdXFxuXCIpXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjb25zb2xlLmxvZyhgaW52ZW50b3J5IGV4aXN0c2ApXHJcbiAgICB9XHJcbiAgfSlcclxufSlcclxuIl19
