var require = meteorInstall({"api":{"clients":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// api/clients/server/methods.js                                                               //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }
}, 1);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 2);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }
}, 3);
Meteor.methods({
  'Clients.Provision': function (clientId) {
    check(clientId, String);
    const client = ClientsCollection.findOne({
      _id: clientId
    });
    if (!client) {
      throw new Meteor.Error('client-not-found', 'That client doesn\'t exist.');
    }
    fs.access('inventory', fs.constants.F_OK, err => {
      if (err) {
        console.log("inventory does not exist");
        fs.writeFileSync('inventory', '');
      } else {
        console.log("inventory exists");
      }
    });
    fs.readFileSync('inventory', function (file) {
      // check if client.hostname exists in file, do nothing
      // if client.hostname is not in file, add to the end of the file and write the file out.
      console.log('file', file);
    });
    ClientsCollection.update({
      _id: clientId
    }, {
      $set: {
        provisioned: true,
        provisionedAt: new Date()
        // provisionedBy: Meteor.user()
      }
    });
    return {
      status: 200,
      message: "".concat(client.hostname, " successfully provisioned")
    };
  },
  'TestYaml': function () {
    const exampleYaml = Assets.get('example.yml.tpl');
    const replace = {
      interface: 'eth0',
      subnet: '10.0.0.0/24'
    };
    // replace {{key}} with value
    // fs.writeFile...
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// api/clients/server/publications.js                                                          //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 1);
Meteor.publish('Clients', function () {
  return ClientsCollection.find();
});
/////////////////////////////////////////////////////////////////////////////////////////////////

}},"clients.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// api/clients/clients.js                                                                      //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
module.export({
  ClientsCollection: () => ClientsCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 0);
const ClientsCollection = new Mongo.Collection('ClientsCollection');
/////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// server/main.js                                                                              //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let ClientsCollection;
module.link("../api/clients/clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 1);
module.link("../api/clients/server/publications");
module.link("../api/clients/server/methods");
Meteor.startup(() => {});
/////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".mjs"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvYXBpL2NsaWVudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL2NsaWVudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiY2hlY2siLCJDbGllbnRzQ29sbGVjdGlvbiIsImZzIiwiZGVmYXVsdCIsIm1ldGhvZHMiLCJDbGllbnRzLlByb3Zpc2lvbiIsImNsaWVudElkIiwiU3RyaW5nIiwiY2xpZW50IiwiZmluZE9uZSIsIl9pZCIsIkVycm9yIiwiYWNjZXNzIiwiY29uc3RhbnRzIiwiRl9PSyIsImVyciIsImNvbnNvbGUiLCJsb2ciLCJ3cml0ZUZpbGVTeW5jIiwicmVhZEZpbGVTeW5jIiwiZmlsZSIsInVwZGF0ZSIsIiRzZXQiLCJwcm92aXNpb25lZCIsInByb3Zpc2lvbmVkQXQiLCJEYXRlIiwic3RhdHVzIiwibWVzc2FnZSIsImNvbmNhdCIsImhvc3RuYW1lIiwiVGVzdFlhbWwiLCJleGFtcGxlWWFtbCIsIkFzc2V0cyIsImdldCIsInJlcGxhY2UiLCJpbnRlcmZhY2UiLCJzdWJuZXQiLCJwdWJsaXNoIiwiZmluZCIsImV4cG9ydCIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsInN0YXJ0dXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBTTtBQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7RUFBQ0YsTUFBTUEsQ0FBQ0csQ0FBQyxFQUFDO0lBQUNILE1BQU0sR0FBQ0csQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlDLEtBQUs7QUFBQ0gsTUFBTSxDQUFDQyxJQUFJLENBQUMsY0FBYyxFQUFDO0VBQUNFLEtBQUtBLENBQUNELENBQUMsRUFBQztJQUFDQyxLQUFLLEdBQUNELENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJRSxpQkFBaUI7QUFBQ0osTUFBTSxDQUFDQyxJQUFJLENBQUMsWUFBWSxFQUFDO0VBQUNHLGlCQUFpQkEsQ0FBQ0YsQ0FBQyxFQUFDO0lBQUNFLGlCQUFpQixHQUFDRixDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUcsRUFBRTtBQUFDTCxNQUFNLENBQUNDLElBQUksQ0FBQyxJQUFJLEVBQUM7RUFBQ0ssT0FBT0EsQ0FBQ0osQ0FBQyxFQUFDO0lBQUNHLEVBQUUsR0FBQ0gsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQVN2UUgsTUFBTSxDQUFDUSxPQUFPLENBQUM7RUFDWCxtQkFBbUIsRUFBRSxTQUFBQyxDQUFVQyxRQUFRLEVBQUU7SUFDckNOLEtBQUssQ0FBQ00sUUFBUSxFQUFFQyxNQUFNLENBQUM7SUFFdkIsTUFBTUMsTUFBTSxHQUFHUCxpQkFBaUIsQ0FBQ1EsT0FBTyxDQUFDO01BQ3JDQyxHQUFHLEVBQUVKO0lBQ1QsQ0FBQyxDQUFDO0lBRUYsSUFBSSxDQUFDRSxNQUFNLEVBQUU7TUFDVCxNQUFNLElBQUlaLE1BQU0sQ0FBQ2UsS0FBSyxDQUFDLGtCQUFrQixFQUFFLDZCQUE2QixDQUFDO0lBQzdFO0lBRUFULEVBQUUsQ0FBQ1UsTUFBTSxDQUFDLFdBQVcsRUFBRVYsRUFBRSxDQUFDVyxTQUFTLENBQUNDLElBQUksRUFBR0MsR0FBRyxJQUFLO01BQy9DLElBQUlBLEdBQUcsRUFBRTtRQUNMQyxPQUFPLENBQUNDLEdBQUcsMkJBQTJCLENBQUM7UUFDdkNmLEVBQUUsQ0FBQ2dCLGFBQWEsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDO01BQ3JDLENBQUMsTUFBTTtRQUNIRixPQUFPLENBQUNDLEdBQUcsbUJBQW1CLENBQUM7TUFDbkM7SUFDSixDQUFDLENBQUM7SUFFRmYsRUFBRSxDQUFDaUIsWUFBWSxDQUFDLFdBQVcsRUFBRSxVQUFVQyxJQUFJLEVBQUU7TUFDekM7TUFDQTtNQUNBSixPQUFPLENBQUNDLEdBQUcsQ0FBQyxNQUFNLEVBQUVHLElBQUksQ0FBQztJQUM3QixDQUFDLENBQUM7SUFJRm5CLGlCQUFpQixDQUFDb0IsTUFBTSxDQUFDO01BQ3JCWCxHQUFHLEVBQUVKO0lBQ1QsQ0FBQyxFQUFFO01BQ0NnQixJQUFJLEVBQUU7UUFDRkMsV0FBVyxFQUFFLElBQUk7UUFDakJDLGFBQWEsRUFBRSxJQUFJQyxJQUFJLENBQUM7UUFDeEI7TUFDSjtJQUNKLENBQUMsQ0FBQztJQUNGLE9BQU87TUFDSEMsTUFBTSxFQUFFLEdBQUc7TUFDWEMsT0FBTyxLQUFBQyxNQUFBLENBQUtwQixNQUFNLENBQUNxQixRQUFRO0lBQy9CLENBQUM7RUFFTCxDQUFDO0VBQ0QsVUFBVSxFQUFFLFNBQUFDLENBQUEsRUFBWTtJQUNwQixNQUFNQyxXQUFXLEdBQUdDLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDLGlCQUFpQixDQUFDO0lBRWpELE1BQU1DLE9BQU8sR0FBRztNQUNaQyxTQUFTLEVBQUUsTUFBTTtNQUNqQkMsTUFBTSxFQUFFO0lBQ1osQ0FBQztJQUNEO0lBQ0E7RUFFSjtBQUNKLENBQUMsQ0FBQyxDOzs7Ozs7Ozs7OztBQ2hFRixJQUFJeEMsTUFBTTtBQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7RUFBQ0YsTUFBTUEsQ0FBQ0csQ0FBQyxFQUFDO0lBQUNILE1BQU0sR0FBQ0csQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlFLGlCQUFpQjtBQUFDSixNQUFNLENBQUNDLElBQUksQ0FBQyxZQUFZLEVBQUM7RUFBQ0csaUJBQWlCQSxDQUFDRixDQUFDLEVBQUM7SUFBQ0UsaUJBQWlCLEdBQUNGLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFHN0pILE1BQU0sQ0FBQ3lDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsWUFBVztFQUNqQyxPQUFPcEMsaUJBQWlCLENBQUNxQyxJQUFJLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQzs7Ozs7Ozs7Ozs7QUNMRnpDLE1BQU0sQ0FBQzBDLE1BQU0sQ0FBQztFQUFDdEMsaUJBQWlCLEVBQUNBLENBQUEsS0FBSUE7QUFBaUIsQ0FBQyxDQUFDO0FBQUMsSUFBSXVDLEtBQUs7QUFBQzNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDMEMsS0FBS0EsQ0FBQ3pDLENBQUMsRUFBQztJQUFDeUMsS0FBSyxHQUFDekMsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUU3RyxNQUFNRSxpQkFBaUIsR0FBRyxJQUFJdUMsS0FBSyxDQUFDQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQzs7Ozs7Ozs7Ozs7QUNGMUUsSUFBSTdDLE1BQU07QUFBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUMsZUFBZSxFQUFDO0VBQUNGLE1BQU1BLENBQUNHLENBQUMsRUFBQztJQUFDSCxNQUFNLEdBQUNHLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJRSxpQkFBaUI7QUFBQ0osTUFBTSxDQUFDQyxJQUFJLENBQUMsd0JBQXdCLEVBQUM7RUFBQ0csaUJBQWlCQSxDQUFDRixDQUFDLEVBQUM7SUFBQ0UsaUJBQWlCLEdBQUNGLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQ0YsTUFBTSxDQUFDQyxJQUFJLENBQUMsb0NBQW9DLENBQUM7QUFBQ0QsTUFBTSxDQUFDQyxJQUFJLENBQUMsK0JBQStCLENBQUM7QUFLeFFGLE1BQU0sQ0FBQzhDLE9BQU8sQ0FBQyxNQUFNLENBQ3JCLENBQUMsQ0FBQyxDIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xyXG4gICAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7XHJcbiAgICBjaGVja1xyXG59IGZyb20gJ21ldGVvci9jaGVjayc7XHJcbmltcG9ydCB7IENsaWVudHNDb2xsZWN0aW9uIH0gZnJvbSAnLi4vY2xpZW50cyc7XHJcbmltcG9ydCBmcyBmcm9tICdmcyc7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcbiAgICAnQ2xpZW50cy5Qcm92aXNpb24nOiBmdW5jdGlvbiAoY2xpZW50SWQpIHtcclxuICAgICAgICBjaGVjayhjbGllbnRJZCwgU3RyaW5nKTtcclxuXHJcbiAgICAgICAgY29uc3QgY2xpZW50ID0gQ2xpZW50c0NvbGxlY3Rpb24uZmluZE9uZSh7XHJcbiAgICAgICAgICAgIF9pZDogY2xpZW50SWRcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgaWYgKCFjbGllbnQpIHtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignY2xpZW50LW5vdC1mb3VuZCcsICdUaGF0IGNsaWVudCBkb2VzblxcJ3QgZXhpc3QuJyk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmcy5hY2Nlc3MoJ2ludmVudG9yeScsIGZzLmNvbnN0YW50cy5GX09LLCAoZXJyKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBpbnZlbnRvcnkgZG9lcyBub3QgZXhpc3RgKTtcclxuICAgICAgICAgICAgICAgIGZzLndyaXRlRmlsZVN5bmMoJ2ludmVudG9yeScsICcnKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGBpbnZlbnRvcnkgZXhpc3RzYCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgZnMucmVhZEZpbGVTeW5jKCdpbnZlbnRvcnknLCBmdW5jdGlvbiAoZmlsZSkge1xyXG4gICAgICAgICAgICAvLyBjaGVjayBpZiBjbGllbnQuaG9zdG5hbWUgZXhpc3RzIGluIGZpbGUsIGRvIG5vdGhpbmdcclxuICAgICAgICAgICAgLy8gaWYgY2xpZW50Lmhvc3RuYW1lIGlzIG5vdCBpbiBmaWxlLCBhZGQgdG8gdGhlIGVuZCBvZiB0aGUgZmlsZSBhbmQgd3JpdGUgdGhlIGZpbGUgb3V0LlxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnZmlsZScsIGZpbGUpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuXHJcblxyXG4gICAgICAgIENsaWVudHNDb2xsZWN0aW9uLnVwZGF0ZSh7XHJcbiAgICAgICAgICAgIF9pZDogY2xpZW50SWQsXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAkc2V0OiB7XHJcbiAgICAgICAgICAgICAgICBwcm92aXNpb25lZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgIHByb3Zpc2lvbmVkQXQ6IG5ldyBEYXRlKClcclxuICAgICAgICAgICAgICAgIC8vIHByb3Zpc2lvbmVkQnk6IE1ldGVvci51c2VyKClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHN0YXR1czogMjAwLFxyXG4gICAgICAgICAgICBtZXNzYWdlOiBgJHtjbGllbnQuaG9zdG5hbWV9IHN1Y2Nlc3NmdWxseSBwcm92aXNpb25lZGBcclxuICAgICAgICB9O1xyXG5cclxuICAgIH0sXHJcbiAgICAnVGVzdFlhbWwnOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgY29uc3QgZXhhbXBsZVlhbWwgPSBBc3NldHMuZ2V0KCdleGFtcGxlLnltbC50cGwnKTtcclxuXHJcbiAgICAgICAgY29uc3QgcmVwbGFjZSA9IHtcclxuICAgICAgICAgICAgaW50ZXJmYWNlOiAnZXRoMCcsXHJcbiAgICAgICAgICAgIHN1Ym5ldDogJzEwLjAuMC4wLzI0J1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyByZXBsYWNlIHt7a2V5fX0gd2l0aCB2YWx1ZVxyXG4gICAgICAgIC8vIGZzLndyaXRlRmlsZS4uLlxyXG5cclxuICAgIH1cclxufSk7IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IENsaWVudHNDb2xsZWN0aW9uIH0gZnJvbSAnLi4vY2xpZW50cyc7XHJcblxyXG5NZXRlb3IucHVibGlzaCgnQ2xpZW50cycsIGZ1bmN0aW9uKCkge1xyXG4gICAgcmV0dXJuIENsaWVudHNDb2xsZWN0aW9uLmZpbmQoKVxyXG59KSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuXHJcbmV4cG9ydCBjb25zdCBDbGllbnRzQ29sbGVjdGlvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdDbGllbnRzQ29sbGVjdGlvbicpOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBDbGllbnRzQ29sbGVjdGlvbiB9IGZyb20gJy4uL2FwaS9jbGllbnRzL2NsaWVudHMnO1xyXG5pbXBvcnQgJy4uL2FwaS9jbGllbnRzL3NlcnZlci9wdWJsaWNhdGlvbnMnO1xyXG5pbXBvcnQgJy4uL2FwaS9jbGllbnRzL3NlcnZlci9tZXRob2RzJztcclxuXHJcbk1ldGVvci5zdGFydHVwKCgpID0+IHtcclxufSk7Il19
