var require = meteorInstall({"api":{"clients":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// api/clients/server/methods.js                                                               //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }
}, 1);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 2);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }
}, 3);
Meteor.methods({
  'Clients.Provision': function (clientId) {
    check(clientId, String);
    const client = ClientsCollection.findOne({
      _id: clientId
    });
    if (!client) {
      throw new Meteor.Error('client-not-found', 'That client doesn\'t exist.');
    }
    fs.access('inventory', fs.constants.F_OK, err => {
      if (err) {
        console.log("inventory does not exist");
        fs.writeFileSync('inventory', '');
      } else {
        console.log("inventory exists");
      }
    });
    fs.readFileSync('inventory', function (file) {
      // check if client.hostname exists in file, do nothing
      // if client.hostname is not in file, add to the end of the file and write the file out.
      console.log('file', file);
    });
    ClientsCollection.update({
      _id: clientId
    }, {
      $set: {
        provisioned: true,
        provisionedAt: new Date()
        // provisionedBy: Meteor.user()
      }
    });
    return {
      status: 200,
      message: "".concat(client.hostname, " successfully provisioned")
    };
  },
  'TestYaml': function () {
    const exampleYaml = Assets.get('example.yml.tpl');
    const replace = {
      interface: 'eth0',
      subnet: '10.0.0.0/24'
    };
    // replace {{key}} with value
    // fs.writeFile...
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// api/clients/server/publications.js                                                          //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 1);
Meteor.publish('Clients', function () {
  return ClientsCollection.find();
});
/////////////////////////////////////////////////////////////////////////////////////////////////

}},"clients.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// api/clients/clients.js                                                                      //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
module.export({
  ClientsCollection: () => ClientsCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 0);
const ClientsCollection = new Mongo.Collection('ClientsCollection');
/////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// server/main.js                                                                              //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let ClientsCollection;
module.link("../api/clients/clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 1);
module.link("../api/clients/server/publications");
module.link("../api/clients/server/methods");
Meteor.startup(() => {
  console.log("Meteor Started");
});
/////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".mjs"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvYXBpL2NsaWVudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL2NsaWVudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiY2hlY2siLCJDbGllbnRzQ29sbGVjdGlvbiIsImZzIiwiZGVmYXVsdCIsIm1ldGhvZHMiLCJDbGllbnRzLlByb3Zpc2lvbiIsImNsaWVudElkIiwiU3RyaW5nIiwiY2xpZW50IiwiZmluZE9uZSIsIl9pZCIsIkVycm9yIiwiYWNjZXNzIiwiY29uc3RhbnRzIiwiRl9PSyIsImVyciIsImNvbnNvbGUiLCJsb2ciLCJ3cml0ZUZpbGVTeW5jIiwicmVhZEZpbGVTeW5jIiwiZmlsZSIsInVwZGF0ZSIsIiRzZXQiLCJwcm92aXNpb25lZCIsInByb3Zpc2lvbmVkQXQiLCJEYXRlIiwic3RhdHVzIiwibWVzc2FnZSIsImNvbmNhdCIsImhvc3RuYW1lIiwiVGVzdFlhbWwiLCJleGFtcGxlWWFtbCIsIkFzc2V0cyIsImdldCIsInJlcGxhY2UiLCJpbnRlcmZhY2UiLCJzdWJuZXQiLCJwdWJsaXNoIiwiZmluZCIsImV4cG9ydCIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsInN0YXJ0dXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBTTtBQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7RUFBQ0YsTUFBTUEsQ0FBQ0csQ0FBQyxFQUFDO0lBQUNILE1BQU0sR0FBQ0csQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlDLEtBQUs7QUFBQ0gsTUFBTSxDQUFDQyxJQUFJLENBQUMsY0FBYyxFQUFDO0VBQUNFLEtBQUtBLENBQUNELENBQUMsRUFBQztJQUFDQyxLQUFLLEdBQUNELENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJRSxpQkFBaUI7QUFBQ0osTUFBTSxDQUFDQyxJQUFJLENBQUMsWUFBWSxFQUFDO0VBQUNHLGlCQUFpQkEsQ0FBQ0YsQ0FBQyxFQUFDO0lBQUNFLGlCQUFpQixHQUFDRixDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUcsRUFBRTtBQUFDTCxNQUFNLENBQUNDLElBQUksQ0FBQyxJQUFJLEVBQUM7RUFBQ0ssT0FBT0EsQ0FBQ0osQ0FBQyxFQUFDO0lBQUNHLEVBQUUsR0FBQ0gsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQVN2UUgsTUFBTSxDQUFDUSxPQUFPLENBQUM7RUFDWCxtQkFBbUIsRUFBRSxTQUFBQyxDQUFVQyxRQUFRLEVBQUU7SUFDckNOLEtBQUssQ0FBQ00sUUFBUSxFQUFFQyxNQUFNLENBQUM7SUFFdkIsTUFBTUMsTUFBTSxHQUFHUCxpQkFBaUIsQ0FBQ1EsT0FBTyxDQUFDO01BQ3JDQyxHQUFHLEVBQUVKO0lBQ1QsQ0FBQyxDQUFDO0lBRUYsSUFBSSxDQUFDRSxNQUFNLEVBQUU7TUFDVCxNQUFNLElBQUlaLE1BQU0sQ0FBQ2UsS0FBSyxDQUFDLGtCQUFrQixFQUFFLDZCQUE2QixDQUFDO0lBQzdFO0lBRUFULEVBQUUsQ0FBQ1UsTUFBTSxDQUFDLFdBQVcsRUFBRVYsRUFBRSxDQUFDVyxTQUFTLENBQUNDLElBQUksRUFBR0MsR0FBRyxJQUFLO01BQy9DLElBQUlBLEdBQUcsRUFBRTtRQUNMQyxPQUFPLENBQUNDLEdBQUcsMkJBQTJCLENBQUM7UUFDdkNmLEVBQUUsQ0FBQ2dCLGFBQWEsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDO01BQ3JDLENBQUMsTUFBTTtRQUNIRixPQUFPLENBQUNDLEdBQUcsbUJBQW1CLENBQUM7TUFDbkM7SUFDSixDQUFDLENBQUM7SUFFRmYsRUFBRSxDQUFDaUIsWUFBWSxDQUFDLFdBQVcsRUFBRSxVQUFVQyxJQUFJLEVBQUU7TUFDekM7TUFDQTtNQUNBSixPQUFPLENBQUNDLEdBQUcsQ0FBQyxNQUFNLEVBQUVHLElBQUksQ0FBQztJQUM3QixDQUFDLENBQUM7SUFJRm5CLGlCQUFpQixDQUFDb0IsTUFBTSxDQUFDO01BQ3JCWCxHQUFHLEVBQUVKO0lBQ1QsQ0FBQyxFQUFFO01BQ0NnQixJQUFJLEVBQUU7UUFDRkMsV0FBVyxFQUFFLElBQUk7UUFDakJDLGFBQWEsRUFBRSxJQUFJQyxJQUFJLENBQUM7UUFDeEI7TUFDSjtJQUNKLENBQUMsQ0FBQztJQUNGLE9BQU87TUFDSEMsTUFBTSxFQUFFLEdBQUc7TUFDWEMsT0FBTyxLQUFBQyxNQUFBLENBQUtwQixNQUFNLENBQUNxQixRQUFRO0lBQy9CLENBQUM7RUFFTCxDQUFDO0VBQ0QsVUFBVSxFQUFFLFNBQUFDLENBQUEsRUFBWTtJQUNwQixNQUFNQyxXQUFXLEdBQUdDLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDLGlCQUFpQixDQUFDO0lBRWpELE1BQU1DLE9BQU8sR0FBRztNQUNaQyxTQUFTLEVBQUUsTUFBTTtNQUNqQkMsTUFBTSxFQUFFO0lBQ1osQ0FBQztJQUNEO0lBQ0E7RUFFSjtBQUNKLENBQUMsQ0FBQyxDOzs7Ozs7Ozs7OztBQ2hFRixJQUFJeEMsTUFBTTtBQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7RUFBQ0YsTUFBTUEsQ0FBQ0csQ0FBQyxFQUFDO0lBQUNILE1BQU0sR0FBQ0csQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlFLGlCQUFpQjtBQUFDSixNQUFNLENBQUNDLElBQUksQ0FBQyxZQUFZLEVBQUM7RUFBQ0csaUJBQWlCQSxDQUFDRixDQUFDLEVBQUM7SUFBQ0UsaUJBQWlCLEdBQUNGLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFHN0pILE1BQU0sQ0FBQ3lDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsWUFBVztFQUNqQyxPQUFPcEMsaUJBQWlCLENBQUNxQyxJQUFJLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQzs7Ozs7Ozs7Ozs7QUNMRnpDLE1BQU0sQ0FBQzBDLE1BQU0sQ0FBQztFQUFDdEMsaUJBQWlCLEVBQUNBLENBQUEsS0FBSUE7QUFBaUIsQ0FBQyxDQUFDO0FBQUMsSUFBSXVDLEtBQUs7QUFBQzNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDMEMsS0FBS0EsQ0FBQ3pDLENBQUMsRUFBQztJQUFDeUMsS0FBSyxHQUFDekMsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUU3RyxNQUFNRSxpQkFBaUIsR0FBRyxJQUFJdUMsS0FBSyxDQUFDQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQzs7Ozs7Ozs7Ozs7QUNGMUUsSUFBSTdDLE1BQU07QUFBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUMsZUFBZSxFQUFDO0VBQUNGLE1BQU1BLENBQUNHLENBQUMsRUFBQztJQUFDSCxNQUFNLEdBQUNHLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJRSxpQkFBaUI7QUFBQ0osTUFBTSxDQUFDQyxJQUFJLENBQUMsd0JBQXdCLEVBQUM7RUFBQ0csaUJBQWlCQSxDQUFDRixDQUFDLEVBQUM7SUFBQ0UsaUJBQWlCLEdBQUNGLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQ0YsTUFBTSxDQUFDQyxJQUFJLENBQUMsb0NBQW9DLENBQUM7QUFBQ0QsTUFBTSxDQUFDQyxJQUFJLENBQUMsK0JBQStCLENBQUM7QUFLeFFGLE1BQU0sQ0FBQzhDLE9BQU8sQ0FBQyxNQUFNO0VBQ2pCMUIsT0FBTyxDQUFDQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7QUFDakMsQ0FBQyxDQUFDLEMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHtcclxuICAgIGNoZWNrXHJcbn0gZnJvbSAnbWV0ZW9yL2NoZWNrJztcclxuaW1wb3J0IHsgQ2xpZW50c0NvbGxlY3Rpb24gfSBmcm9tICcuLi9jbGllbnRzJztcclxuaW1wb3J0IGZzIGZyb20gJ2ZzJztcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICAgICdDbGllbnRzLlByb3Zpc2lvbic6IGZ1bmN0aW9uIChjbGllbnRJZCkge1xyXG4gICAgICAgIGNoZWNrKGNsaWVudElkLCBTdHJpbmcpO1xyXG5cclxuICAgICAgICBjb25zdCBjbGllbnQgPSBDbGllbnRzQ29sbGVjdGlvbi5maW5kT25lKHtcclxuICAgICAgICAgICAgX2lkOiBjbGllbnRJZFxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAoIWNsaWVudCkge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdjbGllbnQtbm90LWZvdW5kJywgJ1RoYXQgY2xpZW50IGRvZXNuXFwndCBleGlzdC4nKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZzLmFjY2VzcygnaW52ZW50b3J5JywgZnMuY29uc3RhbnRzLkZfT0ssIChlcnIpID0+IHtcclxuICAgICAgICAgICAgaWYgKGVycikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYGludmVudG9yeSBkb2VzIG5vdCBleGlzdGApO1xyXG4gICAgICAgICAgICAgICAgZnMud3JpdGVGaWxlU3luYygnaW52ZW50b3J5JywgJycpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYGludmVudG9yeSBleGlzdHNgKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBmcy5yZWFkRmlsZVN5bmMoJ2ludmVudG9yeScsIGZ1bmN0aW9uIChmaWxlKSB7XHJcbiAgICAgICAgICAgIC8vIGNoZWNrIGlmIGNsaWVudC5ob3N0bmFtZSBleGlzdHMgaW4gZmlsZSwgZG8gbm90aGluZ1xyXG4gICAgICAgICAgICAvLyBpZiBjbGllbnQuaG9zdG5hbWUgaXMgbm90IGluIGZpbGUsIGFkZCB0byB0aGUgZW5kIG9mIHRoZSBmaWxlIGFuZCB3cml0ZSB0aGUgZmlsZSBvdXQuXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdmaWxlJywgZmlsZSk7XHJcbiAgICAgICAgfSk7XHJcblxyXG5cclxuXHJcbiAgICAgICAgQ2xpZW50c0NvbGxlY3Rpb24udXBkYXRlKHtcclxuICAgICAgICAgICAgX2lkOiBjbGllbnRJZCxcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgICAgICAgIHByb3Zpc2lvbmVkOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgcHJvdmlzaW9uZWRBdDogbmV3IERhdGUoKVxyXG4gICAgICAgICAgICAgICAgLy8gcHJvdmlzaW9uZWRCeTogTWV0ZW9yLnVzZXIoKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgc3RhdHVzOiAyMDAsXHJcbiAgICAgICAgICAgIG1lc3NhZ2U6IGAke2NsaWVudC5ob3N0bmFtZX0gc3VjY2Vzc2Z1bGx5IHByb3Zpc2lvbmVkYFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgfSxcclxuICAgICdUZXN0WWFtbCc6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBjb25zdCBleGFtcGxlWWFtbCA9IEFzc2V0cy5nZXQoJ2V4YW1wbGUueW1sLnRwbCcpO1xyXG5cclxuICAgICAgICBjb25zdCByZXBsYWNlID0ge1xyXG4gICAgICAgICAgICBpbnRlcmZhY2U6ICdldGgwJyxcclxuICAgICAgICAgICAgc3VibmV0OiAnMTAuMC4wLjAvMjQnXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vIHJlcGxhY2Uge3trZXl9fSB3aXRoIHZhbHVlXHJcbiAgICAgICAgLy8gZnMud3JpdGVGaWxlLi4uXHJcblxyXG4gICAgfVxyXG59KTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHsgQ2xpZW50c0NvbGxlY3Rpb24gfSBmcm9tICcuLi9jbGllbnRzJztcclxuXHJcbk1ldGVvci5wdWJsaXNoKCdDbGllbnRzJywgZnVuY3Rpb24oKSB7XHJcbiAgICByZXR1cm4gQ2xpZW50c0NvbGxlY3Rpb24uZmluZCgpXHJcbn0pIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5cclxuZXhwb3J0IGNvbnN0IENsaWVudHNDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ0NsaWVudHNDb2xsZWN0aW9uJyk7IiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IENsaWVudHNDb2xsZWN0aW9uIH0gZnJvbSAnLi4vYXBpL2NsaWVudHMvY2xpZW50cyc7XHJcbmltcG9ydCAnLi4vYXBpL2NsaWVudHMvc2VydmVyL3B1YmxpY2F0aW9ucyc7XHJcbmltcG9ydCAnLi4vYXBpL2NsaWVudHMvc2VydmVyL21ldGhvZHMnO1xyXG5cclxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coXCJNZXRlb3IgU3RhcnRlZFwiKVxyXG59KTsiXX0=
