var require = meteorInstall({"api":{"clients":{"server":{"methods.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// api/clients/server/methods.js                                                               //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }
}, 1);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 2);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }
}, 3);
Meteor.methods({
  'Clients.Provision': function (clientId) {
    check(clientId, String);
    const client = ClientsCollection.findOne({
      _id: clientId
    });
    if (!client) {
      throw new Meteor.Error('client-not-found', 'That client doesn\'t exist.');
    }
    fs.access('inventory', fs.constants.F_OK, err => {
      if (err) {
        console.log("inventory does not exist");
        fs.writeFileSync('inventory', '');
      } else {
        console.log("inventory exists");
      }
    });
    fs.readFileSync('inventory', function (file) {
      // check if client.hostname exists in file, do nothing
      // if client.hostname is not in file, add to the end of the file and write the file out.
      console.log('file', file);
    });
    ClientsCollection.update({
      _id: clientId
    }, {
      $set: {
        provisioned: true,
        provisionedAt: new Date()
        // provisionedBy: Meteor.user()
      }
    });
    return {
      status: 200,
      message: "".concat(client.hostname, " successfully provisioned")
    };
  },
  'TestYaml': function () {
    const exampleYaml = Assets.get('example.yml.tpl');
    const replace = {
      interface: 'eth0',
      subnet: '10.0.0.0/24'
    };
    // replace {{key}} with value
    // fs.writeFile...
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// api/clients/server/publications.js                                                          //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 1);
Meteor.publish('Clients', function () {
  return ClientsCollection.find();
});
/////////////////////////////////////////////////////////////////////////////////////////////////

}},"clients.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// api/clients/clients.js                                                                      //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
module.export({
  ClientsCollection: () => ClientsCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 0);
const ClientsCollection = new Mongo.Collection('ClientsCollection');
/////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                             //
// server/main.js                                                                              //
//                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                               //
module.export({
  CONFIG_FILE: () => CONFIG_FILE
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let ClientsCollection;
module.link("../api/clients/clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 1);
module.link("../api/clients/server/publications");
module.link("../api/clients/server/methods");
const yaml = require('js-yaml');
const fs = require('fs');
const CONFIG_FILE_VAR = process.env.CONFIG_FILE || '/etc/genisys.yaml';
const CONFIG_FILE = yaml.load(fs.readFileSync(String(CONFIG_FILE_VAR), 'utf8'));
Meteor.startup(() => {
  console.log("Meteor Started");
});
/////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".mjs"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvYXBpL2NsaWVudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL2NsaWVudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1ldGVvciIsIm1vZHVsZSIsImxpbmsiLCJ2IiwiY2hlY2siLCJDbGllbnRzQ29sbGVjdGlvbiIsImZzIiwiZGVmYXVsdCIsIm1ldGhvZHMiLCJDbGllbnRzLlByb3Zpc2lvbiIsImNsaWVudElkIiwiU3RyaW5nIiwiY2xpZW50IiwiZmluZE9uZSIsIl9pZCIsIkVycm9yIiwiYWNjZXNzIiwiY29uc3RhbnRzIiwiRl9PSyIsImVyciIsImNvbnNvbGUiLCJsb2ciLCJ3cml0ZUZpbGVTeW5jIiwicmVhZEZpbGVTeW5jIiwiZmlsZSIsInVwZGF0ZSIsIiRzZXQiLCJwcm92aXNpb25lZCIsInByb3Zpc2lvbmVkQXQiLCJEYXRlIiwic3RhdHVzIiwibWVzc2FnZSIsImNvbmNhdCIsImhvc3RuYW1lIiwiVGVzdFlhbWwiLCJleGFtcGxlWWFtbCIsIkFzc2V0cyIsImdldCIsInJlcGxhY2UiLCJpbnRlcmZhY2UiLCJzdWJuZXQiLCJwdWJsaXNoIiwiZmluZCIsImV4cG9ydCIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsIkNPTkZJR19GSUxFIiwieWFtbCIsInJlcXVpcmUiLCJDT05GSUdfRklMRV9WQVIiLCJwcm9jZXNzIiwiZW52IiwibG9hZCIsInN0YXJ0dXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsTUFBTTtBQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7RUFBQ0YsTUFBTUEsQ0FBQ0csQ0FBQyxFQUFDO0lBQUNILE1BQU0sR0FBQ0csQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlDLEtBQUs7QUFBQ0gsTUFBTSxDQUFDQyxJQUFJLENBQUMsY0FBYyxFQUFDO0VBQUNFLEtBQUtBLENBQUNELENBQUMsRUFBQztJQUFDQyxLQUFLLEdBQUNELENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJRSxpQkFBaUI7QUFBQ0osTUFBTSxDQUFDQyxJQUFJLENBQUMsWUFBWSxFQUFDO0VBQUNHLGlCQUFpQkEsQ0FBQ0YsQ0FBQyxFQUFDO0lBQUNFLGlCQUFpQixHQUFDRixDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUcsRUFBRTtBQUFDTCxNQUFNLENBQUNDLElBQUksQ0FBQyxJQUFJLEVBQUM7RUFBQ0ssT0FBT0EsQ0FBQ0osQ0FBQyxFQUFDO0lBQUNHLEVBQUUsR0FBQ0gsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQVN2UUgsTUFBTSxDQUFDUSxPQUFPLENBQUM7RUFDWCxtQkFBbUIsRUFBRSxTQUFBQyxDQUFVQyxRQUFRLEVBQUU7SUFDckNOLEtBQUssQ0FBQ00sUUFBUSxFQUFFQyxNQUFNLENBQUM7SUFFdkIsTUFBTUMsTUFBTSxHQUFHUCxpQkFBaUIsQ0FBQ1EsT0FBTyxDQUFDO01BQ3JDQyxHQUFHLEVBQUVKO0lBQ1QsQ0FBQyxDQUFDO0lBRUYsSUFBSSxDQUFDRSxNQUFNLEVBQUU7TUFDVCxNQUFNLElBQUlaLE1BQU0sQ0FBQ2UsS0FBSyxDQUFDLGtCQUFrQixFQUFFLDZCQUE2QixDQUFDO0lBQzdFO0lBRUFULEVBQUUsQ0FBQ1UsTUFBTSxDQUFDLFdBQVcsRUFBRVYsRUFBRSxDQUFDVyxTQUFTLENBQUNDLElBQUksRUFBR0MsR0FBRyxJQUFLO01BQy9DLElBQUlBLEdBQUcsRUFBRTtRQUNMQyxPQUFPLENBQUNDLEdBQUcsMkJBQTJCLENBQUM7UUFDdkNmLEVBQUUsQ0FBQ2dCLGFBQWEsQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDO01BQ3JDLENBQUMsTUFBTTtRQUNIRixPQUFPLENBQUNDLEdBQUcsbUJBQW1CLENBQUM7TUFDbkM7SUFDSixDQUFDLENBQUM7SUFFRmYsRUFBRSxDQUFDaUIsWUFBWSxDQUFDLFdBQVcsRUFBRSxVQUFVQyxJQUFJLEVBQUU7TUFDekM7TUFDQTtNQUNBSixPQUFPLENBQUNDLEdBQUcsQ0FBQyxNQUFNLEVBQUVHLElBQUksQ0FBQztJQUM3QixDQUFDLENBQUM7SUFJRm5CLGlCQUFpQixDQUFDb0IsTUFBTSxDQUFDO01BQ3JCWCxHQUFHLEVBQUVKO0lBQ1QsQ0FBQyxFQUFFO01BQ0NnQixJQUFJLEVBQUU7UUFDRkMsV0FBVyxFQUFFLElBQUk7UUFDakJDLGFBQWEsRUFBRSxJQUFJQyxJQUFJLENBQUM7UUFDeEI7TUFDSjtJQUNKLENBQUMsQ0FBQztJQUNGLE9BQU87TUFDSEMsTUFBTSxFQUFFLEdBQUc7TUFDWEMsT0FBTyxLQUFBQyxNQUFBLENBQUtwQixNQUFNLENBQUNxQixRQUFRO0lBQy9CLENBQUM7RUFFTCxDQUFDO0VBQ0QsVUFBVSxFQUFFLFNBQUFDLENBQUEsRUFBWTtJQUNwQixNQUFNQyxXQUFXLEdBQUdDLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDLGlCQUFpQixDQUFDO0lBRWpELE1BQU1DLE9BQU8sR0FBRztNQUNaQyxTQUFTLEVBQUUsTUFBTTtNQUNqQkMsTUFBTSxFQUFFO0lBQ1osQ0FBQztJQUNEO0lBQ0E7RUFFSjtBQUNKLENBQUMsQ0FBQyxDOzs7Ozs7Ozs7OztBQ2hFRixJQUFJeEMsTUFBTTtBQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7RUFBQ0YsTUFBTUEsQ0FBQ0csQ0FBQyxFQUFDO0lBQUNILE1BQU0sR0FBQ0csQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlFLGlCQUFpQjtBQUFDSixNQUFNLENBQUNDLElBQUksQ0FBQyxZQUFZLEVBQUM7RUFBQ0csaUJBQWlCQSxDQUFDRixDQUFDLEVBQUM7SUFBQ0UsaUJBQWlCLEdBQUNGLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFHN0pILE1BQU0sQ0FBQ3lDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsWUFBVztFQUNqQyxPQUFPcEMsaUJBQWlCLENBQUNxQyxJQUFJLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQzs7Ozs7Ozs7Ozs7QUNMRnpDLE1BQU0sQ0FBQzBDLE1BQU0sQ0FBQztFQUFDdEMsaUJBQWlCLEVBQUNBLENBQUEsS0FBSUE7QUFBaUIsQ0FBQyxDQUFDO0FBQUMsSUFBSXVDLEtBQUs7QUFBQzNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDMEMsS0FBS0EsQ0FBQ3pDLENBQUMsRUFBQztJQUFDeUMsS0FBSyxHQUFDekMsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUU3RyxNQUFNRSxpQkFBaUIsR0FBRyxJQUFJdUMsS0FBSyxDQUFDQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsQzs7Ozs7Ozs7Ozs7QUNGMUU1QyxNQUFNLENBQUMwQyxNQUFNLENBQUM7RUFBQ0csV0FBVyxFQUFDQSxDQUFBLEtBQUlBO0FBQVcsQ0FBQyxDQUFDO0FBQUMsSUFBSTlDLE1BQU07QUFBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUMsZUFBZSxFQUFDO0VBQUNGLE1BQU1BLENBQUNHLENBQUMsRUFBQztJQUFDSCxNQUFNLEdBQUNHLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJRSxpQkFBaUI7QUFBQ0osTUFBTSxDQUFDQyxJQUFJLENBQUMsd0JBQXdCLEVBQUM7RUFBQ0csaUJBQWlCQSxDQUFDRixDQUFDLEVBQUM7SUFBQ0UsaUJBQWlCLEdBQUNGLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQ0YsTUFBTSxDQUFDQyxJQUFJLENBQUMsb0NBQW9DLENBQUM7QUFBQ0QsTUFBTSxDQUFDQyxJQUFJLENBQUMsK0JBQStCLENBQUM7QUFLclQsTUFBTTZDLElBQUksR0FBR0MsT0FBTyxDQUFDLFNBQVMsQ0FBQztBQUMvQixNQUFNMUMsRUFBRSxHQUFHMEMsT0FBTyxDQUFDLElBQUksQ0FBQztBQUV4QixNQUFNQyxlQUFlLEdBQUdDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDTCxXQUFXLElBQUksbUJBQW1CO0FBQy9ELE1BQU1BLFdBQVcsR0FBR0MsSUFBSSxDQUFDSyxJQUFJLENBQUM5QyxFQUFFLENBQUNpQixZQUFZLENBQUNaLE1BQU0sQ0FBQ3NDLGVBQWUsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBRXRGakQsTUFBTSxDQUFDcUQsT0FBTyxDQUFDLE1BQU07RUFDakJqQyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztBQUNqQyxDQUFDLENBQUMsQyIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcclxuICAgIE1ldGVvclxyXG59IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQge1xyXG4gICAgY2hlY2tcclxufSBmcm9tICdtZXRlb3IvY2hlY2snO1xyXG5pbXBvcnQgeyBDbGllbnRzQ29sbGVjdGlvbiB9IGZyb20gJy4uL2NsaWVudHMnO1xyXG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgJ0NsaWVudHMuUHJvdmlzaW9uJzogZnVuY3Rpb24gKGNsaWVudElkKSB7XHJcbiAgICAgICAgY2hlY2soY2xpZW50SWQsIFN0cmluZyk7XHJcblxyXG4gICAgICAgIGNvbnN0IGNsaWVudCA9IENsaWVudHNDb2xsZWN0aW9uLmZpbmRPbmUoe1xyXG4gICAgICAgICAgICBfaWQ6IGNsaWVudElkXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGlmICghY2xpZW50KSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoJ2NsaWVudC1ub3QtZm91bmQnLCAnVGhhdCBjbGllbnQgZG9lc25cXCd0IGV4aXN0LicpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZnMuYWNjZXNzKCdpbnZlbnRvcnknLCBmcy5jb25zdGFudHMuRl9PSywgKGVycikgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgaW52ZW50b3J5IGRvZXMgbm90IGV4aXN0YCk7XHJcbiAgICAgICAgICAgICAgICBmcy53cml0ZUZpbGVTeW5jKCdpbnZlbnRvcnknLCAnJyk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgaW52ZW50b3J5IGV4aXN0c2ApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIGZzLnJlYWRGaWxlU3luYygnaW52ZW50b3J5JywgZnVuY3Rpb24gKGZpbGUpIHtcclxuICAgICAgICAgICAgLy8gY2hlY2sgaWYgY2xpZW50Lmhvc3RuYW1lIGV4aXN0cyBpbiBmaWxlLCBkbyBub3RoaW5nXHJcbiAgICAgICAgICAgIC8vIGlmIGNsaWVudC5ob3N0bmFtZSBpcyBub3QgaW4gZmlsZSwgYWRkIHRvIHRoZSBlbmQgb2YgdGhlIGZpbGUgYW5kIHdyaXRlIHRoZSBmaWxlIG91dC5cclxuICAgICAgICAgICAgY29uc29sZS5sb2coJ2ZpbGUnLCBmaWxlKTtcclxuICAgICAgICB9KTtcclxuXHJcblxyXG5cclxuICAgICAgICBDbGllbnRzQ29sbGVjdGlvbi51cGRhdGUoe1xyXG4gICAgICAgICAgICBfaWQ6IGNsaWVudElkLFxyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgICAgICAgcHJvdmlzaW9uZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICBwcm92aXNpb25lZEF0OiBuZXcgRGF0ZSgpXHJcbiAgICAgICAgICAgICAgICAvLyBwcm92aXNpb25lZEJ5OiBNZXRlb3IudXNlcigpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICBzdGF0dXM6IDIwMCxcclxuICAgICAgICAgICAgbWVzc2FnZTogYCR7Y2xpZW50Lmhvc3RuYW1lfSBzdWNjZXNzZnVsbHkgcHJvdmlzaW9uZWRgXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICB9LFxyXG4gICAgJ1Rlc3RZYW1sJzogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNvbnN0IGV4YW1wbGVZYW1sID0gQXNzZXRzLmdldCgnZXhhbXBsZS55bWwudHBsJyk7XHJcblxyXG4gICAgICAgIGNvbnN0IHJlcGxhY2UgPSB7XHJcbiAgICAgICAgICAgIGludGVyZmFjZTogJ2V0aDAnLFxyXG4gICAgICAgICAgICBzdWJuZXQ6ICcxMC4wLjAuMC8yNCdcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8gcmVwbGFjZSB7e2tleX19IHdpdGggdmFsdWVcclxuICAgICAgICAvLyBmcy53cml0ZUZpbGUuLi5cclxuXHJcbiAgICB9XHJcbn0pOyIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5pbXBvcnQgeyBDbGllbnRzQ29sbGVjdGlvbiB9IGZyb20gJy4uL2NsaWVudHMnO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ0NsaWVudHMnLCBmdW5jdGlvbigpIHtcclxuICAgIHJldHVybiBDbGllbnRzQ29sbGVjdGlvbi5maW5kKClcclxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgY29uc3QgQ2xpZW50c0NvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignQ2xpZW50c0NvbGxlY3Rpb24nKTsiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuaW1wb3J0IHsgQ2xpZW50c0NvbGxlY3Rpb24gfSBmcm9tICcuLi9hcGkvY2xpZW50cy9jbGllbnRzJztcclxuaW1wb3J0ICcuLi9hcGkvY2xpZW50cy9zZXJ2ZXIvcHVibGljYXRpb25zJztcclxuaW1wb3J0ICcuLi9hcGkvY2xpZW50cy9zZXJ2ZXIvbWV0aG9kcyc7XHJcblxyXG5jb25zdCB5YW1sID0gcmVxdWlyZSgnanMteWFtbCcpXHJcbmNvbnN0IGZzID0gcmVxdWlyZSgnZnMnKVxyXG5cclxuY29uc3QgQ09ORklHX0ZJTEVfVkFSID0gcHJvY2Vzcy5lbnYuQ09ORklHX0ZJTEUgfHwgJy9ldGMvZ2VuaXN5cy55YW1sJ1xyXG5leHBvcnQgY29uc3QgQ09ORklHX0ZJTEUgPSB5YW1sLmxvYWQoZnMucmVhZEZpbGVTeW5jKFN0cmluZyhDT05GSUdfRklMRV9WQVIpLCAndXRmOCcpKVxyXG5cclxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coXCJNZXRlb3IgU3RhcnRlZFwiKVxyXG59KTsiXX0=
