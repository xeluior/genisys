var require = meteorInstall({"api":{"clients":{"server":{"methods.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// api/clients/server/methods.js                                                             //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let check;
module.link("meteor/check", {
  check(v) {
    check = v;
  }
}, 1);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 2);
let AnsibleCollection;
module.link("../ansible", {
  AnsibleCollection(v) {
    AnsibleCollection = v;
  }
}, 3);
let fs;
module.link("fs", {
  default(v) {
    fs = v;
  }
}, 4);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 5);
const {
  exec
} = require('child_process');
Meteor.methods({
  "Clients.Provision": function (clientId, playbook) {
    check(clientId, Mongo.ObjectID);
    const client = ClientsCollection.findOne({
      _id: clientId
    });
    if (!client) {
      throw new Meteor.Error("client-not-found", "That client doesn't exist.");
    }

    // Reading inventory file and adding hostname to inventory file
    fs.readFile('inventory', 'utf8', function (err, fileContent) {
      if (err) {
        console.error("Error reading file: ".concat(err));
        return;
      }

      // Check if the hostname is in the file 
      if (fileContent.includes(client.hostname)) {
        console.log("".concat(client.hostname, " already exists in the file."));
      } else {
        // If 'client.hostname' is not in the file, add it to the end of the file
        fileContent += "".concat(client.hostname, " ansible_host=").concat(client.ip, "\n");

        // Write the modified content back to the file
        fs.writeFile('inventory', fileContent, 'utf8', function (err) {
          if (err) {
            console.error("Error writing to file: ".concat(err));
            return;
          }
          console.log("".concat(client.hostname, " added to the file."));
          console.log("Content of file: ".concat(fileContent));
        });
      }
    });

    // Running Ansible command
    let command = "ansible-playbook -i inventory ".concat(playbook, " --limit \"").concat(client.hostname, " --ssh-common-args '-o StrictHostKeyChecking=no' --user root\"");
    const ansibleObject = AnsibleCollection.findOne({
      "ssh-key": {
        $exists: true
      }
    });

    // If key found, append to command
    if (ansibleObject) {
      command += " --private-key ".concat(ansibleObject["ssh-key"]);
    }
    console.log('Running command: ' + command);
    exec(command, (error, stdout, stderr) => {
      if (error) {
        console.error("Error executing command: ".concat(error.message));
        return;
      }
      if (stderr) {
        console.error("Command stderr: ".concat(stderr));
        return;
      }
      console.log("Command stdout: ".concat(stdout));
    });

    // Update client's provisioned status
    ClientsCollection.update({
      _id: clientId
    }, {
      $set: {
        provisioned: true,
        provisionedAt: new Date()
      }
    });
    return {
      status: 200,
      message: "".concat(client.hostname, " successfully provisioned")
    };
  }
});
///////////////////////////////////////////////////////////////////////////////////////////////

},"publications.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// api/clients/server/publications.js                                                        //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let ClientsCollection;
module.link("../clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 1);
let PlaybooksCollection;
module.link("../playbooks", {
  PlaybooksCollection(v) {
    PlaybooksCollection = v;
  }
}, 2);
let AnsibleCollection;
module.link("../ansible", {
  AnsibleCollection(v) {
    AnsibleCollection = v;
  }
}, 3);
Meteor.publish('Clients', function () {
  return ClientsCollection.find();
});
Meteor.publish('Playbooks', function () {
  return PlaybooksCollection.find();
});
Meteor.publish('Ansible', function () {
  return AnsibleCollection.find();
});
///////////////////////////////////////////////////////////////////////////////////////////////

}},"ansible.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// api/clients/ansible.js                                                                    //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
module.export({
  AnsibleCollection: () => AnsibleCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 0);
const AnsibleCollection = new Mongo.Collection('AnsibleCollection');
///////////////////////////////////////////////////////////////////////////////////////////////

},"clients.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// api/clients/clients.js                                                                    //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
module.export({
  ClientsCollection: () => ClientsCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 0);
const ClientsCollection = new Mongo.Collection('ClientsCollection');
///////////////////////////////////////////////////////////////////////////////////////////////

},"playbooks.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// api/clients/playbooks.js                                                                  //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
module.export({
  PlaybooksCollection: () => PlaybooksCollection
});
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }
}, 0);
const PlaybooksCollection = new Mongo.Collection('PlaybooksCollection');
///////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                           //
// server/main.js                                                                            //
//                                                                                           //
///////////////////////////////////////////////////////////////////////////////////////////////
                                                                                             //
module.export({
  CONFIG_FILE: () => CONFIG_FILE
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }
}, 0);
let ClientsCollection;
module.link("../api/clients/clients", {
  ClientsCollection(v) {
    ClientsCollection = v;
  }
}, 1);
let PlaybooksCollection;
module.link("../api/clients/playbooks", {
  PlaybooksCollection(v) {
    PlaybooksCollection = v;
  }
}, 2);
let AnsibleCollection;
module.link("../api/clients/ansible", {
  AnsibleCollection(v) {
    AnsibleCollection = v;
  }
}, 3);
module.link("../api/clients/server/publications");
module.link("../api/clients/server/methods");
const yaml = require("js-yaml");
const fs = require("fs");
const CONFIG_FILE_VAR = process.env.CONFIG_FILE || "/etc/genisys.yaml";
const CONFIG_FILE = yaml.load(fs.readFileSync(String(CONFIG_FILE_VAR), "utf8"));
// const temp_yaml_string = `---
// ansible:
//   inventory: /var/genisys/inventory
//   ssh-key: /etc/genisys/ssh/id_rsa
//   playbooks:
//     - /etc/genisys/playbooks/firstrun.yaml
//     - /etc/genisys/playbooks/script2.yaml`

// export const CONFIG_FILE = yaml.load(temp_yaml_string)

Meteor.startup(() => {
  console.log("Meteor Started");
  PlaybooksCollection.dropCollectionAsync();
  AnsibleCollection.dropCollectionAsync();

  // Load playbooks into Mongo
  CONFIG_FILE["ansible"]["playbooks"].forEach(element => {
    obj = {
      playbook: element
    };
    PlaybooksCollection.insert(obj);
  });

  // Putting ansible SSH key into mongo collection for usage on client
  if (CONFIG_FILE["ansible"]["ssh-key"]) {
    obj = {
      "ssh-key": CONFIG_FILE["ansible"]["ssh-key"]
    };
    AnsibleCollection.insert(obj);
  }

  //Creating Inventory file
  fs.access("inventory", fs.constants.F_OK, err => {
    if (err) {
      console.log("inventory does not exist, creating now");
      fs.writeFileSync("inventory", "[all_hosts]\n");
    } else {
      console.log("inventory exists");
    }
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".mjs"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvYXBpL2NsaWVudHMvc2VydmVyL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL3NlcnZlci9wdWJsaWNhdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL2Fuc2libGUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL2NsaWVudHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2FwaS9jbGllbnRzL3BsYXlib29rcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiXSwibmFtZXMiOlsiTWV0ZW9yIiwibW9kdWxlIiwibGluayIsInYiLCJjaGVjayIsIkNsaWVudHNDb2xsZWN0aW9uIiwiQW5zaWJsZUNvbGxlY3Rpb24iLCJmcyIsImRlZmF1bHQiLCJNb25nbyIsImV4ZWMiLCJyZXF1aXJlIiwibWV0aG9kcyIsIkNsaWVudHMuUHJvdmlzaW9uIiwiY2xpZW50SWQiLCJwbGF5Ym9vayIsIk9iamVjdElEIiwiY2xpZW50IiwiZmluZE9uZSIsIl9pZCIsIkVycm9yIiwicmVhZEZpbGUiLCJlcnIiLCJmaWxlQ29udGVudCIsImNvbnNvbGUiLCJlcnJvciIsImNvbmNhdCIsImluY2x1ZGVzIiwiaG9zdG5hbWUiLCJsb2ciLCJpcCIsIndyaXRlRmlsZSIsImNvbW1hbmQiLCJhbnNpYmxlT2JqZWN0IiwiJGV4aXN0cyIsInN0ZG91dCIsInN0ZGVyciIsIm1lc3NhZ2UiLCJ1cGRhdGUiLCIkc2V0IiwicHJvdmlzaW9uZWQiLCJwcm92aXNpb25lZEF0IiwiRGF0ZSIsInN0YXR1cyIsIlBsYXlib29rc0NvbGxlY3Rpb24iLCJwdWJsaXNoIiwiZmluZCIsImV4cG9ydCIsIkNvbGxlY3Rpb24iLCJDT05GSUdfRklMRSIsInlhbWwiLCJDT05GSUdfRklMRV9WQVIiLCJwcm9jZXNzIiwiZW52IiwibG9hZCIsInJlYWRGaWxlU3luYyIsIlN0cmluZyIsInN0YXJ0dXAiLCJkcm9wQ29sbGVjdGlvbkFzeW5jIiwiZm9yRWFjaCIsImVsZW1lbnQiLCJvYmoiLCJpbnNlcnQiLCJhY2Nlc3MiLCJjb25zdGFudHMiLCJGX09LIiwid3JpdGVGaWxlU3luYyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFNO0FBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGVBQWUsRUFBQztFQUFDRixNQUFNQSxDQUFDRyxDQUFDLEVBQUM7SUFBQ0gsTUFBTSxHQUFDRyxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUMsS0FBSztBQUFDSCxNQUFNLENBQUNDLElBQUksQ0FBQyxjQUFjLEVBQUM7RUFBQ0UsS0FBS0EsQ0FBQ0QsQ0FBQyxFQUFDO0lBQUNDLEtBQUssR0FBQ0QsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlFLGlCQUFpQjtBQUFDSixNQUFNLENBQUNDLElBQUksQ0FBQyxZQUFZLEVBQUM7RUFBQ0csaUJBQWlCQSxDQUFDRixDQUFDLEVBQUM7SUFBQ0UsaUJBQWlCLEdBQUNGLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJRyxpQkFBaUI7QUFBQ0wsTUFBTSxDQUFDQyxJQUFJLENBQUMsWUFBWSxFQUFDO0VBQUNJLGlCQUFpQkEsQ0FBQ0gsQ0FBQyxFQUFDO0lBQUNHLGlCQUFpQixHQUFDSCxDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSUksRUFBRTtBQUFDTixNQUFNLENBQUNDLElBQUksQ0FBQyxJQUFJLEVBQUM7RUFBQ00sT0FBT0EsQ0FBQ0wsQ0FBQyxFQUFDO0lBQUNJLEVBQUUsR0FBQ0osQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlNLEtBQUs7QUFBQ1IsTUFBTSxDQUFDQyxJQUFJLENBQUMsY0FBYyxFQUFDO0VBQUNPLEtBQUtBLENBQUNOLENBQUMsRUFBQztJQUFDTSxLQUFLLEdBQUNOLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFLamEsTUFBTTtFQUFFTztBQUFLLENBQUMsR0FBR0MsT0FBTyxDQUFDLGVBQWUsQ0FBQztBQUd6Q1gsTUFBTSxDQUFDWSxPQUFPLENBQUM7RUFDYixtQkFBbUIsRUFBRSxTQUFBQyxDQUFVQyxRQUFRLEVBQUVDLFFBQVEsRUFBRTtJQUNqRFgsS0FBSyxDQUFDVSxRQUFRLEVBQUVMLEtBQUssQ0FBQ08sUUFBUSxDQUFDO0lBRS9CLE1BQU1DLE1BQU0sR0FBR1osaUJBQWlCLENBQUNhLE9BQU8sQ0FBQztNQUN2Q0MsR0FBRyxFQUFFTDtJQUNQLENBQUMsQ0FBQztJQUVGLElBQUksQ0FBQ0csTUFBTSxFQUFFO01BQ1gsTUFBTSxJQUFJakIsTUFBTSxDQUFDb0IsS0FBSyxDQUFDLGtCQUFrQixFQUFFLDRCQUE0QixDQUFDO0lBQzFFOztJQUVBO0lBQ0FiLEVBQUUsQ0FBQ2MsUUFBUSxDQUFDLFdBQVcsRUFBRSxNQUFNLEVBQUUsVUFBVUMsR0FBRyxFQUFFQyxXQUFXLEVBQUU7TUFDekQsSUFBSUQsR0FBRyxFQUFFO1FBQ0xFLE9BQU8sQ0FBQ0MsS0FBSyx3QkFBQUMsTUFBQSxDQUF3QkosR0FBRyxDQUFFLENBQUM7UUFDM0M7TUFDSjs7TUFFQTtNQUNBLElBQUlDLFdBQVcsQ0FBQ0ksUUFBUSxDQUFDVixNQUFNLENBQUNXLFFBQVEsQ0FBQyxFQUFFO1FBQ3ZDSixPQUFPLENBQUNLLEdBQUcsSUFBQUgsTUFBQSxDQUFJVCxNQUFNLENBQUNXLFFBQVEsaUNBQThCLENBQUM7TUFDakUsQ0FBQyxNQUFNO1FBQ0g7UUFDQUwsV0FBVyxPQUFBRyxNQUFBLENBQU9ULE1BQU0sQ0FBQ1csUUFBUSxvQkFBQUYsTUFBQSxDQUFpQlQsTUFBTSxDQUFDYSxFQUFFLE9BQUk7O1FBRS9EO1FBQ0F2QixFQUFFLENBQUN3QixTQUFTLENBQUMsV0FBVyxFQUFFUixXQUFXLEVBQUUsTUFBTSxFQUFFLFVBQVVELEdBQUcsRUFBRTtVQUMxRCxJQUFJQSxHQUFHLEVBQUU7WUFDTEUsT0FBTyxDQUFDQyxLQUFLLDJCQUFBQyxNQUFBLENBQTJCSixHQUFHLENBQUUsQ0FBQztZQUM5QztVQUNKO1VBQ0FFLE9BQU8sQ0FBQ0ssR0FBRyxJQUFBSCxNQUFBLENBQUlULE1BQU0sQ0FBQ1csUUFBUSx3QkFBcUIsQ0FBQztVQUNwREosT0FBTyxDQUFDSyxHQUFHLHFCQUFBSCxNQUFBLENBQXFCSCxXQUFXLENBQUUsQ0FBQztRQUNsRCxDQUFDLENBQUM7TUFDTjtJQUNKLENBQUMsQ0FBQzs7SUFFRjtJQUNBLElBQUlTLE9BQU8sb0NBQUFOLE1BQUEsQ0FBb0NYLFFBQVEsaUJBQUFXLE1BQUEsQ0FBYVQsTUFBTSxDQUFDVyxRQUFRLG1FQUErRDtJQUVsSixNQUFNSyxhQUFhLEdBQUczQixpQkFBaUIsQ0FBQ1ksT0FBTyxDQUFDO01BQUMsU0FBUyxFQUFFO1FBQUVnQixPQUFPLEVBQUU7TUFBSztJQUFDLENBQUMsQ0FBQzs7SUFFL0U7SUFDQSxJQUFJRCxhQUFhLEVBQUU7TUFDZkQsT0FBTyxzQkFBQU4sTUFBQSxDQUFzQk8sYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFFO0lBQzNEO0lBRUFULE9BQU8sQ0FBQ0ssR0FBRyxDQUFDLG1CQUFtQixHQUFHRyxPQUFPLENBQUM7SUFFMUN0QixJQUFJLENBQUNzQixPQUFPLEVBQUUsQ0FBQ1AsS0FBSyxFQUFFVSxNQUFNLEVBQUVDLE1BQU0sS0FBSztNQUNyQyxJQUFJWCxLQUFLLEVBQUU7UUFDUEQsT0FBTyxDQUFDQyxLQUFLLDZCQUFBQyxNQUFBLENBQTZCRCxLQUFLLENBQUNZLE9BQU8sQ0FBRSxDQUFDO1FBQzFEO01BQ0o7TUFDQSxJQUFJRCxNQUFNLEVBQUU7UUFDUlosT0FBTyxDQUFDQyxLQUFLLG9CQUFBQyxNQUFBLENBQW9CVSxNQUFNLENBQUUsQ0FBQztRQUMxQztNQUNKO01BQ0FaLE9BQU8sQ0FBQ0ssR0FBRyxvQkFBQUgsTUFBQSxDQUFvQlMsTUFBTSxDQUFFLENBQUM7SUFDNUMsQ0FBQyxDQUFDOztJQUVGO0lBQ0E5QixpQkFBaUIsQ0FBQ2lDLE1BQU0sQ0FDdEI7TUFDRW5CLEdBQUcsRUFBRUw7SUFDUCxDQUFDLEVBQ0Q7TUFDRXlCLElBQUksRUFBRTtRQUNKQyxXQUFXLEVBQUUsSUFBSTtRQUNqQkMsYUFBYSxFQUFFLElBQUlDLElBQUksQ0FBQztNQUMxQjtJQUNGLENBQ0YsQ0FBQztJQUNELE9BQU87TUFDTEMsTUFBTSxFQUFFLEdBQUc7TUFDWE4sT0FBTyxLQUFBWCxNQUFBLENBQUtULE1BQU0sQ0FBQ1csUUFBUTtJQUM3QixDQUFDO0VBQ0g7QUFDRixDQUFDLENBQUMsQzs7Ozs7Ozs7Ozs7QUN2RkYsSUFBSTVCLE1BQU07QUFBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUMsZUFBZSxFQUFDO0VBQUNGLE1BQU1BLENBQUNHLENBQUMsRUFBQztJQUFDSCxNQUFNLEdBQUNHLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFBQyxJQUFJRSxpQkFBaUI7QUFBQ0osTUFBTSxDQUFDQyxJQUFJLENBQUMsWUFBWSxFQUFDO0VBQUNHLGlCQUFpQkEsQ0FBQ0YsQ0FBQyxFQUFDO0lBQUNFLGlCQUFpQixHQUFDRixDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBQUMsSUFBSXlDLG1CQUFtQjtBQUFDM0MsTUFBTSxDQUFDQyxJQUFJLENBQUMsY0FBYyxFQUFDO0VBQUMwQyxtQkFBbUJBLENBQUN6QyxDQUFDLEVBQUM7SUFBQ3lDLG1CQUFtQixHQUFDekMsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlHLGlCQUFpQjtBQUFDTCxNQUFNLENBQUNDLElBQUksQ0FBQyxZQUFZLEVBQUM7RUFBQ0ksaUJBQWlCQSxDQUFDSCxDQUFDLEVBQUM7SUFBQ0csaUJBQWlCLEdBQUNILENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFLaldILE1BQU0sQ0FBQzZDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsWUFBVztFQUNqQyxPQUFPeEMsaUJBQWlCLENBQUN5QyxJQUFJLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUM7QUFFRjlDLE1BQU0sQ0FBQzZDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsWUFBVztFQUNuQyxPQUFPRCxtQkFBbUIsQ0FBQ0UsSUFBSSxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDO0FBRUY5QyxNQUFNLENBQUM2QyxPQUFPLENBQUMsU0FBUyxFQUFFLFlBQVc7RUFDakMsT0FBT3ZDLGlCQUFpQixDQUFDd0MsSUFBSSxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLEM7Ozs7Ozs7Ozs7O0FDZkY3QyxNQUFNLENBQUM4QyxNQUFNLENBQUM7RUFBQ3pDLGlCQUFpQixFQUFDQSxDQUFBLEtBQUlBO0FBQWlCLENBQUMsQ0FBQztBQUFDLElBQUlHLEtBQUs7QUFBQ1IsTUFBTSxDQUFDQyxJQUFJLENBQUMsY0FBYyxFQUFDO0VBQUNPLEtBQUtBLENBQUNOLENBQUMsRUFBQztJQUFDTSxLQUFLLEdBQUNOLENBQUM7RUFBQTtBQUFDLENBQUMsRUFBQyxDQUFDLENBQUM7QUFFN0csTUFBTUcsaUJBQWlCLEdBQUcsSUFBSUcsS0FBSyxDQUFDdUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLEM7Ozs7Ozs7Ozs7O0FDRjFFL0MsTUFBTSxDQUFDOEMsTUFBTSxDQUFDO0VBQUMxQyxpQkFBaUIsRUFBQ0EsQ0FBQSxLQUFJQTtBQUFpQixDQUFDLENBQUM7QUFBQyxJQUFJSSxLQUFLO0FBQUNSLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLGNBQWMsRUFBQztFQUFDTyxLQUFLQSxDQUFDTixDQUFDLEVBQUM7SUFBQ00sS0FBSyxHQUFDTixDQUFDO0VBQUE7QUFBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDO0FBRTdHLE1BQU1FLGlCQUFpQixHQUFHLElBQUlJLEtBQUssQ0FBQ3VDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxDOzs7Ozs7Ozs7OztBQ0YxRS9DLE1BQU0sQ0FBQzhDLE1BQU0sQ0FBQztFQUFDSCxtQkFBbUIsRUFBQ0EsQ0FBQSxLQUFJQTtBQUFtQixDQUFDLENBQUM7QUFBQyxJQUFJbkMsS0FBSztBQUFDUixNQUFNLENBQUNDLElBQUksQ0FBQyxjQUFjLEVBQUM7RUFBQ08sS0FBS0EsQ0FBQ04sQ0FBQyxFQUFDO0lBQUNNLEtBQUssR0FBQ04sQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUVqSCxNQUFNeUMsbUJBQW1CLEdBQUcsSUFBSW5DLEtBQUssQ0FBQ3VDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxDOzs7Ozs7Ozs7OztBQ0Y5RS9DLE1BQU0sQ0FBQzhDLE1BQU0sQ0FBQztFQUFDRSxXQUFXLEVBQUNBLENBQUEsS0FBSUE7QUFBVyxDQUFDLENBQUM7QUFBQyxJQUFJakQsTUFBTTtBQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQyxlQUFlLEVBQUM7RUFBQ0YsTUFBTUEsQ0FBQ0csQ0FBQyxFQUFDO0lBQUNILE1BQU0sR0FBQ0csQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlFLGlCQUFpQjtBQUFDSixNQUFNLENBQUNDLElBQUksQ0FBQyx3QkFBd0IsRUFBQztFQUFDRyxpQkFBaUJBLENBQUNGLENBQUMsRUFBQztJQUFDRSxpQkFBaUIsR0FBQ0YsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUl5QyxtQkFBbUI7QUFBQzNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDLDBCQUEwQixFQUFDO0VBQUMwQyxtQkFBbUJBLENBQUN6QyxDQUFDLEVBQUM7SUFBQ3lDLG1CQUFtQixHQUFDekMsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDLElBQUlHLGlCQUFpQjtBQUFDTCxNQUFNLENBQUNDLElBQUksQ0FBQyx3QkFBd0IsRUFBQztFQUFDSSxpQkFBaUJBLENBQUNILENBQUMsRUFBQztJQUFDRyxpQkFBaUIsR0FBQ0gsQ0FBQztFQUFBO0FBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQztBQUFDRixNQUFNLENBQUNDLElBQUksQ0FBQyxvQ0FBb0MsQ0FBQztBQUFDRCxNQUFNLENBQUNDLElBQUksQ0FBQywrQkFBK0IsQ0FBQztBQU9qaEIsTUFBTWdELElBQUksR0FBR3ZDLE9BQU8sQ0FBQyxTQUFTLENBQUM7QUFDL0IsTUFBTUosRUFBRSxHQUFHSSxPQUFPLENBQUMsSUFBSSxDQUFDO0FBRXhCLE1BQU13QyxlQUFlLEdBQUdDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSixXQUFXLElBQUksbUJBQW1CO0FBQy9ELE1BQU1BLFdBQVcsR0FBR0MsSUFBSSxDQUFDSSxJQUFJLENBQ2xDL0MsRUFBRSxDQUFDZ0QsWUFBWSxDQUFDQyxNQUFNLENBQUNMLGVBQWUsQ0FBQyxFQUFFLE1BQU0sQ0FDakQsQ0FBQztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOztBQUVBbkQsTUFBTSxDQUFDeUQsT0FBTyxDQUFDLE1BQU07RUFDbkJqQyxPQUFPLENBQUNLLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztFQUU3QmUsbUJBQW1CLENBQUNjLG1CQUFtQixDQUFDLENBQUM7RUFDekNwRCxpQkFBaUIsQ0FBQ29ELG1CQUFtQixDQUFDLENBQUM7O0VBRXZDO0VBQ0FULFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQ1UsT0FBTyxDQUFFQyxPQUFPLElBQUs7SUFDdkRDLEdBQUcsR0FBRztNQUFFOUMsUUFBUSxFQUFFNkM7SUFBUSxDQUFDO0lBQzNCaEIsbUJBQW1CLENBQUNrQixNQUFNLENBQUNELEdBQUcsQ0FBQztFQUNqQyxDQUFDLENBQUM7O0VBRUY7RUFDQSxJQUFJWixXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQ3JDO0lBQ0VZLEdBQUcsR0FBRztNQUFDLFNBQVMsRUFBRVosV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVM7SUFBQyxDQUFDO0lBQ3BEM0MsaUJBQWlCLENBQUN3RCxNQUFNLENBQUNELEdBQUcsQ0FBQztFQUMvQjs7RUFFQTtFQUNBdEQsRUFBRSxDQUFDd0QsTUFBTSxDQUFDLFdBQVcsRUFBRXhELEVBQUUsQ0FBQ3lELFNBQVMsQ0FBQ0MsSUFBSSxFQUFHM0MsR0FBRyxJQUFLO0lBQ2pELElBQUlBLEdBQUcsRUFBRTtNQUNQRSxPQUFPLENBQUNLLEdBQUcseUNBQXlDLENBQUM7TUFDckR0QixFQUFFLENBQUMyRCxhQUFhLENBQUMsV0FBVyxFQUFFLGVBQWUsQ0FBQztJQUNoRCxDQUFDLE1BQU07TUFDTDFDLE9BQU8sQ0FBQ0ssR0FBRyxtQkFBbUIsQ0FBQztJQUNqQztFQUNGLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiXHJcbmltcG9ydCB7IGNoZWNrIH0gZnJvbSBcIm1ldGVvci9jaGVja1wiXHJcbmltcG9ydCB7IENsaWVudHNDb2xsZWN0aW9uIH0gZnJvbSBcIi4uL2NsaWVudHNcIlxyXG5pbXBvcnQgeyBBbnNpYmxlQ29sbGVjdGlvbiB9IGZyb20gXCIuLi9hbnNpYmxlXCJcclxuaW1wb3J0IGZzIGZyb20gXCJmc1wiXHJcbmNvbnN0IHsgZXhlYyB9ID0gcmVxdWlyZSgnY2hpbGRfcHJvY2VzcycpXHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuICBcIkNsaWVudHMuUHJvdmlzaW9uXCI6IGZ1bmN0aW9uIChjbGllbnRJZCwgcGxheWJvb2spIHtcclxuICAgIGNoZWNrKGNsaWVudElkLCBNb25nby5PYmplY3RJRClcclxuXHJcbiAgICBjb25zdCBjbGllbnQgPSBDbGllbnRzQ29sbGVjdGlvbi5maW5kT25lKHtcclxuICAgICAgX2lkOiBjbGllbnRJZCxcclxuICAgIH0pXHJcblxyXG4gICAgaWYgKCFjbGllbnQpIHtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihcImNsaWVudC1ub3QtZm91bmRcIiwgXCJUaGF0IGNsaWVudCBkb2Vzbid0IGV4aXN0LlwiKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIFJlYWRpbmcgaW52ZW50b3J5IGZpbGUgYW5kIGFkZGluZyBob3N0bmFtZSB0byBpbnZlbnRvcnkgZmlsZVxyXG4gICAgZnMucmVhZEZpbGUoJ2ludmVudG9yeScsICd1dGY4JywgZnVuY3Rpb24gKGVyciwgZmlsZUNvbnRlbnQpIHtcclxuICAgICAgICBpZiAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIHJlYWRpbmcgZmlsZTogJHtlcnJ9YCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICBcclxuICAgICAgICAvLyBDaGVjayBpZiB0aGUgaG9zdG5hbWUgaXMgaW4gdGhlIGZpbGUgXHJcbiAgICAgICAgaWYgKGZpbGVDb250ZW50LmluY2x1ZGVzKGNsaWVudC5ob3N0bmFtZSkpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coYCR7Y2xpZW50Lmhvc3RuYW1lfSBhbHJlYWR5IGV4aXN0cyBpbiB0aGUgZmlsZS5gKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAvLyBJZiAnY2xpZW50Lmhvc3RuYW1lJyBpcyBub3QgaW4gdGhlIGZpbGUsIGFkZCBpdCB0byB0aGUgZW5kIG9mIHRoZSBmaWxlXHJcbiAgICAgICAgICAgIGZpbGVDb250ZW50ICs9IGAke2NsaWVudC5ob3N0bmFtZX0gYW5zaWJsZV9ob3N0PSR7Y2xpZW50LmlwfVxcbmA7XHJcbiAgICBcclxuICAgICAgICAgICAgLy8gV3JpdGUgdGhlIG1vZGlmaWVkIGNvbnRlbnQgYmFjayB0byB0aGUgZmlsZVxyXG4gICAgICAgICAgICBmcy53cml0ZUZpbGUoJ2ludmVudG9yeScsIGZpbGVDb250ZW50LCAndXRmOCcsIGZ1bmN0aW9uIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciB3cml0aW5nIHRvIGZpbGU6ICR7ZXJyfWApO1xyXG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGAke2NsaWVudC5ob3N0bmFtZX0gYWRkZWQgdG8gdGhlIGZpbGUuYCk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgQ29udGVudCBvZiBmaWxlOiAke2ZpbGVDb250ZW50fWApXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIC8vIFJ1bm5pbmcgQW5zaWJsZSBjb21tYW5kXHJcbiAgICBsZXQgY29tbWFuZCA9IGBhbnNpYmxlLXBsYXlib29rIC1pIGludmVudG9yeSAke3BsYXlib29rfSAtLWxpbWl0IFwiJHtjbGllbnQuaG9zdG5hbWV9IC0tc3NoLWNvbW1vbi1hcmdzICctbyBTdHJpY3RIb3N0S2V5Q2hlY2tpbmc9bm8nIC0tdXNlciByb290XCJgXHJcblxyXG4gICAgY29uc3QgYW5zaWJsZU9iamVjdCA9IEFuc2libGVDb2xsZWN0aW9uLmZpbmRPbmUoe1wic3NoLWtleVwiOiB7ICRleGlzdHM6IHRydWUgfX0pXHJcblxyXG4gICAgLy8gSWYga2V5IGZvdW5kLCBhcHBlbmQgdG8gY29tbWFuZFxyXG4gICAgaWYgKGFuc2libGVPYmplY3QpIHtcclxuICAgICAgICBjb21tYW5kICs9IGAgLS1wcml2YXRlLWtleSAke2Fuc2libGVPYmplY3RbXCJzc2gta2V5XCJdfWBcclxuICAgIH1cclxuXHJcbiAgICBjb25zb2xlLmxvZygnUnVubmluZyBjb21tYW5kOiAnICsgY29tbWFuZClcclxuXHJcbiAgICBleGVjKGNvbW1hbmQsIChlcnJvciwgc3Rkb3V0LCBzdGRlcnIpID0+IHtcclxuICAgICAgICBpZiAoZXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRXJyb3IgZXhlY3V0aW5nIGNvbW1hbmQ6ICR7ZXJyb3IubWVzc2FnZX1gKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoc3RkZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYENvbW1hbmQgc3RkZXJyOiAke3N0ZGVycn1gKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zb2xlLmxvZyhgQ29tbWFuZCBzdGRvdXQ6ICR7c3Rkb3V0fWApO1xyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gVXBkYXRlIGNsaWVudCdzIHByb3Zpc2lvbmVkIHN0YXR1c1xyXG4gICAgQ2xpZW50c0NvbGxlY3Rpb24udXBkYXRlKFxyXG4gICAgICB7XHJcbiAgICAgICAgX2lkOiBjbGllbnRJZCxcclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgIHByb3Zpc2lvbmVkOiB0cnVlLFxyXG4gICAgICAgICAgcHJvdmlzaW9uZWRBdDogbmV3IERhdGUoKSxcclxuICAgICAgICB9LFxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBzdGF0dXM6IDIwMCxcclxuICAgICAgbWVzc2FnZTogYCR7Y2xpZW50Lmhvc3RuYW1lfSBzdWNjZXNzZnVsbHkgcHJvdmlzaW9uZWRgLFxyXG4gICAgfVxyXG4gIH1cclxufSlcclxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcbmltcG9ydCB7IENsaWVudHNDb2xsZWN0aW9uIH0gZnJvbSAnLi4vY2xpZW50cyc7XHJcbmltcG9ydCB7IFBsYXlib29rc0NvbGxlY3Rpb24gfSBmcm9tICcuLi9wbGF5Ym9va3MnO1xyXG5pbXBvcnQgeyBBbnNpYmxlQ29sbGVjdGlvbiB9IGZyb20gJy4uL2Fuc2libGUnO1xyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ0NsaWVudHMnLCBmdW5jdGlvbigpIHtcclxuICAgIHJldHVybiBDbGllbnRzQ29sbGVjdGlvbi5maW5kKClcclxufSlcclxuXHJcbk1ldGVvci5wdWJsaXNoKCdQbGF5Ym9va3MnLCBmdW5jdGlvbigpIHtcclxuICAgIHJldHVybiBQbGF5Ym9va3NDb2xsZWN0aW9uLmZpbmQoKVxyXG59KVxyXG5cclxuTWV0ZW9yLnB1Ymxpc2goJ0Fuc2libGUnLCBmdW5jdGlvbigpIHtcclxuICAgIHJldHVybiBBbnNpYmxlQ29sbGVjdGlvbi5maW5kKClcclxufSkiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgY29uc3QgQW5zaWJsZUNvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignQW5zaWJsZUNvbGxlY3Rpb24nKTsiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgY29uc3QgQ2xpZW50c0NvbGxlY3Rpb24gPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignQ2xpZW50c0NvbGxlY3Rpb24nKTsiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcblxyXG5leHBvcnQgY29uc3QgUGxheWJvb2tzQ29sbGVjdGlvbiA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdQbGF5Ym9va3NDb2xsZWN0aW9uJykiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiXHJcbmltcG9ydCB7IENsaWVudHNDb2xsZWN0aW9uIH0gZnJvbSBcIi4uL2FwaS9jbGllbnRzL2NsaWVudHNcIlxyXG5pbXBvcnQgeyBQbGF5Ym9va3NDb2xsZWN0aW9uIH0gZnJvbSBcIi4uL2FwaS9jbGllbnRzL3BsYXlib29rc1wiXHJcbmltcG9ydCB7IEFuc2libGVDb2xsZWN0aW9uIH0gZnJvbSBcIi4uL2FwaS9jbGllbnRzL2Fuc2libGVcIlxyXG5pbXBvcnQgXCIuLi9hcGkvY2xpZW50cy9zZXJ2ZXIvcHVibGljYXRpb25zXCJcclxuaW1wb3J0IFwiLi4vYXBpL2NsaWVudHMvc2VydmVyL21ldGhvZHNcIlxyXG5cclxuY29uc3QgeWFtbCA9IHJlcXVpcmUoXCJqcy15YW1sXCIpXHJcbmNvbnN0IGZzID0gcmVxdWlyZShcImZzXCIpXHJcblxyXG5jb25zdCBDT05GSUdfRklMRV9WQVIgPSBwcm9jZXNzLmVudi5DT05GSUdfRklMRSB8fCBcIi9ldGMvZ2VuaXN5cy55YW1sXCJcclxuZXhwb3J0IGNvbnN0IENPTkZJR19GSUxFID0geWFtbC5sb2FkKFxyXG4gIGZzLnJlYWRGaWxlU3luYyhTdHJpbmcoQ09ORklHX0ZJTEVfVkFSKSwgXCJ1dGY4XCIpXHJcbilcclxuXHJcbi8vIGNvbnN0IHRlbXBfeWFtbF9zdHJpbmcgPSBgLS0tXHJcbi8vIGFuc2libGU6XHJcbi8vICAgaW52ZW50b3J5OiAvdmFyL2dlbmlzeXMvaW52ZW50b3J5XHJcbi8vICAgc3NoLWtleTogL2V0Yy9nZW5pc3lzL3NzaC9pZF9yc2FcclxuLy8gICBwbGF5Ym9va3M6XHJcbi8vICAgICAtIC9ldGMvZ2VuaXN5cy9wbGF5Ym9va3MvZmlyc3RydW4ueWFtbFxyXG4vLyAgICAgLSAvZXRjL2dlbmlzeXMvcGxheWJvb2tzL3NjcmlwdDIueWFtbGBcclxuXHJcbi8vIGV4cG9ydCBjb25zdCBDT05GSUdfRklMRSA9IHlhbWwubG9hZCh0ZW1wX3lhbWxfc3RyaW5nKVxyXG5cclxuTWV0ZW9yLnN0YXJ0dXAoKCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKFwiTWV0ZW9yIFN0YXJ0ZWRcIilcclxuXHJcbiAgUGxheWJvb2tzQ29sbGVjdGlvbi5kcm9wQ29sbGVjdGlvbkFzeW5jKClcclxuICBBbnNpYmxlQ29sbGVjdGlvbi5kcm9wQ29sbGVjdGlvbkFzeW5jKClcclxuXHJcbiAgLy8gTG9hZCBwbGF5Ym9va3MgaW50byBNb25nb1xyXG4gIENPTkZJR19GSUxFW1wiYW5zaWJsZVwiXVtcInBsYXlib29rc1wiXS5mb3JFYWNoKChlbGVtZW50KSA9PiB7XHJcbiAgICBvYmogPSB7IHBsYXlib29rOiBlbGVtZW50IH1cclxuICAgIFBsYXlib29rc0NvbGxlY3Rpb24uaW5zZXJ0KG9iailcclxuICB9KVxyXG5cclxuICAvLyBQdXR0aW5nIGFuc2libGUgU1NIIGtleSBpbnRvIG1vbmdvIGNvbGxlY3Rpb24gZm9yIHVzYWdlIG9uIGNsaWVudFxyXG4gIGlmIChDT05GSUdfRklMRVtcImFuc2libGVcIl1bXCJzc2gta2V5XCJdKVxyXG4gIHtcclxuICAgIG9iaiA9IHtcInNzaC1rZXlcIjogQ09ORklHX0ZJTEVbXCJhbnNpYmxlXCJdW1wic3NoLWtleVwiXX1cclxuICAgIEFuc2libGVDb2xsZWN0aW9uLmluc2VydChvYmopXHJcbiAgfVxyXG5cclxuICAvL0NyZWF0aW5nIEludmVudG9yeSBmaWxlXHJcbiAgZnMuYWNjZXNzKFwiaW52ZW50b3J5XCIsIGZzLmNvbnN0YW50cy5GX09LLCAoZXJyKSA9PiB7XHJcbiAgICBpZiAoZXJyKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGBpbnZlbnRvcnkgZG9lcyBub3QgZXhpc3QsIGNyZWF0aW5nIG5vd2ApXHJcbiAgICAgIGZzLndyaXRlRmlsZVN5bmMoXCJpbnZlbnRvcnlcIiwgXCJbYWxsX2hvc3RzXVxcblwiKVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY29uc29sZS5sb2coYGludmVudG9yeSBleGlzdHNgKVxyXG4gICAgfVxyXG4gIH0pXHJcbn0pXHJcbiJdfQ==
